if(!window.cp)window.cp = function(str){return document.getElementById(str)};cp.CPProjInit = function(){if(cp && cp.model && cp.model.data) return; cp.model = {}; cp.poolResources = {}; cp.D = cp.model.data = {
pref:{
acc:1,
rkt:1,
hsr:0,
atp:false
},
si462:{
name:'Simulation_1',
type:1268,
from:10901,
to:11262,
rp:0,
rpa:0,
mdi:'si462c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si454',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si462c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:462,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si462',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si454:{
name:'Simulation_non_responsive_1',
type:1268,
from:10901,
to:11262,
rp:0,
rpa:0,
mdi:'si454c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-inputfield":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si462',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si473',
t:1269
}
,{
n:'si493',
t:612
}
,{
n:'si2135',
t:12
}
,{
n:'si2171',
t:612
}
,{
n:'si2151',
t:1269
}
,{
n:'si2954',
t:612
}
,{
n:'si2924',
t:2433
}
,{
n:'si3116',
t:612
}
,{
n:'si3168',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-inputfield":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si462',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si454c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:454,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si454',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:470,
tsp:50,
ip:'dr/0470.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si473:{
name:'Click_box_1',
type:1269,
from:10539,
to:10900,
rp:0,
rpa:0,
mdi:'si473c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.1,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":175,"left":1326,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(546);"]]}]}',
ola:'{"scripts":[{"then":[["cp.jumpToNextSlide(3166);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:12.052,
lcapid:'si493',
si:[{
n:'si483',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[473]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si473c:{
b:[1326,175,1360,195],
fh:false,
fw:false,
uid:473,
iso:false,
css:{
360:{
l:'136.420%',
t:'28.783%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'136.420%',
lhID:-1,
lvEID:0,
lvV:'28.783%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'136.420%',
t:'28.783%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'136.420%',
lhID:-1,
lvEID:0,
lvV:'28.783%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'136.420%',
t:'28.783%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'136.420%',
lhID:-1,
lvEID:0,
lvV:'28.783%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si473',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1326,175,1360,195],
vb:[1326,175,1360,195]
},
si483:{
name:'Shape_1',
type:612,
from:10539,
to:10900,
rp:0,
rpa:0,
mdi:'si483c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[483]
}
]
,
stis:0,
bstiid:473,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si473',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si483c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:483,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si483',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si493:{
name:'Rectangle_1',
type:612,
from:1,
to:362,
rp:0,
rpa:0,
mdi:'si493c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.1,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":235,"left":1011,"width":300,"height":"auto"}}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:504,
stt:0,
dsr:'Default_State',
stsi:[493]
}
,{
stn:516,
stt:102,
dsr:'Failure',
stsi:[517]
}
,{
stn:527,
stt:103,
dsr:'Hint',
stsi:[528]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si493','si506','si517','si528'],
isDD:false
},
si493c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:493,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si493',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si506:{
name:'',
type:612,
from:1,
to:362,
rp:0,
rpa:0,
mdi:'si506c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":235,"left":1011,"width":300,"height":"auto"}}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si493',
stl:[{
stn:'Normal',
stt:0,
stsi:[506]
}
]
,
stis:0,
bstiid:493,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:493,
isDD:false
},
si506c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:506,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si506',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si517:{
name:'',
type:612,
from:1,
to:362,
rp:0,
rpa:0,
mdi:'si517c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":235,"left":1011,"width":300,"height":"auto"}}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si493',
stl:[{
stn:'Normal',
stt:0,
stsi:[517]
}
]
,
stis:0,
bstiid:493,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:493,
isDD:false
},
si517c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:517,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si517',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si528:{
name:'',
type:612,
from:1,
to:362,
rp:0,
rpa:0,
mdi:'si528c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":235,"left":1011,"width":300,"height":"auto"}}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si493',
stl:[{
stn:'Normal',
stt:0,
stsi:[528]
}
]
,
stis:0,
bstiid:493,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:493,
isDD:false
},
si528c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:528,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si528',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2135:{
name:'Mouse_1',
type:12,
from:10901,
to:11262,
rp:0,
rpa:0,
mdi:'si2135c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.1,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":false,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":0,"mouseStartPointY":0,"mouseEndPointX":1348.2451965547702,"mouseEndPointY":182.76788869257945}}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2135Ad',
trin:0,
trout:0,
isDD:false
},
si2135c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2135,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2135',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2135Ad:{
src:'ar/Mouse.mp3',
from:10901,
to:10906,
del:11.918,
msa:1,
du:0.182
},
si2171:{
name:'Rectangle_12',
type:612,
from:259,
to:362,
rp:0,
rpa:0,
mdi:'si2171c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:8.6,
sid:3.5,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2182,
stt:0,
dsr:'Default_State',
stsi:[2171]
}
,{
stn:2194,
stt:102,
dsr:'Failure',
stsi:[2195]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2171','si2184','si2195','si2206'],
isDD:false
},
si2171c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2171,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2171',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2184:{
name:'',
type:612,
from:1,
to:362,
rp:0,
rpa:0,
mdi:'si2184c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:8.6,
sid:3.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2171',
stl:[{
stn:'Normal',
stt:0,
stsi:[2184]
}
]
,
stis:0,
bstiid:2171,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2171,
isDD:false
},
si2184c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2184,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2184',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2195:{
name:'',
type:612,
from:1,
to:362,
rp:0,
rpa:0,
mdi:'si2195c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:8.6,
sid:3.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2171',
stl:[{
stn:'Normal',
stt:0,
stsi:[2195]
}
]
,
stis:0,
bstiid:2171,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2171,
isDD:false
},
si2195c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2195,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2195',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2206:{
name:'',
type:612,
from:1,
to:362,
rp:0,
rpa:0,
mdi:'si2206c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:8.6,
sid:3.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2171',
stl:[{
stn:'Normal',
stt:0,
stsi:[2206]
}
]
,
stis:0,
bstiid:2171,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2171,
isDD:false
},
si2206c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2206,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2206',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2151:{
name:'Highlight_box_1',
type:1269,
from:8974,
to:9077,
rp:0,
rpa:0,
mdi:'si2151c',
tag:'slide-item-highlight-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:8.6,
sid:3.5,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":1312.32238295053,"top":162.9043175795053,"width":56.072437299856446,"height":44.85059542706493},"shouldRender":true}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ihb:true,
si:[{
n:'si2161',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2151]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2151c:{
b:[1132,24,1260,56],
fh:false,
fw:false,
uid:2151,
iso:false,
css:{
360:{
l:'116.461%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'116.461%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'116.461%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'116.461%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'116.461%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'116.461%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2151',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[1132,24,1260,56],
vb:[1132,24,1260,56]
},
si2161:{
name:'Shape_12',
type:612,
from:8974,
to:9077,
rp:0,
rpa:0,
mdi:'si2161c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:8.6,
sid:3.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2161]
}
]
,
stis:0,
bstiid:2151,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2151',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2161c:{
b:[0,0,128,32],
fh:false,
fw:false,
uid:2161,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2161',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,130,34],
vb:[-2,-2,130,34]
},
si2954:{
name:'Rectangle_19',
type:612,
from:4143,
to:4504,
rp:0,
rpa:0,
mdi:'si2954c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.1,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2965,
stt:0,
dsr:'Default_State',
stsi:[2954]
}
,{
stn:2977,
stt:102,
dsr:'Failure',
stsi:[2978]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2954','si2967','si2978','si2989'],
isDD:false
},
si2954c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2954,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2954',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2967:{
name:'',
type:612,
from:4143,
to:4504,
rp:0,
rpa:0,
mdi:'si2967c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2954',
stl:[{
stn:'Normal',
stt:0,
stsi:[2967]
}
]
,
stis:0,
bstiid:2954,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2954,
isDD:false
},
si2967c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2967,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2967',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2978:{
name:'',
type:612,
from:4143,
to:4504,
rp:0,
rpa:0,
mdi:'si2978c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2954',
stl:[{
stn:'Normal',
stt:0,
stsi:[2978]
}
]
,
stis:0,
bstiid:2954,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2954,
isDD:false
},
si2978c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2978,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2978',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2989:{
name:'',
type:612,
from:4143,
to:4504,
rp:0,
rpa:0,
mdi:'si2989c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2954',
stl:[{
stn:'Normal',
stt:0,
stsi:[2989]
}
]
,
stis:0,
bstiid:2954,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2954,
isDD:false
},
si2989c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2989,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2989',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2924:{
name:'InputField_1',
type:2433,
from:4143,
to:4504,
rp:0,
rpa:0,
mdi:'si2924c',
tag:'slide-item-inputfield',
v:0,
enabled:true,
defEn:true,
vu:[2952,2953],
siaf:0,
sid:12.1,
presetData:[{
presetId:'',
presetType:12,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"active":true,"disabled":false,"focusLost":true,"error":true},"scaleValue":"medium","isTextActive":true,"currentState":"normal","inputFieldProps":{"answersList":[],"enableCaseSensitive":true,"enableMultipleLine":false,"selectedInputFieldType":0},"normal":{"opacity":100,"editorState":{"blocks":[{"key":"b8cpv","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"hlnkt:wp"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"hlnke:true"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"hlnk:"},{"offset":0,"length":15,"style":"overridden:false"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-inputfield-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"active":{"opacity":100,"editorState":{"blocks":[{"key":"99q49","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"hlnkt:wp"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"hlnke:true"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"hlnk:"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-inputfield-active","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_active","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"disabled":{"opacity":100,"editorState":{"blocks":[{"key":"2vpdq","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"hlnkt:wp"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"hlnke:true"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"hlnk:"},{"offset":0,"length":15,"style":"overridden:false"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-inputfield-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"focusLost":{"opacity":100,"editorState":{"blocks":[{"key":"4kirv","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"hlnkt:wp"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"hlnke:true"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"hlnk:"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-inputfield-focusLost","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_focusLost","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"error":{"opacity":100,"editorState":{"blocks":[{"key":"cfvur","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"hlnkt:wp"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"hlnke:true"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"hlnk:"},{"offset":0,"length":15,"style":"overridden:false"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-inputfield-error","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_error","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"sizeNPos":{"left":20,"top":830,"width":165},"designOption":"DEFAULT_INPUTFIELD_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"8"}},"size":{"small":{"desktop":{"textFontSize":16,"paddingSelectContainer":"9px 20px 6px 14px"},"tablet":{"textFontSize":18,"paddingSelectContainer":"12px 20px 8px 16px"},"mobile":{"textFontSize":18,"paddingSelectContainer":"12px 20px 8px 16px"}},"medium":{"desktop":{"textFontSize":20,"paddingSelectContainer":"11px 20px 8px 14px"},"tablet":{"textFontSize":22,"paddingSelectContainer":"14px 20px 10px 16px"},"mobile":{"textFontSize":22,"paddingSelectContainer":"14px 20px 10px 16px"}},"large":{"desktop":{"textFontSize":24,"paddingSelectContainer":"13px 20px 10px 14px"},"tablet":{"textFontSize":26,"paddingSelectContainer":"15px 20px 11px 16px"},"mobile":{"textFontSize":26,"paddingSelectContainer":"15px 20px 11px 16px"}}},"inputfieldHeight":"0px"}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ifml:0,
ifcs:0,
ifst:0,
sz:1,
ifal:[''],
si:[]
,
te:true,
ie:false,
lcapid:'si2954',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2924]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2924c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2924,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2924',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3116:{
name:'Rectangle_21',
type:612,
from:10539,
to:10900,
rp:0,
rpa:0,
mdi:'si3116c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.1,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:3127,
stt:0,
dsr:'Default_State',
stsi:[3116]
}
,{
stn:3139,
stt:102,
dsr:'Failure',
stsi:[3140]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si3116','si3129','si3140','si3151'],
isDD:false
},
si3116c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:3116,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3116',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3129:{
name:'',
type:612,
from:10539,
to:10900,
rp:0,
rpa:0,
mdi:'si3129c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3116',
stl:[{
stn:'Normal',
stt:0,
stsi:[3129]
}
]
,
stis:0,
bstiid:3116,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3116,
isDD:false
},
si3129c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:3129,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3129',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3140:{
name:'',
type:612,
from:10539,
to:10900,
rp:0,
rpa:0,
mdi:'si3140c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3116',
stl:[{
stn:'Normal',
stt:0,
stsi:[3140]
}
]
,
stis:0,
bstiid:3116,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3116,
isDD:false
},
si3140c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:3140,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3140',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3151:{
name:'',
type:612,
from:10539,
to:10900,
rp:0,
rpa:0,
mdi:'si3151c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3116',
stl:[{
stn:'Normal',
stt:0,
stsi:[3151]
}
]
,
stis:0,
bstiid:3116,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3116,
isDD:false
},
si3151c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:3151,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3151',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3168:{
name:'Instructions_1',
type:612,
from:10901,
to:11262,
rp:0,
rpa:0,
mdi:'si3168c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"ae35r","text":"Type instruction here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":21,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":21,"style":"hlnkt:wp"},{"offset":0,"length":21,"style":"textOutlineEnable:false"},{"offset":0,"length":21,"style":"opacity:1"},{"offset":0,"length":21,"style":"textShadowColor:ffffff00"},{"offset":0,"length":21,"style":"hlnke:true"},{"offset":0,"length":21,"style":"backgroundColor:unset"},{"offset":0,"length":21,"style":"textShadowX:0px"},{"offset":0,"length":21,"style":"textShadowY:0px"},{"offset":0,"length":21,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":21,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":21,"style":"textShadowBlur:0px"},{"offset":0,"length":21,"style":"textHighlightEnable:false"},{"offset":0,"length":21,"style":"textShadowEnable:false"},{"offset":0,"length":21,"style":"hlnk:"},{"offset":0,"length":21,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":20,"top":24,"width":320},"shouldRender":true}',
parentGroup:'si454',
retainState:false,
immo:false,
apsn:'Slide436',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3168]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3168c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3168,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3168',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide436:{
lb:'Simulation slide 1',
id:436,
from:10901,
to:11262,
iols:0,
i360qs:false,
sdu:12.1,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide436c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si462',
t:1268
}
]
,
iph:[]
,
oa:'si2135Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
546:{
ts:''
}
,
3166:{
ts:''
}

}

},
Slide436c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:436,
dn:'Slide436',
visible:'1'
},
si579:{
name:'Simulation_2',
type:1268,
from:11263,
to:11340,
rp:0,
rpa:0,
mdi:'si579c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide553',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si571',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si579c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:579,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si579',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si571:{
name:'Simulation_non_responsive_2',
type:1268,
from:11263,
to:11340,
rp:0,
rpa:0,
mdi:'si571c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si579',
retainState:false,
immo:false,
apsn:'Slide553',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2251',
t:612
}
,{
n:'si2231',
t:1269
}
,{
n:'si2999',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si579',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si571c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:571,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si571',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:587,
tsp:50,
ip:'dr/0587.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2251:{
name:'Rectangle_13',
type:612,
from:363,
to:440,
rp:0,
rpa:0,
mdi:'si2251c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.6,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si571',
retainState:false,
immo:false,
apsn:'Slide553',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2262,
stt:0,
dsr:'Default_State',
stsi:[2251]
}
,{
stn:2274,
stt:102,
dsr:'Failure',
stsi:[2275]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2251','si2264','si2275','si2286'],
isDD:false
},
si2251c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2251,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2251',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2264:{
name:'',
type:612,
from:363,
to:440,
rp:0,
rpa:0,
mdi:'si2264c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si571',
retainState:false,
immo:false,
apsn:'Slide553',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2251',
stl:[{
stn:'Normal',
stt:0,
stsi:[2264]
}
]
,
stis:0,
bstiid:2251,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2251,
isDD:false
},
si2264c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2264,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2264',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2275:{
name:'',
type:612,
from:363,
to:440,
rp:0,
rpa:0,
mdi:'si2275c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si571',
retainState:false,
immo:false,
apsn:'Slide553',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2251',
stl:[{
stn:'Normal',
stt:0,
stsi:[2275]
}
]
,
stis:0,
bstiid:2251,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2251,
isDD:false
},
si2275c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2275,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2275',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2286:{
name:'',
type:612,
from:363,
to:440,
rp:0,
rpa:0,
mdi:'si2286c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si571',
retainState:false,
immo:false,
apsn:'Slide553',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2251',
stl:[{
stn:'Normal',
stt:0,
stsi:[2286]
}
]
,
stis:0,
bstiid:2251,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2251,
isDD:false
},
si2286c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2286,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2286',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2231:{
name:'Click_box_12',
type:1269,
from:363,
to:440,
rp:0,
rpa:0,
mdi:'si2231c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.6,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":1186.2139465547702,"top":593.8375110424029,"width":64,"height":64},"shouldRender":true,"attempts":1024}',
parentGroup:'si571',
retainState:false,
immo:false,
apsn:'Slide553',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2304);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1,
pa:-1,
lcapid:'si2251',
si:[{
n:'si2241',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2231]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2231c:{
b:[1352,24,1416,88],
fh:false,
fw:false,
uid:2231,
iso:false,
css:{
360:{
l:'139.095%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'139.095%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'139.095%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'139.095%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'139.095%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'139.095%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2231',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1352,24,1416,88],
vb:[1352,24,1416,88]
},
si2241:{
name:'Shape_13',
type:612,
from:363,
to:440,
rp:0,
rpa:0,
mdi:'si2241c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide553',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2241]
}
]
,
stis:0,
bstiid:2231,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2231',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2241c:{
b:[0,0,64,64],
fh:false,
fw:false,
uid:2241,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2241',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,66,66],
vb:[-2,-2,66,66]
},
si2999:{
name:'Mouse_21',
type:12,
from:11263,
to:11340,
rp:0,
rpa:0,
mdi:'si2999c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.6,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":1348.2451965547702,"mouseStartPointY":182.76788869257945,"mouseEndPointX":1223.3280145759716,"mouseEndPointY":620.6750772968197}}',
parentGroup:'si571',
retainState:false,
immo:false,
apsn:'Slide553',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2999Ad',
trin:0,
trout:0,
isDD:false
},
si2999c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2999,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2999',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2999Ad:{
src:'ar/Mouse.mp3',
from:11263,
to:11268,
del:2.418,
msa:1,
du:0.182
},
Slide553:{
lb:'Simulation slide 2',
id:553,
from:11263,
to:11340,
iols:0,
i360qs:false,
sdu:2.6,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide553c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si579',
t:1268
}
]
,
iph:[]
,
oa:'si2999Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2304:{
ts:''
}

}

},
Slide553c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:553,
dn:'Slide553',
visible:'1'
},
si616:{
name:'Simulation_3',
type:1268,
from:11341,
to:11409,
rp:0,
rpa:0,
mdi:'si616c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide590',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si608',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si616c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:616,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si616',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si608:{
name:'Simulation_non_responsive_3',
type:1268,
from:11341,
to:11409,
rp:0,
rpa:0,
mdi:'si608c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":1,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si616',
retainState:false,
immo:false,
apsn:'Slide590',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si627',
t:1269
}
,{
n:'si647',
t:612
}
,{
n:'si2331',
t:612
}
,{
n:'si2311',
t:1269
}
,{
n:'si2391',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":1,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si616',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si608c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:608,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si608',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:624,
tsp:50,
ip:'dr/0624.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si627:{
name:'Click_box_2',
type:1269,
from:441,
to:509,
rp:0,
rpa:0,
mdi:'si627c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":590.358546819788,"left":1201.6494589222616,"width":34,"height":66.9753003878644},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si608',
retainState:false,
immo:false,
apsn:'Slide590',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(700);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:2.274,
lcapid:'si647',
si:[{
n:'si637',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[627]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si627c:{
b:[1325,175,1359,195],
fh:false,
fw:false,
uid:627,
iso:false,
css:{
360:{
l:'136.317%',
t:'28.783%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'136.317%',
lhID:-1,
lvEID:0,
lvV:'28.783%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'136.317%',
t:'28.783%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'136.317%',
lhID:-1,
lvEID:0,
lvV:'28.783%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'136.317%',
t:'28.783%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'136.317%',
lhID:-1,
lvEID:0,
lvV:'28.783%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si627',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1325,175,1359,195],
vb:[1325,175,1359,195]
},
si637:{
name:'Shape_2',
type:612,
from:441,
to:509,
rp:0,
rpa:0,
mdi:'si637c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide590',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[637]
}
]
,
stis:0,
bstiid:627,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si627',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si637c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:637,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si637',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si647:{
name:'Rectangle_2',
type:612,
from:441,
to:509,
rp:0,
rpa:0,
mdi:'si647c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":235,"left":1010,"width":300,"height":"auto"}}',
parentGroup:'si608',
retainState:false,
immo:false,
apsn:'Slide590',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:658,
stt:0,
dsr:'Default_State',
stsi:[647]
}
,{
stn:670,
stt:102,
dsr:'Failure',
stsi:[671]
}
,{
stn:681,
stt:103,
dsr:'Hint',
stsi:[682]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si647','si660','si671','si682'],
isDD:false
},
si647c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:647,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si647',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si660:{
name:'',
type:612,
from:441,
to:509,
rp:0,
rpa:0,
mdi:'si660c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":235,"left":1010,"width":300,"height":"auto"}}',
parentGroup:'si608',
retainState:false,
immo:false,
apsn:'Slide590',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si647',
stl:[{
stn:'Normal',
stt:0,
stsi:[660]
}
]
,
stis:0,
bstiid:647,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:647,
isDD:false
},
si660c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:660,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si660',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si671:{
name:'',
type:612,
from:441,
to:509,
rp:0,
rpa:0,
mdi:'si671c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":235,"left":1010,"width":300,"height":"auto"}}',
parentGroup:'si608',
retainState:false,
immo:false,
apsn:'Slide590',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si647',
stl:[{
stn:'Normal',
stt:0,
stsi:[671]
}
]
,
stis:0,
bstiid:647,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:647,
isDD:false
},
si671c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:671,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si671',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si682:{
name:'',
type:612,
from:441,
to:509,
rp:0,
rpa:0,
mdi:'si682c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":235,"left":1010,"width":300,"height":"auto"}}',
parentGroup:'si608',
retainState:false,
immo:false,
apsn:'Slide590',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si647',
stl:[{
stn:'Normal',
stt:0,
stsi:[682]
}
]
,
stis:0,
bstiid:647,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:647,
isDD:false
},
si682c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:682,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si682',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2331:{
name:'Rectangle_14',
type:612,
from:441,
to:509,
rp:0,
rpa:0,
mdi:'si2331c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si608',
retainState:false,
immo:false,
apsn:'Slide590',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2342,
stt:0,
dsr:'Default_State',
stsi:[2331]
}
,{
stn:2354,
stt:102,
dsr:'Failure',
stsi:[2355]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2331','si2344','si2355','si2366'],
isDD:false
},
si2331c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2331,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2331',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2344:{
name:'',
type:612,
from:441,
to:509,
rp:0,
rpa:0,
mdi:'si2344c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si608',
retainState:false,
immo:false,
apsn:'Slide590',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2331',
stl:[{
stn:'Normal',
stt:0,
stsi:[2344]
}
]
,
stis:0,
bstiid:2331,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2331,
isDD:false
},
si2344c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2344,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2344',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2355:{
name:'',
type:612,
from:441,
to:509,
rp:0,
rpa:0,
mdi:'si2355c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si608',
retainState:false,
immo:false,
apsn:'Slide590',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2331',
stl:[{
stn:'Normal',
stt:0,
stsi:[2355]
}
]
,
stis:0,
bstiid:2331,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2331,
isDD:false
},
si2355c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2355,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2355',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2366:{
name:'',
type:612,
from:441,
to:509,
rp:0,
rpa:0,
mdi:'si2366c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si608',
retainState:false,
immo:false,
apsn:'Slide590',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2331',
stl:[{
stn:'Normal',
stt:0,
stsi:[2366]
}
]
,
stis:0,
bstiid:2331,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2331,
isDD:false
},
si2366c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2366,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2366',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2311:{
name:'Highlight_box_2',
type:1269,
from:9156,
to:9224,
rp:0,
rpa:0,
mdi:'si2311c',
tag:'slide-item-highlight-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":1193.0023741166078,"top":589.5435622791518,"width":51.710796019213774,"height":66.8727214260573},"shouldRender":true}',
parentGroup:'si608',
retainState:false,
immo:false,
apsn:'Slide590',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ihb:true,
si:[{
n:'si2321',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2311]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2311c:{
b:[1132,24,1260,56],
fh:false,
fw:false,
uid:2311,
iso:false,
css:{
360:{
l:'116.461%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'116.461%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'116.461%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'116.461%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'116.461%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'116.461%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2311',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[1132,24,1260,56],
vb:[1132,24,1260,56]
},
si2321:{
name:'Shape_14',
type:612,
from:9156,
to:9224,
rp:0,
rpa:0,
mdi:'si2321c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide590',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2321]
}
]
,
stis:0,
bstiid:2311,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2311',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2321c:{
b:[0,0,128,32],
fh:false,
fw:false,
uid:2321,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2321',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,130,34],
vb:[-2,-2,130,34]
},
si2391:{
name:'Mouse_2',
type:12,
from:5014,
to:5082,
rp:0,
rpa:0,
mdi:'si2391c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.3,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":1223.3280145759716,"mouseStartPointY":620.6750772968197,"mouseEndPointX":16,"mouseEndPointY":16}}',
parentGroup:'si608',
retainState:false,
immo:false,
apsn:'Slide590',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2391Ad',
trin:0,
trout:0,
isDD:false
},
si2391c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2391,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2391',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2391Ad:{
src:'ar/Mouse.mp3',
from:5014,
to:5019,
del:2.118,
msa:1,
du:0.182
},
Slide590:{
lb:'Simulation slide 3',
id:590,
from:11341,
to:11409,
iols:0,
i360qs:false,
sdu:2.3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide590c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si616',
t:1268
}
]
,
iph:[]
,
oa:'si2391Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
700:{
ts:''
}

}

},
Slide590c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:590,
dn:'Slide590',
visible:'1'
},
si733:{
name:'Simulation_4',
type:1268,
from:12120,
to:12510,
rp:0,
rpa:0,
mdi:'si733c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide707',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si725',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si733c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:733,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si733',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si725:{
name:'Simulation_non_responsive_4',
type:1268,
from:12120,
to:12510,
rp:0,
rpa:0,
mdi:'si725c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":1,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si733',
retainState:false,
immo:false,
apsn:'Slide707',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si744',
t:1269
}
,{
n:'si764',
t:612
}
,{
n:'si2398',
t:12
}
,{
n:'si3026',
t:612
}
,{
n:'si3006',
t:1269
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":1,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si733',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si725c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:725,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si725',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:741,
tsp:50,
ip:'dr/0741.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si744:{
name:'Click_box_3',
type:1269,
from:510,
to:900,
rp:0,
rpa:0,
mdi:'si744c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":250.66320671378094,"left":331.77087014134275,"width":169.7838449646643,"height":172.37584413993483},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si725',
retainState:false,
immo:false,
apsn:'Slide707',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(817);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:13.003,
lcapid:'si764',
si:[{
n:'si754',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[744]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si744c:{
b:[382,326,416,346],
fh:false,
fw:false,
uid:744,
iso:false,
css:{
360:{
l:'39.300%',
t:'53.618%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'39.300%',
lhID:-1,
lvEID:0,
lvV:'53.618%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'39.300%',
t:'53.618%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'39.300%',
lhID:-1,
lvEID:0,
lvV:'53.618%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'39.300%',
t:'53.618%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'39.300%',
lhID:-1,
lvEID:0,
lvV:'53.618%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si744',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[382,326,416,346],
vb:[382,326,416,346]
},
si754:{
name:'Shape_3',
type:612,
from:510,
to:900,
rp:0,
rpa:0,
mdi:'si754c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide707',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[754]
}
]
,
stis:0,
bstiid:744,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si744',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si754c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:754,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si754',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si764:{
name:'Rectangle_3',
type:612,
from:510,
to:900,
rp:0,
rpa:0,
mdi:'si764c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":386,"left":397,"width":300,"height":"auto"}}',
parentGroup:'si725',
retainState:false,
immo:false,
apsn:'Slide707',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:775,
stt:0,
dsr:'Default_State',
stsi:[764]
}
,{
stn:787,
stt:102,
dsr:'Failure',
stsi:[788]
}
,{
stn:798,
stt:103,
dsr:'Hint',
stsi:[799]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si764','si777','si788','si799'],
isDD:false
},
si764c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:764,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si764',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si777:{
name:'',
type:612,
from:510,
to:900,
rp:0,
rpa:0,
mdi:'si777c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":386,"left":397,"width":300,"height":"auto"}}',
parentGroup:'si725',
retainState:false,
immo:false,
apsn:'Slide707',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si764',
stl:[{
stn:'Normal',
stt:0,
stsi:[777]
}
]
,
stis:0,
bstiid:764,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:764,
isDD:false
},
si777c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:777,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si777',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si788:{
name:'',
type:612,
from:510,
to:900,
rp:0,
rpa:0,
mdi:'si788c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":386,"left":397,"width":300,"height":"auto"}}',
parentGroup:'si725',
retainState:false,
immo:false,
apsn:'Slide707',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si764',
stl:[{
stn:'Normal',
stt:0,
stsi:[788]
}
]
,
stis:0,
bstiid:764,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:764,
isDD:false
},
si788c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:788,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si788',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si799:{
name:'',
type:612,
from:510,
to:900,
rp:0,
rpa:0,
mdi:'si799c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":386,"left":397,"width":300,"height":"auto"}}',
parentGroup:'si725',
retainState:false,
immo:false,
apsn:'Slide707',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si764',
stl:[{
stn:'Normal',
stt:0,
stsi:[799]
}
]
,
stis:0,
bstiid:764,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:764,
isDD:false
},
si799c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:799,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si799',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2398:{
name:'Mouse_3',
type:12,
from:12120,
to:12510,
rp:0,
rpa:0,
mdi:'si2398c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":1223.3280145759716,"mouseStartPointY":620.6750772968197,"mouseEndPointX":397.5909341872791,"mouseEndPointY":374.62273630742044}}',
parentGroup:'si725',
retainState:false,
immo:false,
apsn:'Slide707',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2398Ad',
trin:0,
trout:0,
isDD:false
},
si2398c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2398,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2398',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2398Ad:{
src:'ar/Mouse.mp3',
from:12120,
to:12125,
del:12.818,
msa:1,
du:0.182
},
si3026:{
name:'Rectangle_20',
type:612,
from:9225,
to:9615,
rp:0,
rpa:0,
mdi:'si3026c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si725',
retainState:false,
immo:false,
apsn:'Slide707',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:3037,
stt:0,
dsr:'Default_State',
stsi:[3026]
}
,{
stn:3049,
stt:102,
dsr:'Failure',
stsi:[3050]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si3026','si3039','si3050','si3061'],
isDD:false
},
si3026c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:3026,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3026',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3039:{
name:'',
type:612,
from:9225,
to:9615,
rp:0,
rpa:0,
mdi:'si3039c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si725',
retainState:false,
immo:false,
apsn:'Slide707',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3026',
stl:[{
stn:'Normal',
stt:0,
stsi:[3039]
}
]
,
stis:0,
bstiid:3026,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3026,
isDD:false
},
si3039c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:3039,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3039',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3050:{
name:'',
type:612,
from:9225,
to:9615,
rp:0,
rpa:0,
mdi:'si3050c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si725',
retainState:false,
immo:false,
apsn:'Slide707',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3026',
stl:[{
stn:'Normal',
stt:0,
stsi:[3050]
}
]
,
stis:0,
bstiid:3026,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3026,
isDD:false
},
si3050c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:3050,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3050',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3061:{
name:'',
type:612,
from:9225,
to:9615,
rp:0,
rpa:0,
mdi:'si3061c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si725',
retainState:false,
immo:false,
apsn:'Slide707',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3026',
stl:[{
stn:'Normal',
stt:0,
stsi:[3061]
}
]
,
stis:0,
bstiid:3026,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3026,
isDD:false
},
si3061c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:3061,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3061',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3006:{
name:'Highlight_box_3',
type:1269,
from:9225,
to:9615,
rp:0,
rpa:0,
mdi:'si3006c',
tag:'slide-item-highlight-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":329.6346621024735,"top":257.4919390459364,"width":166.85545149624556,"height":168.45870270745914},"shouldRender":true}',
parentGroup:'si725',
retainState:false,
immo:false,
apsn:'Slide707',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ihb:true,
si:[{
n:'si3016',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3006]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3006c:{
b:[1132,24,1260,56],
fh:false,
fw:false,
uid:3006,
iso:false,
css:{
360:{
l:'116.461%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'116.461%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'116.461%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'116.461%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'116.461%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'116.461%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3006',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[1132,24,1260,56],
vb:[1132,24,1260,56]
},
si3016:{
name:'Shape_19',
type:612,
from:9225,
to:9615,
rp:0,
rpa:0,
mdi:'si3016c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide707',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3016]
}
]
,
stis:0,
bstiid:3006,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si3006',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si3016c:{
b:[0,0,128,32],
fh:false,
fw:false,
uid:3016,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3016',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,130,34],
vb:[-2,-2,130,34]
},
Slide707:{
lb:'Simulation slide 4',
id:707,
from:12120,
to:12510,
iols:0,
i360qs:false,
sdu:13,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide707c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si733',
t:1268
}
]
,
iph:[]
,
oa:'si2398Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
817:{
ts:''
}

}

},
Slide707c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:707,
dn:'Slide707',
visible:'1'
},
si850:{
name:'Simulation_5',
type:1268,
from:12511,
to:12734,
rp:0,
rpa:0,
mdi:'si850c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.5,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide824',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si842',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si850c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:850,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si850',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si842:{
name:'Simulation_non_responsive_5',
type:1268,
from:12511,
to:12734,
rp:0,
rpa:0,
mdi:'si842c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.5,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si850',
retainState:false,
immo:false,
apsn:'Slide824',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2425',
t:612
}
,{
n:'si2405',
t:1269
}
,{
n:'si2485',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si850',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si842c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:842,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si842',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:858,
tsp:50,
ip:'dr/0858.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2425:{
name:'Rectangle_15',
type:612,
from:901,
to:1124,
rp:0,
rpa:0,
mdi:'si2425c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.5,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si842',
retainState:false,
immo:false,
apsn:'Slide824',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2436,
stt:0,
dsr:'Default_State',
stsi:[2425]
}
,{
stn:2448,
stt:102,
dsr:'Failure',
stsi:[2449]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2425','si2438','si2449','si2460'],
isDD:false
},
si2425c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2425,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2425',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2438:{
name:'',
type:612,
from:901,
to:1124,
rp:0,
rpa:0,
mdi:'si2438c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si842',
retainState:false,
immo:false,
apsn:'Slide824',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2425',
stl:[{
stn:'Normal',
stt:0,
stsi:[2438]
}
]
,
stis:0,
bstiid:2425,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2425,
isDD:false
},
si2438c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2438,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2438',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2449:{
name:'',
type:612,
from:901,
to:1124,
rp:0,
rpa:0,
mdi:'si2449c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si842',
retainState:false,
immo:false,
apsn:'Slide824',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2425',
stl:[{
stn:'Normal',
stt:0,
stsi:[2449]
}
]
,
stis:0,
bstiid:2425,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2425,
isDD:false
},
si2449c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2449,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2449',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2460:{
name:'',
type:612,
from:901,
to:1124,
rp:0,
rpa:0,
mdi:'si2460c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si842',
retainState:false,
immo:false,
apsn:'Slide824',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2425',
stl:[{
stn:'Normal',
stt:0,
stsi:[2460]
}
]
,
stis:0,
bstiid:2425,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2425,
isDD:false
},
si2460c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2460,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2460',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2405:{
name:'Click_box_13',
type:1269,
from:901,
to:1124,
rp:0,
rpa:0,
mdi:'si2405c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.5,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":1352,"top":24,"width":64,"height":64},"shouldRender":true,"attempts":1024}',
parentGroup:'si842',
retainState:false,
immo:false,
apsn:'Slide824',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2478);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1,
pa:-1,
lcapid:'si2425',
si:[{
n:'si2415',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2405]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2405c:{
b:[1352,24,1416,88],
fh:false,
fw:false,
uid:2405,
iso:false,
css:{
360:{
l:'139.095%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'139.095%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'139.095%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'139.095%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'139.095%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'139.095%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2405',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1352,24,1416,88],
vb:[1352,24,1416,88]
},
si2415:{
name:'Shape_15',
type:612,
from:901,
to:1124,
rp:0,
rpa:0,
mdi:'si2415c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide824',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2415]
}
]
,
stis:0,
bstiid:2405,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2405',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2415c:{
b:[0,0,64,64],
fh:false,
fw:false,
uid:2415,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2415',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,66,66],
vb:[-2,-2,66,66]
},
si2485:{
name:'Mouse_4',
type:12,
from:12511,
to:12734,
rp:0,
rpa:0,
mdi:'si2485c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.5,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":397.5909341872791,"mouseStartPointY":374.62273630742044,"mouseEndPointX":16,"mouseEndPointY":16}}',
parentGroup:'si842',
retainState:false,
immo:false,
apsn:'Slide824',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2485Ad',
trin:0,
trout:0,
isDD:false
},
si2485c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2485,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2485',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2485Ad:{
src:'ar/Mouse.mp3',
from:12511,
to:12516,
del:7.318,
msa:1,
du:0.182
},
Slide824:{
lb:'Simulation slide 5',
id:824,
from:12511,
to:12734,
iols:0,
i360qs:false,
sdu:7.5,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide824c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si850',
t:1268
}
]
,
iph:[]
,
oa:'si2485Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2478:{
ts:''
}

}

},
Slide824c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:824,
dn:'Slide824',
visible:'1'
},
si887:{
name:'Simulation_6',
type:1268,
from:12735,
to:12801,
rp:0,
rpa:0,
mdi:'si887c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide861',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si879',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si887c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:887,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si887',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si879:{
name:'Simulation_non_responsive_6',
type:1268,
from:12735,
to:12801,
rp:0,
rpa:0,
mdi:'si879c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si887',
retainState:false,
immo:false,
apsn:'Slide861',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2512',
t:612
}
,{
n:'si2492',
t:1269
}
,{
n:'si2572',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si887',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si879c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:879,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si879',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:895,
tsp:50,
ip:'dr/0895.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2512:{
name:'Rectangle_16',
type:612,
from:1125,
to:1191,
rp:0,
rpa:0,
mdi:'si2512c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.2,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si879',
retainState:false,
immo:false,
apsn:'Slide861',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2523,
stt:0,
dsr:'Default_State',
stsi:[2512]
}
,{
stn:2535,
stt:102,
dsr:'Failure',
stsi:[2536]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2512','si2525','si2536','si2547'],
isDD:false
},
si2512c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2512,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2512',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2525:{
name:'',
type:612,
from:1125,
to:1191,
rp:0,
rpa:0,
mdi:'si2525c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si879',
retainState:false,
immo:false,
apsn:'Slide861',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2512',
stl:[{
stn:'Normal',
stt:0,
stsi:[2525]
}
]
,
stis:0,
bstiid:2512,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2512,
isDD:false
},
si2525c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2525,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2525',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2536:{
name:'',
type:612,
from:1125,
to:1191,
rp:0,
rpa:0,
mdi:'si2536c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si879',
retainState:false,
immo:false,
apsn:'Slide861',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2512',
stl:[{
stn:'Normal',
stt:0,
stsi:[2536]
}
]
,
stis:0,
bstiid:2512,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2512,
isDD:false
},
si2536c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2536,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2536',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2547:{
name:'',
type:612,
from:1125,
to:1191,
rp:0,
rpa:0,
mdi:'si2547c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si879',
retainState:false,
immo:false,
apsn:'Slide861',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2512',
stl:[{
stn:'Normal',
stt:0,
stsi:[2547]
}
]
,
stis:0,
bstiid:2512,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2512,
isDD:false
},
si2547c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2547,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2547',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2492:{
name:'Click_box_14',
type:1269,
from:1125,
to:1191,
rp:0,
rpa:0,
mdi:'si2492c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.2,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":1352,"top":24,"width":64,"height":64},"shouldRender":true,"attempts":1024}',
parentGroup:'si879',
retainState:false,
immo:false,
apsn:'Slide861',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2565);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1,
pa:-1,
lcapid:'si2512',
si:[{
n:'si2502',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2492]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2492c:{
b:[1352,24,1416,88],
fh:false,
fw:false,
uid:2492,
iso:false,
css:{
360:{
l:'139.095%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'139.095%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'139.095%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'139.095%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'139.095%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'139.095%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2492',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1352,24,1416,88],
vb:[1352,24,1416,88]
},
si2502:{
name:'Shape_16',
type:612,
from:1125,
to:1191,
rp:0,
rpa:0,
mdi:'si2502c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide861',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2502]
}
]
,
stis:0,
bstiid:2492,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2492',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2502c:{
b:[0,0,64,64],
fh:false,
fw:false,
uid:2502,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2502',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,66,66],
vb:[-2,-2,66,66]
},
si2572:{
name:'Mouse_5',
type:12,
from:12735,
to:12801,
rp:0,
rpa:0,
mdi:'si2572c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.2,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":397.5909341872791,"mouseStartPointY":374.6227363074205,"mouseEndPointX":1235.674801236749,"mouseEndPointY":318.0649293286219}}',
parentGroup:'si879',
retainState:false,
immo:false,
apsn:'Slide861',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2572Ad',
trin:0,
trout:0,
isDD:false
},
si2572c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2572,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2572',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2572Ad:{
src:'ar/Mouse.mp3',
from:12735,
to:12740,
del:2.018,
msa:1,
du:0.182
},
Slide861:{
lb:'Simulation slide 6',
id:861,
from:12735,
to:12801,
iols:0,
i360qs:false,
sdu:2.2,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide861c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si887',
t:1268
}
]
,
iph:[]
,
oa:'si2572Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2565:{
ts:''
}

}

},
Slide861c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:861,
dn:'Slide861',
visible:'1'
},
si924:{
name:'Simulation_7',
type:1268,
from:12802,
to:12839,
rp:0,
rpa:0,
mdi:'si924c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide898',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si916',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si924c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:924,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si924',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si916:{
name:'Simulation_non_responsive_7',
type:1268,
from:12802,
to:12839,
rp:0,
rpa:0,
mdi:'si916c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si924',
retainState:false,
immo:false,
apsn:'Slide898',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2579',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si924',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si916c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:916,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si916',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:932,
tsp:50,
ip:'dr/0932.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2579:{
name:'Mouse_6',
type:12,
from:12802,
to:12839,
rp:0,
rpa:0,
mdi:'si2579c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.2,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":1235.674801236749,"mouseStartPointY":318.0649293286219,"mouseEndPointX":1364.8985203180212,"mouseEndPointY":305.7250441696113}}',
parentGroup:'si916',
retainState:false,
immo:false,
apsn:'Slide898',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2579Ad',
trin:0,
trout:0,
isDD:false
},
si2579c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2579,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2579',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2579Ad:{
src:'ar/Mouse.mp3',
from:12802,
to:12807,
del:1.018,
msa:1,
du:0.182
},
Slide898:{
lb:'Simulation slide 7',
id:898,
from:12802,
to:12839,
iols:0,
i360qs:false,
sdu:1.2,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide898c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si924',
t:1268
}
]
,
iph:[]
,
oa:'si2579Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide898c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:898,
dn:'Slide898',
visible:'1'
},
si961:{
name:'Simulation_8',
type:1268,
from:12840,
to:12898,
rp:0,
rpa:0,
mdi:'si961c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide935',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si953',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si961c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:961,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si961',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si953:{
name:'Simulation_non_responsive_8',
type:1268,
from:12840,
to:12898,
rp:0,
rpa:0,
mdi:'si953c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si961',
retainState:false,
immo:false,
apsn:'Slide935',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2586',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si961',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si953c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:953,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si953',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:969,
tsp:50,
ip:'dr/0969.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2586:{
name:'Mouse_7',
type:12,
from:12840,
to:12898,
rp:0,
rpa:0,
mdi:'si2586c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":1364.8985203180212,"mouseStartPointY":305.7250441696113,"mouseEndPointX":1237.5036992049468,"mouseEndPointY":397.2458590989399}}',
parentGroup:'si953',
retainState:false,
immo:false,
apsn:'Slide935',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2586Ad',
trin:0,
trout:0,
isDD:false
},
si2586c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2586,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2586',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2586Ad:{
src:'ar/Mouse.mp3',
from:12840,
to:12845,
del:1.818,
msa:1,
du:0.182
},
Slide935:{
lb:'Simulation slide 8',
id:935,
from:12840,
to:12898,
iols:0,
i360qs:false,
sdu:2,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide935c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si961',
t:1268
}
]
,
iph:[]
,
oa:'si2586Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide935c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:935,
dn:'Slide935',
visible:'1'
},
si998:{
name:'Simulation_9',
type:1268,
from:12899,
to:13217,
rp:0,
rpa:0,
mdi:'si998c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide972',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si990',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si998c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:998,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si998',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si990:{
name:'Simulation_non_responsive_9',
type:1268,
from:12899,
to:13217,
rp:0,
rpa:0,
mdi:'si990c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si998',
retainState:false,
immo:false,
apsn:'Slide972',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1009',
t:1269
}
,{
n:'si1029',
t:612
}
,{
n:'si2593',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si998',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si990c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:990,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si990',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:1006,
tsp:50,
ip:'dr/01006.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1009:{
name:'Click_box_4',
type:1269,
from:1289,
to:1607,
rp:0,
rpa:0,
mdi:'si1009c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.6,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":482.8073652826855,"left":1188.313769876325,"width":108.30192431123011,"height":75.65550248108988},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si990',
retainState:false,
immo:false,
apsn:'Slide972',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1082);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:10.619,
lcapid:'si1029',
si:[{
n:'si1019',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1009]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1009c:{
b:[1222,511,1256,531],
fh:false,
fw:false,
uid:1009,
iso:false,
css:{
360:{
l:'125.720%',
t:'84.046%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'125.720%',
lhID:-1,
lvEID:0,
lvV:'84.046%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'125.720%',
t:'84.046%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'125.720%',
lhID:-1,
lvEID:0,
lvV:'84.046%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'125.720%',
t:'84.046%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'125.720%',
lhID:-1,
lvEID:0,
lvV:'84.046%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1009',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1222,511,1256,531],
vb:[1222,511,1256,531]
},
si1019:{
name:'Shape_4',
type:612,
from:1289,
to:1607,
rp:0,
rpa:0,
mdi:'si1019c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide972',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1019]
}
]
,
stis:0,
bstiid:1009,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1009',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1019c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1019,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1019',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1029:{
name:'Rectangle_4',
type:612,
from:1289,
to:1607,
rp:0,
rpa:0,
mdi:'si1029c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.6,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":571,"left":907,"width":300,"height":"auto"}}',
parentGroup:'si990',
retainState:false,
immo:false,
apsn:'Slide972',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1040,
stt:0,
dsr:'Default_State',
stsi:[1029]
}
,{
stn:1052,
stt:102,
dsr:'Failure',
stsi:[1053]
}
,{
stn:1063,
stt:103,
dsr:'Hint',
stsi:[1064]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1029','si1042','si1053','si1064'],
isDD:false
},
si1029c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1029,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1029',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1042:{
name:'',
type:612,
from:1289,
to:1607,
rp:0,
rpa:0,
mdi:'si1042c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":571,"left":907,"width":300,"height":"auto"}}',
parentGroup:'si990',
retainState:false,
immo:false,
apsn:'Slide972',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1029',
stl:[{
stn:'Normal',
stt:0,
stsi:[1042]
}
]
,
stis:0,
bstiid:1029,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1029,
isDD:false
},
si1042c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1042,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1042',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1053:{
name:'',
type:612,
from:1289,
to:1607,
rp:0,
rpa:0,
mdi:'si1053c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":571,"left":907,"width":300,"height":"auto"}}',
parentGroup:'si990',
retainState:false,
immo:false,
apsn:'Slide972',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1029',
stl:[{
stn:'Normal',
stt:0,
stsi:[1053]
}
]
,
stis:0,
bstiid:1029,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1029,
isDD:false
},
si1053c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1053,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1053',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1064:{
name:'',
type:612,
from:1289,
to:1607,
rp:0,
rpa:0,
mdi:'si1064c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":571,"left":907,"width":300,"height":"auto"}}',
parentGroup:'si990',
retainState:false,
immo:false,
apsn:'Slide972',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1029',
stl:[{
stn:'Normal',
stt:0,
stsi:[1064]
}
]
,
stis:0,
bstiid:1029,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1029,
isDD:false
},
si1064c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1064,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1064',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2593:{
name:'Mouse_8',
type:12,
from:12899,
to:13217,
rp:0,
rpa:0,
mdi:'si2593c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.6,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":1237.5036992049468,"mouseStartPointY":397.2458590989399,"mouseEndPointX":1274.040249558304,"mouseEndPointY":494.5501325088339}}',
parentGroup:'si990',
retainState:false,
immo:false,
apsn:'Slide972',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2593Ad',
trin:0,
trout:0,
isDD:false
},
si2593c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2593,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2593',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2593Ad:{
src:'ar/Mouse.mp3',
from:12899,
to:12904,
del:10.418,
msa:1,
du:0.182
},
Slide972:{
lb:'Simulation slide 9',
id:972,
from:12899,
to:13217,
iols:0,
i360qs:false,
sdu:10.6,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide972c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si998',
t:1268
}
]
,
iph:[]
,
oa:'si2593Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1082:{
ts:''
}

}

},
Slide972c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:972,
dn:'Slide972',
visible:'1'
},
si1115:{
name:'Simulation_10',
type:1268,
from:13218,
to:13363,
rp:0,
rpa:0,
mdi:'si1115c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.9,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1089',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1107',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1115c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1115,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1115',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1107:{
name:'Simulation_non_responsive_10',
type:1268,
from:13218,
to:13363,
rp:0,
rpa:0,
mdi:'si1107c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.9,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1115',
retainState:false,
immo:false,
apsn:'Slide1089',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2620',
t:612
}
,{
n:'si2600',
t:1269
}
,{
n:'si2680',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1115',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1107c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1107,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1107',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:1123,
tsp:50,
ip:'dr/01123.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2620:{
name:'Rectangle_17',
type:612,
from:1608,
to:1753,
rp:0,
rpa:0,
mdi:'si2620c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.9,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si1107',
retainState:false,
immo:false,
apsn:'Slide1089',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2631,
stt:0,
dsr:'Default_State',
stsi:[2620]
}
,{
stn:2643,
stt:102,
dsr:'Failure',
stsi:[2644]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2620','si2633','si2644','si2655'],
isDD:false
},
si2620c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2620,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2620',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2633:{
name:'',
type:612,
from:1608,
to:1753,
rp:0,
rpa:0,
mdi:'si2633c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si1107',
retainState:false,
immo:false,
apsn:'Slide1089',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2620',
stl:[{
stn:'Normal',
stt:0,
stsi:[2633]
}
]
,
stis:0,
bstiid:2620,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2620,
isDD:false
},
si2633c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2633,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2633',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2644:{
name:'',
type:612,
from:1608,
to:1753,
rp:0,
rpa:0,
mdi:'si2644c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si1107',
retainState:false,
immo:false,
apsn:'Slide1089',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2620',
stl:[{
stn:'Normal',
stt:0,
stsi:[2644]
}
]
,
stis:0,
bstiid:2620,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2620,
isDD:false
},
si2644c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2644,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2644',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2655:{
name:'',
type:612,
from:1608,
to:1753,
rp:0,
rpa:0,
mdi:'si2655c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si1107',
retainState:false,
immo:false,
apsn:'Slide1089',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2620',
stl:[{
stn:'Normal',
stt:0,
stsi:[2655]
}
]
,
stis:0,
bstiid:2620,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2620,
isDD:false
},
si2655c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2655,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2655',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2600:{
name:'Click_box_15',
type:1269,
from:1608,
to:1753,
rp:0,
rpa:0,
mdi:'si2600c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.9,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":1352,"top":24,"width":64,"height":64},"shouldRender":true,"attempts":1024}',
parentGroup:'si1107',
retainState:false,
immo:false,
apsn:'Slide1089',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2673);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1,
pa:-1,
lcapid:'si2620',
si:[{
n:'si2610',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2600]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2600c:{
b:[1352,24,1416,88],
fh:false,
fw:false,
uid:2600,
iso:false,
css:{
360:{
l:'139.095%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'139.095%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'139.095%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'139.095%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'139.095%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'139.095%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2600',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1352,24,1416,88],
vb:[1352,24,1416,88]
},
si2610:{
name:'Shape_17',
type:612,
from:1608,
to:1753,
rp:0,
rpa:0,
mdi:'si2610c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1089',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2610]
}
]
,
stis:0,
bstiid:2600,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2600',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2610c:{
b:[0,0,64,64],
fh:false,
fw:false,
uid:2610,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2610',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,66,66],
vb:[-2,-2,66,66]
},
si2680:{
name:'Mouse_9',
type:12,
from:13275,
to:13363,
rp:0,
rpa:0,
mdi:'si2680c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.9,
sid:3,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":1274.040249558304,"mouseStartPointY":494.5501325088339,"mouseEndPointX":592.4479350706713,"mouseEndPointY":387.1006515017667}}',
parentGroup:'si1107',
retainState:false,
immo:false,
apsn:'Slide1089',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2680Ad',
trin:0,
trout:0,
isDD:false
},
si2680c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2680,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2680',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2680Ad:{
src:'ar/Mouse.mp3',
from:13275,
to:13280,
del:4.718,
msa:1,
du:0.182
},
Slide1089:{
lb:'Simulation slide 10',
id:1089,
from:13218,
to:13363,
iols:0,
i360qs:false,
sdu:4.9,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1089c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1115',
t:1268
}
]
,
iph:[]
,
oa:'si2680Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2673:{
ts:''
}

}

},
Slide1089c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1089,
dn:'Slide1089',
visible:'1'
},
si1152:{
name:'Simulation_11',
type:1268,
from:13364,
to:13455,
rp:0,
rpa:0,
mdi:'si1152c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3.1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1126',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1144',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1152c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1152,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1152',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1144:{
name:'Simulation_non_responsive_11',
type:1268,
from:13364,
to:13455,
rp:0,
rpa:0,
mdi:'si1144c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3.1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1152',
retainState:false,
immo:false,
apsn:'Slide1126',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2687',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1152',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1144c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1144,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1144',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:1160,
tsp:50,
ip:'dr/01160.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2687:{
name:'Mouse_10',
type:12,
from:13364,
to:13455,
rp:0,
rpa:0,
mdi:'si2687c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3.1,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":592.4479350706713,"mouseStartPointY":387.1006515017667,"mouseEndPointX":597.3756073321554,"mouseEndPointY":379.48829505300347}}',
parentGroup:'si1144',
retainState:false,
immo:false,
apsn:'Slide1126',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2687Ad',
trin:0,
trout:0,
isDD:false
},
si2687c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2687,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2687',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2687Ad:{
src:'ar/Mouse.mp3',
from:13364,
to:13369,
del:2.918,
msa:1,
du:0.182
},
Slide1126:{
lb:'Simulation slide 11',
id:1126,
from:13364,
to:13455,
iols:0,
i360qs:false,
sdu:3.1,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1126c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1152',
t:1268
}
]
,
iph:[]
,
oa:'si2687Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1126c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1126,
dn:'Slide1126',
visible:'1'
},
si1189:{
name:'Simulation_12',
type:1268,
from:13456,
to:13548,
rp:0,
rpa:0,
mdi:'si1189c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3.1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1163',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1181',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1189c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1189,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1189',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1181:{
name:'Simulation_non_responsive_12',
type:1268,
from:13456,
to:13548,
rp:0,
rpa:0,
mdi:'si1181c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3.1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1189',
retainState:false,
immo:false,
apsn:'Slide1163',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2694',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1189',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1181c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1181,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1181',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:1197,
tsp:50,
ip:'dr/01197.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2694:{
name:'Mouse_11',
type:12,
from:13456,
to:13548,
rp:0,
rpa:0,
mdi:'si2694c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3.1,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":597.3756073321554,"mouseStartPointY":379.4882950530034,"mouseEndPointX":345.3534673144876,"mouseEndPointY":450.34601369257945}}',
parentGroup:'si1181',
retainState:false,
immo:false,
apsn:'Slide1163',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2694Ad',
trin:0,
trout:0,
isDD:false
},
si2694c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2694,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2694',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2694Ad:{
src:'ar/Mouse.mp3',
from:13456,
to:13461,
del:2.918,
msa:1,
du:0.182
},
Slide1163:{
lb:'Simulation slide 12',
id:1163,
from:13456,
to:13548,
iols:0,
i360qs:false,
sdu:3.1,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1163c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1189',
t:1268
}
]
,
iph:[]
,
oa:'si2694Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1163c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1163,
dn:'Slide1163',
visible:'1'
},
si1226:{
name:'Simulation_13',
type:1268,
from:13549,
to:13758,
rp:0,
rpa:0,
mdi:'si1226c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1200',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1218',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1226c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1226,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1226',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1218:{
name:'Simulation_non_responsive_13',
type:1268,
from:13549,
to:13758,
rp:0,
rpa:0,
mdi:'si1218c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1226',
retainState:false,
immo:false,
apsn:'Slide1200',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1237',
t:1269
}
,{
n:'si1257',
t:612
}
,{
n:'si2701',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1226',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1218c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1218,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1218',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:1234,
tsp:50,
ip:'dr/01234.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1237:{
name:'Click_box_5',
type:1269,
from:1939,
to:2148,
rp:0,
rpa:0,
mdi:'si1237c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":455,"left":12,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si1218',
retainState:false,
immo:false,
apsn:'Slide1200',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1310);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:6.98999,
lcapid:'si1257',
si:[{
n:'si1247',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1237]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1237c:{
b:[12,455,46,475],
fh:false,
fw:false,
uid:1237,
iso:false,
css:{
360:{
l:'1.235%',
t:'74.836%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'1.235%',
lhID:-1,
lvEID:0,
lvV:'74.836%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'1.235%',
t:'74.836%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'1.235%',
lhID:-1,
lvEID:0,
lvV:'74.836%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'1.235%',
t:'74.836%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'1.235%',
lhID:-1,
lvEID:0,
lvV:'74.836%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1237',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[12,455,46,475],
vb:[12,455,46,475]
},
si1247:{
name:'Shape_5',
type:612,
from:1939,
to:2148,
rp:0,
rpa:0,
mdi:'si1247c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1200',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1247]
}
]
,
stis:0,
bstiid:1237,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1237',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1247c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1247,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1247',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1257:{
name:'Rectangle_5',
type:612,
from:1939,
to:2148,
rp:0,
rpa:0,
mdi:'si1257c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":515,"left":27,"width":300,"height":"auto"}}',
parentGroup:'si1218',
retainState:false,
immo:false,
apsn:'Slide1200',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1268,
stt:0,
dsr:'Default_State',
stsi:[1257]
}
,{
stn:1280,
stt:102,
dsr:'Failure',
stsi:[1281]
}
,{
stn:1291,
stt:103,
dsr:'Hint',
stsi:[1292]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1257','si1270','si1281','si1292'],
isDD:false
},
si1257c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1257,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1257',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1270:{
name:'',
type:612,
from:1939,
to:2148,
rp:0,
rpa:0,
mdi:'si1270c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":515,"left":27,"width":300,"height":"auto"}}',
parentGroup:'si1218',
retainState:false,
immo:false,
apsn:'Slide1200',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1257',
stl:[{
stn:'Normal',
stt:0,
stsi:[1270]
}
]
,
stis:0,
bstiid:1257,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1257,
isDD:false
},
si1270c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1270,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1270',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1281:{
name:'',
type:612,
from:1939,
to:2148,
rp:0,
rpa:0,
mdi:'si1281c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":515,"left":27,"width":300,"height":"auto"}}',
parentGroup:'si1218',
retainState:false,
immo:false,
apsn:'Slide1200',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1257',
stl:[{
stn:'Normal',
stt:0,
stsi:[1281]
}
]
,
stis:0,
bstiid:1257,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1257,
isDD:false
},
si1281c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1281,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1281',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1292:{
name:'',
type:612,
from:1939,
to:2148,
rp:0,
rpa:0,
mdi:'si1292c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":515,"left":27,"width":300,"height":"auto"}}',
parentGroup:'si1218',
retainState:false,
immo:false,
apsn:'Slide1200',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1257',
stl:[{
stn:'Normal',
stt:0,
stsi:[1292]
}
]
,
stis:0,
bstiid:1257,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1257,
isDD:false
},
si1292c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1292,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1292',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2701:{
name:'Mouse_12',
type:12,
from:13549,
to:13758,
rp:0,
rpa:0,
mdi:'si2701c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":345.3534673144876,"mouseStartPointY":450.34601369257945,"mouseEndPointX":40.452020759717314,"mouseEndPointY":469.7185291519434}}',
parentGroup:'si1218',
retainState:false,
immo:false,
apsn:'Slide1200',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2701Ad',
trin:0,
trout:0,
isDD:false
},
si2701c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2701,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2701',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2701Ad:{
src:'ar/Mouse.mp3',
from:13549,
to:13554,
del:6.818,
msa:1,
du:0.182
},
Slide1200:{
lb:'Simulation slide 13',
id:1200,
from:13549,
to:13758,
iols:0,
i360qs:false,
sdu:7,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1200c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1226',
t:1268
}
]
,
iph:[]
,
oa:'si2701Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1310:{
ts:''
}

}

},
Slide1200c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1200,
dn:'Slide1200',
visible:'1'
},
si1343:{
name:'Simulation_14',
type:1268,
from:13759,
to:13846,
rp:0,
rpa:0,
mdi:'si1343c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.9,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1317',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1335',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1343c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1343,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1343',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1335:{
name:'Simulation_non_responsive_14',
type:1268,
from:13759,
to:13846,
rp:0,
rpa:0,
mdi:'si1335c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.9,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1343',
retainState:false,
immo:false,
apsn:'Slide1317',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2708',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1343',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1335c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1335,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1335',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:1351,
tsp:50,
ip:'dr/01351.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2708:{
name:'Mouse_13',
type:12,
from:13759,
to:13846,
rp:0,
rpa:0,
mdi:'si2708c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.9,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":40.452020759717314,"mouseStartPointY":469.7185291519434,"mouseEndPointX":35.99365061837456,"mouseEndPointY":478.4696333922261}}',
parentGroup:'si1335',
retainState:false,
immo:false,
apsn:'Slide1317',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2708Ad',
trin:0,
trout:0,
isDD:false
},
si2708c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2708,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2708',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2708Ad:{
src:'ar/Mouse.mp3',
from:13759,
to:13764,
del:2.718,
msa:1,
du:0.182
},
Slide1317:{
lb:'Simulation slide 14',
id:1317,
from:13759,
to:13846,
iols:0,
i360qs:false,
sdu:2.9,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1317c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1343',
t:1268
}
]
,
iph:[]
,
oa:'si2708Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1317c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1317,
dn:'Slide1317',
visible:'1'
},
si1380:{
name:'Simulation_15',
type:1268,
from:13847,
to:14006,
rp:0,
rpa:0,
mdi:'si1380c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1354',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1372',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1380c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1380,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1380',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1372:{
name:'Simulation_non_responsive_15',
type:1268,
from:13847,
to:14006,
rp:0,
rpa:0,
mdi:'si1372c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1380',
retainState:false,
immo:false,
apsn:'Slide1354',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1391',
t:1269
}
,{
n:'si1411',
t:612
}
,{
n:'si2722',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1380',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1372c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1372,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1372',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:1388,
tsp:50,
ip:'dr/01388.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1391:{
name:'Click_box_6',
type:1269,
from:2237,
to:2396,
rp:0,
rpa:0,
mdi:'si1391c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":226,"left":1279,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si1372',
retainState:false,
immo:false,
apsn:'Slide1354',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1464);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:5.31099,
lcapid:'si1411',
si:[{
n:'si1401',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1391]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1391c:{
b:[1279,226,1313,246],
fh:false,
fw:false,
uid:1391,
iso:false,
css:{
360:{
l:'131.584%',
t:'37.171%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'131.584%',
lhID:-1,
lvEID:0,
lvV:'37.171%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'131.584%',
t:'37.171%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'131.584%',
lhID:-1,
lvEID:0,
lvV:'37.171%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'131.584%',
t:'37.171%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'131.584%',
lhID:-1,
lvEID:0,
lvV:'37.171%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1391',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1279,226,1313,246],
vb:[1279,226,1313,246]
},
si1401:{
name:'Shape_6',
type:612,
from:2237,
to:2396,
rp:0,
rpa:0,
mdi:'si1401c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1354',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1401]
}
]
,
stis:0,
bstiid:1391,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1391',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1401c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1401,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1401',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1411:{
name:'Rectangle_6',
type:612,
from:2237,
to:2396,
rp:0,
rpa:0,
mdi:'si1411c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":286,"left":964,"width":300,"height":"auto"}}',
parentGroup:'si1372',
retainState:false,
immo:false,
apsn:'Slide1354',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1422,
stt:0,
dsr:'Default_State',
stsi:[1411]
}
,{
stn:1434,
stt:102,
dsr:'Failure',
stsi:[1435]
}
,{
stn:1445,
stt:103,
dsr:'Hint',
stsi:[1446]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1411','si1424','si1435','si1446'],
isDD:false
},
si1411c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1411,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1411',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1424:{
name:'',
type:612,
from:2237,
to:2396,
rp:0,
rpa:0,
mdi:'si1424c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":286,"left":964,"width":300,"height":"auto"}}',
parentGroup:'si1372',
retainState:false,
immo:false,
apsn:'Slide1354',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1411',
stl:[{
stn:'Normal',
stt:0,
stsi:[1424]
}
]
,
stis:0,
bstiid:1411,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1411,
isDD:false
},
si1424c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1424,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1424',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1435:{
name:'',
type:612,
from:2237,
to:2396,
rp:0,
rpa:0,
mdi:'si1435c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":286,"left":964,"width":300,"height":"auto"}}',
parentGroup:'si1372',
retainState:false,
immo:false,
apsn:'Slide1354',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1411',
stl:[{
stn:'Normal',
stt:0,
stsi:[1435]
}
]
,
stis:0,
bstiid:1411,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1411,
isDD:false
},
si1435c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1435,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1435',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1446:{
name:'',
type:612,
from:2237,
to:2396,
rp:0,
rpa:0,
mdi:'si1446c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":286,"left":964,"width":300,"height":"auto"}}',
parentGroup:'si1372',
retainState:false,
immo:false,
apsn:'Slide1354',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1411',
stl:[{
stn:'Normal',
stt:0,
stsi:[1446]
}
]
,
stis:0,
bstiid:1411,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1411,
isDD:false
},
si1446c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1446,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1446',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2722:{
name:'Mouse_15',
type:12,
from:13847,
to:14006,
rp:0,
rpa:0,
mdi:'si2722c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":35.99365061837456,"mouseStartPointY":478.4696333922261,"mouseEndPointX":1294.1443242049468,"mouseEndPointY":245.75789531802118}}',
parentGroup:'si1372',
retainState:false,
immo:false,
apsn:'Slide1354',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2722Ad',
trin:0,
trout:0,
isDD:false
},
si2722c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2722,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2722',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2722Ad:{
src:'ar/Mouse.mp3',
from:13847,
to:13852,
del:5.118,
msa:1,
du:0.182
},
Slide1354:{
lb:'Simulation slide 15',
id:1354,
from:13847,
to:14006,
iols:0,
i360qs:false,
sdu:5.3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1354c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1380',
t:1268
}
]
,
iph:[]
,
oa:'si2722Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1464:{
ts:''
}

}

},
Slide1354c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1354,
dn:'Slide1354',
visible:'1'
},
si1497:{
name:'Simulation_16',
type:1268,
from:14007,
to:14393,
rp:0,
rpa:0,
mdi:'si1497c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.9,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1471',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1489',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1497c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1497,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1497',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1489:{
name:'Simulation_non_responsive_16',
type:1268,
from:14007,
to:14393,
rp:0,
rpa:0,
mdi:'si1489c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.9,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1497',
retainState:false,
immo:false,
apsn:'Slide1471',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1508',
t:1269
}
,{
n:'si1528',
t:612
}
,{
n:'si2715',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1497',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1489c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1489,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1489',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:1505,
tsp:50,
ip:'dr/01505.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1508:{
name:'Click_box_7',
type:1269,
from:2397,
to:2783,
rp:0,
rpa:0,
mdi:'si1508c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.9,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":214.8487190812721,"left":1276.6794942579506,"width":49.41108622736307,"height":52.82722176595627},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si1489',
retainState:false,
immo:false,
apsn:'Slide1471',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1581);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:12.876,
lcapid:'si1528',
si:[{
n:'si1518',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1508]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1508c:{
b:[1402,320,1436,340],
fh:false,
fw:false,
uid:1508,
iso:false,
css:{
360:{
l:'144.239%',
t:'52.632%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'144.239%',
lhID:-1,
lvEID:0,
lvV:'52.632%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'144.239%',
t:'52.632%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'144.239%',
lhID:-1,
lvEID:0,
lvV:'52.632%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'144.239%',
t:'52.632%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'144.239%',
lhID:-1,
lvEID:0,
lvV:'52.632%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1508',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1402,320,1436,340],
vb:[1402,320,1436,340]
},
si1518:{
name:'Shape_7',
type:612,
from:2397,
to:2783,
rp:0,
rpa:0,
mdi:'si1518c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1471',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1518]
}
]
,
stis:0,
bstiid:1508,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1508',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1518c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1518,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1518',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1528:{
name:'Rectangle_7',
type:612,
from:2397,
to:2783,
rp:0,
rpa:0,
mdi:'si1528c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.9,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":380,"left":1087,"width":300,"height":"auto"}}',
parentGroup:'si1489',
retainState:false,
immo:false,
apsn:'Slide1471',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1539,
stt:0,
dsr:'Default_State',
stsi:[1528]
}
,{
stn:1551,
stt:102,
dsr:'Failure',
stsi:[1552]
}
,{
stn:1562,
stt:103,
dsr:'Hint',
stsi:[1563]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1528','si1541','si1552','si1563'],
isDD:false
},
si1528c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1528,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1528',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1541:{
name:'',
type:612,
from:2397,
to:2783,
rp:0,
rpa:0,
mdi:'si1541c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":380,"left":1087,"width":300,"height":"auto"}}',
parentGroup:'si1489',
retainState:false,
immo:false,
apsn:'Slide1471',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1528',
stl:[{
stn:'Normal',
stt:0,
stsi:[1541]
}
]
,
stis:0,
bstiid:1528,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1528,
isDD:false
},
si1541c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1541,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1541',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1552:{
name:'',
type:612,
from:2397,
to:2783,
rp:0,
rpa:0,
mdi:'si1552c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":380,"left":1087,"width":300,"height":"auto"}}',
parentGroup:'si1489',
retainState:false,
immo:false,
apsn:'Slide1471',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1528',
stl:[{
stn:'Normal',
stt:0,
stsi:[1552]
}
]
,
stis:0,
bstiid:1528,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1528,
isDD:false
},
si1552c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1552,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1552',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1563:{
name:'',
type:612,
from:2397,
to:2783,
rp:0,
rpa:0,
mdi:'si1563c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":380,"left":1087,"width":300,"height":"auto"}}',
parentGroup:'si1489',
retainState:false,
immo:false,
apsn:'Slide1471',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1528',
stl:[{
stn:'Normal',
stt:0,
stsi:[1563]
}
]
,
stis:0,
bstiid:1528,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1528,
isDD:false
},
si1563c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1563,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1563',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2715:{
name:'Mouse_14',
type:12,
from:14193,
to:14393,
rp:0,
rpa:0,
mdi:'si2715c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:6.2,
sid:6.7,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":1294.1443242049468,"mouseStartPointY":245.7578953180212,"mouseEndPointX":1409.5719412544167,"mouseEndPointY":321.12919611307416}}',
parentGroup:'si1489',
retainState:false,
immo:false,
apsn:'Slide1471',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2715Ad',
trin:0,
trout:0,
isDD:false
},
si2715c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2715,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2715',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2715Ad:{
src:'ar/Mouse.mp3',
from:14193,
to:14198,
del:12.718,
msa:1,
du:0.182
},
Slide1471:{
lb:'Simulation slide 16',
id:1471,
from:14007,
to:14393,
iols:0,
i360qs:false,
sdu:12.9,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1471c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1497',
t:1268
}
]
,
iph:[]
,
oa:'si2715Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1581:{
ts:''
}

}

},
Slide1471c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1471,
dn:'Slide1471',
visible:'1'
},
si1614:{
name:'Simulation_17',
type:1268,
from:14394,
to:14528,
rp:0,
rpa:0,
mdi:'si1614c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.5,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1588',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1606',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1614c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1614,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1614',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1606:{
name:'Simulation_non_responsive_17',
type:1268,
from:14394,
to:14528,
rp:0,
rpa:0,
mdi:'si1606c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.5,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1614',
retainState:false,
immo:false,
apsn:'Slide1588',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1625',
t:1269
}
,{
n:'si1645',
t:612
}
,{
n:'si2729',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1614',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1606c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1606,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1606',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:1622,
tsp:50,
ip:'dr/01622.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1625:{
name:'Click_box_8',
type:1269,
from:2784,
to:2918,
rp:0,
rpa:0,
mdi:'si1625c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.5,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":428.39462571430545,"left":1252.2916298586572,"width":99.97310571030255,"height":17.667844522968196},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si1606',
retainState:false,
immo:false,
apsn:'Slide1588',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1698);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:4.49099,
lcapid:'si1645',
si:[{
n:'si1635',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1625]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1625c:{
b:[1288,426,1322,446],
fh:false,
fw:false,
uid:1625,
iso:false,
css:{
360:{
l:'132.510%',
t:'70.066%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'132.510%',
lhID:-1,
lvEID:0,
lvV:'70.066%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'132.510%',
t:'70.066%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'132.510%',
lhID:-1,
lvEID:0,
lvV:'70.066%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'132.510%',
t:'70.066%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'132.510%',
lhID:-1,
lvEID:0,
lvV:'70.066%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1625',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1288,426,1322,446],
vb:[1288,426,1322,446]
},
si1635:{
name:'Shape_8',
type:612,
from:2784,
to:2918,
rp:0,
rpa:0,
mdi:'si1635c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1588',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1635]
}
]
,
stis:0,
bstiid:1625,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1625',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1635c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1635,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1635',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1645:{
name:'Rectangle_8',
type:612,
from:2784,
to:2918,
rp:0,
rpa:0,
mdi:'si1645c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.5,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":486,"left":973,"width":300,"height":"auto"}}',
parentGroup:'si1606',
retainState:false,
immo:false,
apsn:'Slide1588',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1656,
stt:0,
dsr:'Default_State',
stsi:[1645]
}
,{
stn:1668,
stt:102,
dsr:'Failure',
stsi:[1669]
}
,{
stn:1679,
stt:103,
dsr:'Hint',
stsi:[1680]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1645','si1658','si1669','si1680'],
isDD:false
},
si1645c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1645,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1645',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1658:{
name:'',
type:612,
from:2784,
to:2918,
rp:0,
rpa:0,
mdi:'si1658c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":486,"left":973,"width":300,"height":"auto"}}',
parentGroup:'si1606',
retainState:false,
immo:false,
apsn:'Slide1588',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1645',
stl:[{
stn:'Normal',
stt:0,
stsi:[1658]
}
]
,
stis:0,
bstiid:1645,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1645,
isDD:false
},
si1658c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1658,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1658',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1669:{
name:'',
type:612,
from:2784,
to:2918,
rp:0,
rpa:0,
mdi:'si1669c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":486,"left":973,"width":300,"height":"auto"}}',
parentGroup:'si1606',
retainState:false,
immo:false,
apsn:'Slide1588',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1645',
stl:[{
stn:'Normal',
stt:0,
stsi:[1669]
}
]
,
stis:0,
bstiid:1645,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1645,
isDD:false
},
si1669c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1669,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1669',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1680:{
name:'',
type:612,
from:2784,
to:2918,
rp:0,
rpa:0,
mdi:'si1680c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":486,"left":973,"width":300,"height":"auto"}}',
parentGroup:'si1606',
retainState:false,
immo:false,
apsn:'Slide1588',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1645',
stl:[{
stn:'Normal',
stt:0,
stsi:[1680]
}
]
,
stis:0,
bstiid:1645,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1645,
isDD:false
},
si1680c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1680,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1680',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2729:{
name:'Mouse_16',
type:12,
from:14394,
to:14528,
rp:0,
rpa:0,
mdi:'si2729c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.5,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":1409.5719412544167,"mouseStartPointY":321.12919611307416,"mouseEndPointX":1300.5420163427561,"mouseEndPointY":436.68794169611306}}',
parentGroup:'si1606',
retainState:false,
immo:false,
apsn:'Slide1588',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2729Ad',
trin:0,
trout:0,
isDD:false
},
si2729c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2729,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2729',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2729Ad:{
src:'ar/Mouse.mp3',
from:14394,
to:14399,
del:4.318,
msa:1,
du:0.182
},
Slide1588:{
lb:'Simulation slide 17',
id:1588,
from:14394,
to:14528,
iols:0,
i360qs:false,
sdu:4.5,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1588c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1614',
t:1268
}
]
,
iph:[]
,
oa:'si2729Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1698:{
ts:''
}

}

},
Slide1588c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1588,
dn:'Slide1588',
visible:'1'
},
si1731:{
name:'Simulation_18',
type:1268,
from:14529,
to:14805,
rp:0,
rpa:0,
mdi:'si1731c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1705',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1723',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1731c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1731,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1731',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1723:{
name:'Simulation_non_responsive_18',
type:1268,
from:14529,
to:14805,
rp:0,
rpa:0,
mdi:'si1723c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1731',
retainState:false,
immo:false,
apsn:'Slide1705',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1742',
t:1269
}
,{
n:'si1762',
t:612
}
,{
n:'si2736',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1731',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1723c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1723,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1723',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:1739,
tsp:50,
ip:'dr/01739.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1742:{
name:'Click_box_9',
type:1269,
from:2919,
to:3195,
rp:0,
rpa:0,
mdi:'si1742c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.2,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":477,"left":1119,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si1723',
retainState:false,
immo:false,
apsn:'Slide1705',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1815);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:9.20499,
lcapid:'si1762',
si:[{
n:'si1752',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1742]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1742c:{
b:[1119,477,1153,497],
fh:false,
fw:false,
uid:1742,
iso:false,
css:{
360:{
l:'115.123%',
t:'78.454%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'115.123%',
lhID:-1,
lvEID:0,
lvV:'78.454%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'115.123%',
t:'78.454%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'115.123%',
lhID:-1,
lvEID:0,
lvV:'78.454%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'115.123%',
t:'78.454%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'115.123%',
lhID:-1,
lvEID:0,
lvV:'78.454%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1742',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1119,477,1153,497],
vb:[1119,477,1153,497]
},
si1752:{
name:'Shape_9',
type:612,
from:2919,
to:3195,
rp:0,
rpa:0,
mdi:'si1752c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1705',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1752]
}
]
,
stis:0,
bstiid:1742,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1742',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1752c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1752,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1752',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1762:{
name:'Rectangle_9',
type:612,
from:2919,
to:3195,
rp:0,
rpa:0,
mdi:'si1762c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.2,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":537,"left":1134,"width":300,"height":"auto"}}',
parentGroup:'si1723',
retainState:false,
immo:false,
apsn:'Slide1705',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1773,
stt:0,
dsr:'Default_State',
stsi:[1762]
}
,{
stn:1785,
stt:102,
dsr:'Failure',
stsi:[1786]
}
,{
stn:1796,
stt:103,
dsr:'Hint',
stsi:[1797]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1762','si1775','si1786','si1797'],
isDD:false
},
si1762c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1762,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1762',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1775:{
name:'',
type:612,
from:2919,
to:3195,
rp:0,
rpa:0,
mdi:'si1775c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":537,"left":1134,"width":300,"height":"auto"}}',
parentGroup:'si1723',
retainState:false,
immo:false,
apsn:'Slide1705',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1762',
stl:[{
stn:'Normal',
stt:0,
stsi:[1775]
}
]
,
stis:0,
bstiid:1762,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1762,
isDD:false
},
si1775c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1775,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1775',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1786:{
name:'',
type:612,
from:2919,
to:3195,
rp:0,
rpa:0,
mdi:'si1786c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":537,"left":1134,"width":300,"height":"auto"}}',
parentGroup:'si1723',
retainState:false,
immo:false,
apsn:'Slide1705',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1762',
stl:[{
stn:'Normal',
stt:0,
stsi:[1786]
}
]
,
stis:0,
bstiid:1762,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1762,
isDD:false
},
si1786c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1786,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1786',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1797:{
name:'',
type:612,
from:2919,
to:3195,
rp:0,
rpa:0,
mdi:'si1797c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":537,"left":1134,"width":300,"height":"auto"}}',
parentGroup:'si1723',
retainState:false,
immo:false,
apsn:'Slide1705',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1762',
stl:[{
stn:'Normal',
stt:0,
stsi:[1797]
}
]
,
stis:0,
bstiid:1762,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1762,
isDD:false
},
si1797c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1797,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1797',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2736:{
name:'Mouse_17',
type:12,
from:14529,
to:14805,
rp:0,
rpa:0,
mdi:'si2736c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.2,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":1300.542016342756,"mouseStartPointY":436.68794169611306,"mouseEndPointX":1132.5870693462896,"mouseEndPointY":490.2781029151943}}',
parentGroup:'si1723',
retainState:false,
immo:false,
apsn:'Slide1705',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2736Ad',
trin:0,
trout:0,
isDD:false
},
si2736c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2736,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2736',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2736Ad:{
src:'ar/Mouse.mp3',
from:14529,
to:14534,
del:9.018,
msa:1,
du:0.182
},
Slide1705:{
lb:'Simulation slide 18',
id:1705,
from:14529,
to:14805,
iols:0,
i360qs:false,
sdu:9.2,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1705c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1731',
t:1268
}
]
,
iph:[]
,
oa:'si2736Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1815:{
ts:''
}

}

},
Slide1705c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1705,
dn:'Slide1705',
visible:'1'
},
si1848:{
name:'Simulation_19',
type:1268,
from:14806,
to:15315,
rp:0,
rpa:0,
mdi:'si1848c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1822',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1840',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1848c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1848,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1848',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1840:{
name:'Simulation_non_responsive_19',
type:1268,
from:14806,
to:15315,
rp:0,
rpa:0,
mdi:'si1840c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1848',
retainState:false,
immo:false,
apsn:'Slide1822',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1859',
t:1269
}
,{
n:'si1879',
t:612
}
,{
n:'si2743',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1848',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1840c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1840,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1840',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:1856,
tsp:50,
ip:'dr/01856.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1859:{
name:'Click_box_10',
type:1269,
from:14806,
to:15315,
rp:0,
rpa:0,
mdi:'si1859c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":238,"left":1197,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si1840',
retainState:false,
immo:false,
apsn:'Slide1822',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1932);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:16.99,
lcapid:'si1879',
si:[{
n:'si1869',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1859]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1859c:{
b:[1197,238,1231,258],
fh:false,
fw:false,
uid:1859,
iso:false,
css:{
360:{
l:'123.148%',
t:'39.145%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'123.148%',
lhID:-1,
lvEID:0,
lvV:'39.145%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'123.148%',
t:'39.145%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'123.148%',
lhID:-1,
lvEID:0,
lvV:'39.145%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'123.148%',
t:'39.145%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'123.148%',
lhID:-1,
lvEID:0,
lvV:'39.145%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1859',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1197,238,1231,258],
vb:[1197,238,1231,258]
},
si1869:{
name:'Shape_10',
type:612,
from:14806,
to:15315,
rp:0,
rpa:0,
mdi:'si1869c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1822',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1869]
}
]
,
stis:0,
bstiid:1859,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1859',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1869c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1869,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1869',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1879:{
name:'Rectangle_10',
type:612,
from:14806,
to:15315,
rp:0,
rpa:0,
mdi:'si1879c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":298,"left":882,"width":300,"height":"auto"}}',
parentGroup:'si1840',
retainState:false,
immo:false,
apsn:'Slide1822',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1890,
stt:0,
dsr:'Default_State',
stsi:[1879]
}
,{
stn:1902,
stt:102,
dsr:'Failure',
stsi:[1903]
}
,{
stn:1913,
stt:103,
dsr:'Hint',
stsi:[1914]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1879','si1892','si1903','si1914'],
isDD:false
},
si1879c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1879,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1879',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1892:{
name:'',
type:612,
from:3196,
to:3422,
rp:0,
rpa:0,
mdi:'si1892c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":298,"left":882,"width":300,"height":"auto"}}',
parentGroup:'si1840',
retainState:false,
immo:false,
apsn:'Slide1822',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1879',
stl:[{
stn:'Normal',
stt:0,
stsi:[1892]
}
]
,
stis:0,
bstiid:1879,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1879,
isDD:false
},
si1892c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1892,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1892',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1903:{
name:'',
type:612,
from:3196,
to:3422,
rp:0,
rpa:0,
mdi:'si1903c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":298,"left":882,"width":300,"height":"auto"}}',
parentGroup:'si1840',
retainState:false,
immo:false,
apsn:'Slide1822',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1879',
stl:[{
stn:'Normal',
stt:0,
stsi:[1903]
}
]
,
stis:0,
bstiid:1879,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1879,
isDD:false
},
si1903c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1903,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1903',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1914:{
name:'',
type:612,
from:3196,
to:3422,
rp:0,
rpa:0,
mdi:'si1914c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":298,"left":882,"width":300,"height":"auto"}}',
parentGroup:'si1840',
retainState:false,
immo:false,
apsn:'Slide1822',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1879',
stl:[{
stn:'Normal',
stt:0,
stsi:[1914]
}
]
,
stis:0,
bstiid:1879,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1879,
isDD:false
},
si1914c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1914,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1914',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2743:{
name:'Mouse_18',
type:12,
from:14806,
to:15315,
rp:0,
rpa:0,
mdi:'si2743c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":1132.5870693462896,"mouseStartPointY":490.2781029151943,"mouseEndPointX":1222.803500441696,"mouseEndPointY":245.18507067137807}}',
parentGroup:'si1840',
retainState:false,
immo:false,
apsn:'Slide1822',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2743Ad',
trin:0,
trout:0,
isDD:false
},
si2743c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2743,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2743',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2743Ad:{
src:'ar/Mouse.mp3',
from:14806,
to:14811,
del:16.818,
msa:1,
du:0.182
},
Slide1822:{
lb:'Simulation slide 19',
id:1822,
from:14806,
to:15315,
iols:0,
i360qs:false,
sdu:17,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1822c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1848',
t:1268
}
]
,
iph:[]
,
oa:'si2743Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1932:{
ts:''
}

}

},
Slide1822c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1822,
dn:'Slide1822',
visible:'1'
},
StAd28:{
from:16036,
to:20116,
src:'ar/StAd27.mp3',
du:136599,
saup:[{
sn:436,
del:0,
du:12.1,
l:false
}
,{
sn:553,
del:0,
du:2.6,
l:false
}
,{
sn:590,
del:0,
du:2.3,
l:false
}
,{
sn:707,
del:0,
du:13,
l:false
}
,{
sn:824,
del:0,
du:7.5,
l:false
}
,{
sn:861,
del:0,
du:2.2,
l:false
}
,{
sn:898,
del:0,
du:1.2,
l:false
}
,{
sn:935,
del:0,
du:2,
l:false
}
,{
sn:972,
del:0,
du:10.6,
l:false
}
,{
sn:1089,
del:0,
du:4.9,
l:false
}
,{
sn:1126,
del:0,
du:3.1,
l:false
}
,{
sn:1163,
del:0,
du:3.1,
l:false
}
,{
sn:1200,
del:0,
du:7,
l:false
}
,{
sn:1317,
del:0,
du:2.9,
l:false
}
,{
sn:1354,
del:0,
du:5.3,
l:false
}
,{
sn:1471,
del:0,
du:12.9,
l:false
}
,{
sn:1588,
del:0,
du:4.5,
l:false
}
,{
sn:1705,
del:0,
du:9.2,
l:false
}
,{
sn:1822,
del:0,
du:16.9796,
l:false
}
,{
sn:1939,
del:0,
du:13.2204,
l:false
}
]

},
si1965:{
name:'Simulation_20',
type:1268,
from:15316,
to:15749,
rp:0,
rpa:0,
mdi:'si1965c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:14.4,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1939',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1957',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1965c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1965,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1965',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1957:{
name:'Simulation_non_responsive_20',
type:1268,
from:15316,
to:15749,
rp:0,
rpa:0,
mdi:'si1957c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:14.4,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1965',
retainState:false,
immo:false,
apsn:'Slide1939',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1976',
t:1269
}
,{
n:'si1996',
t:612
}
,{
n:'si2750',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1965',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1957c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1957,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1957',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:1973,
tsp:50,
ip:'dr/01973.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1976:{
name:'Click_box_11',
type:1269,
from:3423,
to:3856,
rp:0,
rpa:0,
mdi:'si1976c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:14.4,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":235,"left":1371,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si1957',
retainState:false,
immo:false,
apsn:'Slide1939',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2049);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:14.431,
lcapid:'si1996',
si:[{
n:'si1986',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1976]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1976c:{
b:[1371,235,1405,255],
fh:false,
fw:false,
uid:1976,
iso:false,
css:{
360:{
l:'141.049%',
t:'38.651%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'141.049%',
lhID:-1,
lvEID:0,
lvV:'38.651%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'141.049%',
t:'38.651%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'141.049%',
lhID:-1,
lvEID:0,
lvV:'38.651%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'141.049%',
t:'38.651%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'141.049%',
lhID:-1,
lvEID:0,
lvV:'38.651%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1976',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1371,235,1405,255],
vb:[1371,235,1405,255]
},
si1986:{
name:'Shape_11',
type:612,
from:3423,
to:3856,
rp:0,
rpa:0,
mdi:'si1986c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:14.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1939',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1986]
}
]
,
stis:0,
bstiid:1976,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1976',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1986c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1986,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1986',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1996:{
name:'Rectangle_11',
type:612,
from:3423,
to:3856,
rp:0,
rpa:0,
mdi:'si1996c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:14.4,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":295,"left":1056,"width":300,"height":"auto"}}',
parentGroup:'si1957',
retainState:false,
immo:false,
apsn:'Slide1939',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2007,
stt:0,
dsr:'Default_State',
stsi:[1996]
}
,{
stn:2019,
stt:102,
dsr:'Failure',
stsi:[2020]
}
,{
stn:2030,
stt:103,
dsr:'Hint',
stsi:[2031]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1996','si2009','si2020','si2031'],
isDD:false
},
si1996c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1996,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1996',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2009:{
name:'',
type:612,
from:3423,
to:3856,
rp:0,
rpa:0,
mdi:'si2009c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:14.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":295,"left":1056,"width":300,"height":"auto"}}',
parentGroup:'si1957',
retainState:false,
immo:false,
apsn:'Slide1939',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1996',
stl:[{
stn:'Normal',
stt:0,
stsi:[2009]
}
]
,
stis:0,
bstiid:1996,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1996,
isDD:false
},
si2009c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2009,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2009',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2020:{
name:'',
type:612,
from:3423,
to:3856,
rp:0,
rpa:0,
mdi:'si2020c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:14.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":295,"left":1056,"width":300,"height":"auto"}}',
parentGroup:'si1957',
retainState:false,
immo:false,
apsn:'Slide1939',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1996',
stl:[{
stn:'Normal',
stt:0,
stsi:[2020]
}
]
,
stis:0,
bstiid:1996,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1996,
isDD:false
},
si2020c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2020,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2020',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2031:{
name:'',
type:612,
from:3423,
to:3856,
rp:0,
rpa:0,
mdi:'si2031c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:14.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":295,"left":1056,"width":300,"height":"auto"}}',
parentGroup:'si1957',
retainState:false,
immo:false,
apsn:'Slide1939',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1996',
stl:[{
stn:'Normal',
stt:0,
stsi:[2031]
}
]
,
stis:0,
bstiid:1996,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1996,
isDD:false
},
si2031c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2031,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2031',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2750:{
name:'Mouse_19',
type:12,
from:15316,
to:15749,
rp:0,
rpa:0,
mdi:'si2750c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:14.4,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":1222.803500441696,"mouseStartPointY":245.18507067137807,"mouseEndPointX":1393.1670715547702,"mouseEndPointY":246.0960689045936}}',
parentGroup:'si1957',
retainState:false,
immo:false,
apsn:'Slide1939',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2750Ad',
trin:0,
trout:0,
isDD:false
},
si2750c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2750,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2750',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2750Ad:{
src:'ar/Mouse.mp3',
from:15316,
to:15321,
del:14.218,
msa:1,
du:0.182
},
Slide1939:{
lb:'Simulation slide 20',
id:1939,
from:15316,
to:15749,
iols:0,
i360qs:false,
sdu:14.4,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1939c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1965',
t:1268
}
]
,
iph:[]
,
oa:'si2750Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2049:{
ts:''
}

}

},
Slide1939c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1939,
dn:'Slide1939',
visible:'1'
},
si2082:{
name:'Simulation_21',
type:1268,
from:15750,
to:16035,
rp:0,
rpa:0,
mdi:'si2082c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.5,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2056',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2074',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2082c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2082,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2082',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2074:{
name:'Simulation_non_responsive_21',
type:1268,
from:15750,
to:16035,
rp:0,
rpa:0,
mdi:'si2074c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.5,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si2082',
retainState:false,
immo:false,
apsn:'Slide2056',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2777',
t:612
}
,{
n:'si2757',
t:1269
}
,{
n:'si2837',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":900},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2082',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2074c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2074,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2074',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:2880,
h:1800,
id:2090,
tsp:50,
ip:'dr/02090.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2777:{
name:'Rectangle_18',
type:612,
from:3857,
to:4142,
rp:0,
rpa:0,
mdi:'si2777c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.5,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si2074',
retainState:false,
immo:false,
apsn:'Slide2056',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2788,
stt:0,
dsr:'Default_State',
stsi:[2777]
}
,{
stn:2800,
stt:102,
dsr:'Failure',
stsi:[2801]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2777','si2790','si2801','si2812'],
isDD:false
},
si2777c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2777,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2777',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2790:{
name:'',
type:612,
from:3857,
to:4142,
rp:0,
rpa:0,
mdi:'si2790c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si2074',
retainState:false,
immo:false,
apsn:'Slide2056',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2777',
stl:[{
stn:'Normal',
stt:0,
stsi:[2790]
}
]
,
stis:0,
bstiid:2777,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2777,
isDD:false
},
si2790c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2790,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2790',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2801:{
name:'',
type:612,
from:3857,
to:4142,
rp:0,
rpa:0,
mdi:'si2801c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si2074',
retainState:false,
immo:false,
apsn:'Slide2056',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2777',
stl:[{
stn:'Normal',
stt:0,
stsi:[2801]
}
]
,
stis:0,
bstiid:2777,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2777,
isDD:false
},
si2801c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2801,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2801',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2812:{
name:'',
type:612,
from:3857,
to:4142,
rp:0,
rpa:0,
mdi:'si2812c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si2074',
retainState:false,
immo:false,
apsn:'Slide2056',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2777',
stl:[{
stn:'Normal',
stt:0,
stsi:[2812]
}
]
,
stis:0,
bstiid:2777,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2777,
isDD:false
},
si2812c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2812,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2812',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2757:{
name:'Click_box_16',
type:1269,
from:3857,
to:4142,
rp:0,
rpa:0,
mdi:'si2757c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.5,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":1210.5192137809188,"top":327.7281912544169,"width":64,"height":64},"shouldRender":true,"attempts":1024}',
parentGroup:'si2074',
retainState:false,
immo:false,
apsn:'Slide2056',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2830);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1,
pa:-1,
lcapid:'si2777',
si:[{
n:'si2767',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2757]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2757c:{
b:[1352,24,1416,88],
fh:false,
fw:false,
uid:2757,
iso:false,
css:{
360:{
l:'139.095%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'139.095%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'139.095%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'139.095%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'139.095%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'139.095%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2757',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1352,24,1416,88],
vb:[1352,24,1416,88]
},
si2767:{
name:'Shape_18',
type:612,
from:3857,
to:4142,
rp:0,
rpa:0,
mdi:'si2767c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide2056',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2767]
}
]
,
stis:0,
bstiid:2757,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2757',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2767c:{
b:[0,0,64,64],
fh:false,
fw:false,
uid:2767,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2767',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,66,66],
vb:[-2,-2,66,66]
},
si2837:{
name:'Mouse_20',
type:12,
from:15852,
to:16035,
rp:0,
rpa:0,
mdi:'si2837c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:3.4,
sid:6.1,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":5},"mousePathPoints":{"mouseStartPointX":1393.1670715547702,"mouseStartPointY":246.0960689045936,"mouseEndPointX":16,"mouseEndPointY":16}}',
parentGroup:'si2074',
retainState:false,
immo:false,
apsn:'Slide2056',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2837Ad',
trin:0,
trout:0,
isDD:false
},
si2837c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2837,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2837',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2837Ad:{
src:'ar/Mouse.mp3',
from:15852,
to:15857,
del:9.318,
msa:1,
du:0.182
},
Slide2056:{
lb:'Simulation slide 21',
id:2056,
from:15750,
to:16035,
iols:0,
i360qs:false,
sdu:9.5,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2056c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2082',
t:1268
}
]
,
iph:[]
,
oa:'si2837Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2830:{
ts:''
}

}

},
Slide2056c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2056,
dn:'Slide2056',
visible:'1'
},
StAd29:{
from:16036,
to:16320,
src:'ar/2133.mp3',
du:9500,
saup:[{
sn:2056,
del:0,
du:9.5,
l:false
}
]

},
quizzingData:{
allowBackwardMovement:true,
allowReviewMode:true,
reviewShowAnswers:true,
it:false,
firstSlideInQuiz:-1,
lastSlideInQuiz:-1,
quizScopeEndSlide:-1,
maxScore:0,
minScore:0,
maxPretestScore:0,
numQuestionsInQuiz:0,
numQuizAttemptsAllowed:1,
passingScore:0,
quizInfoCurrentAttempt:0,
quizInfoPercentScored:0,
quizMandateLevel:0,
quizID:199,
questionPoolsInitialized:true,
quizInfoAttempts:1,
quizInfoLastSlidePointScored:0,
quizInfoMaxAttemptsOnCurrentQuestion:1,
quizInfoPassFail:0,
quizInfoPointsPerQuestionSlide:0,
quizInfoPointsScored:0,
quizInfoQuizPassPercent:80,
quizInfoQuizPassPoints:0,
quizInfoTotalCorrectAnswers:0,
quizInfoTotalProjectPoints:0,
quizInfoTotalQuestionsPerProject:0,
quizInfoTotalQuizPoints:0,
quizInfoTotalUnansweredQuestions:0,
reportingEnabled:false,
submitAll:false,
hidePlaybarInQuiz:false,
quizBranchAware:false,
passFailPassingScoreTypeInPrecent:true,
passFailPassingScoreValue:80,
showRetake:false,
showReviewButtons:true,
oid:'$$OBJECTIVE_ID',
quizVariableVsIdMap:{
learnerId:'var346',
learnerName:'var347',
isInQuizScope:'var368',
isInReviewMode:'var369',
quizInfoPercentScored:'var370',
quizInfoAttempts:'var371',
quizInfoPassFail:'var372',
score:'var373',
quizInfoQuizPassPercent:'var374',
passingScore:'var375',
quizInfoTotalCorrectAnswers:'var376',
maxScore:'var377',
quizInfoTotalQuestionsPerProject:'var378',
quizInfoTotalUnansweredQuestions:'var379',
quizInfoAnswerChoice:'var380',
quizInfoPreviousQuestionScore:'var381',
questionInfoMaxAttempts:'var382',
questionInfoNegativePoints:'var383',
questionInfoPointsAssigned:'var384'
}

},
var346var346:{
vid:346,
name:'LMS.LearnerID',
vv:'',
vvt:2,
vt:0
},
var347var347:{
vid:347,
name:'LMS.LearnerName',
vv:'',
vvt:2,
vt:0
},
var348var348:{
vid:348,
name:'LMS.CourseName',
vv:'',
vvt:2,
vt:0
},
var349var349:{
vid:349,
name:'Project.ClosedCaptions',
vv:1,
vvt:0,
vt:9
},
var350var350:{
vid:350,
name:'Project.MuteAudio',
vv:0,
vvt:0,
vt:9
},
var351var351:{
vid:351,
name:'Project.ShowPlaybar',
vv:1,
vvt:0,
vt:9
},
var352var352:{
vid:352,
name:'Project.ShowTOC',
vv:0,
vvt:0,
vt:9
},
var353var353:{
vid:353,
name:'Project.AudioLevel',
vv:100,
vvt:1,
vt:9
},
var354var354:{
vid:354,
name:'Project.LockTOC',
vv:0,
vvt:0,
vt:9
},
var355var355:{
vid:355,
name:'Project.CurrentSlideNumber',
vv:1,
vvt:1,
vt:9
},
var356var356:{
vid:356,
name:'Project.CurrentSlideName',
vv:'slide',
vvt:2,
vt:9
},
var357var357:{
vid:357,
name:'Project.SlideCount',
vv:1,
vvt:1,
vt:9
},
var358var358:{
vid:358,
name:'Date.Today',
vv:'dd',
vvt:3,
vt:5
},
var359var359:{
vid:359,
name:'Date.DateMMDDYY',
vv:'mm/dd/yyyy',
vvt:3,
vt:5
},
var360var360:{
vid:360,
name:'Date.DateDDMMYY',
vv:'dd/mm/yyyy',
vvt:3,
vt:5
},
var361var361:{
vid:361,
name:'Date.Day',
vv:'1',
vvt:3,
vt:5
},
var362var362:{
vid:362,
name:'Date.Hours',
vv:'hh',
vvt:3,
vt:5
},
var363var363:{
vid:363,
name:'Date.LocaleString',
vv:'',
vvt:3,
vt:5
},
var364var364:{
vid:364,
name:'Date.Minutes',
vv:'mm',
vvt:3,
vt:5
},
var365var365:{
vid:365,
name:'Date.Month',
vv:'mm',
vvt:3,
vt:5
},
var366var366:{
vid:366,
name:'Date.Time',
vv:'hh:mm:ss',
vvt:3,
vt:5
},
var367var367:{
vid:367,
name:'Date.Year',
vv:'yyyy',
vvt:3,
vt:5
},
var368var368:{
vid:368,
name:'Quiz.InScope',
vv:0,
vvt:0,
vt:7
},
var369var369:{
vid:369,
name:'Quiz.InReview',
vv:0,
vvt:0,
vt:7
},
var370var370:{
vid:370,
name:'Quiz.PercentageScore',
vv:'0',
vvt:2,
vt:7
},
var371var371:{
vid:371,
name:'Quiz.AttemptCount',
vv:0,
vvt:1,
vt:7
},
var372var372:{
vid:372,
name:'Quiz.Pass',
vv:0,
vvt:0,
vt:7
},
var373var373:{
vid:373,
name:'Quiz.Score',
vv:0,
vvt:1,
vt:7
},
var374var374:{
vid:374,
name:'Quiz.PassPercentage',
vv:80,
vvt:1,
vt:7
},
var375var375:{
vid:375,
name:'Quiz.PassPoints',
vv:0,
vvt:1,
vt:7
},
var376var376:{
vid:376,
name:'Quiz.CorrectAnswerCount',
vv:0,
vvt:1,
vt:7
},
var377var377:{
vid:377,
name:'Quiz.MaxScore',
vv:0,
vvt:1,
vt:7
},
var378var378:{
vid:378,
name:'Quiz.QuestionCount',
vv:0,
vvt:1,
vt:7
},
var379var379:{
vid:379,
name:'Quiz.UnansweredQuestionCount',
vv:0,
vvt:1,
vt:7
},
var380var380:{
vid:380,
name:'Question.AnswerChoice',
vv:'',
vvt:2,
vt:7
},
var381var381:{
vid:381,
name:'Question.PreviousQuestionScore',
vv:0,
vvt:1,
vt:7
},
var382var382:{
vid:382,
name:'Question.MaxAttempts',
vv:0,
vvt:1,
vt:7
},
var383var383:{
vid:383,
name:'Question.NegativePoints',
vv:0,
vvt:1,
vt:7
},
var384var384:{
vid:384,
name:'Question.PointsAssigned',
vv:0,
vvt:1,
vt:7
},
var2952var2952:{
vid:2952,
name:'variableEditBoxStr_1',
vv:'',
vvt:2,
vt:0
},
var2953var2953:{
vid:2953,
name:'variableEditBoxNum_1',
vv:0,
vvt:1,
vt:0
},
var3114var3114:{
vid:3114,
name:'variableEditBoxStr_2',
vv:'',
vvt:2,
vt:0
},
var3115var3115:{
vid:3115,
name:'variableEditBoxNum_2',
vv:0,
vvt:1,
vt:0
},
variableIdVsNameMap:{
var346:'LMS.LearnerID',
var347:'LMS.LearnerName',
var348:'LMS.CourseName',
var349:'Project.ClosedCaptions',
var350:'Project.MuteAudio',
var351:'Project.ShowPlaybar',
var352:'Project.ShowTOC',
var353:'Project.AudioLevel',
var354:'Project.LockTOC',
var355:'Project.CurrentSlideNumber',
var356:'Project.CurrentSlideName',
var357:'Project.SlideCount',
var358:'Date.Today',
var359:'Date.DateMMDDYY',
var360:'Date.DateDDMMYY',
var361:'Date.Day',
var362:'Date.Hours',
var363:'Date.LocaleString',
var364:'Date.Minutes',
var365:'Date.Month',
var366:'Date.Time',
var367:'Date.Year',
var368:'Quiz.InScope',
var369:'Quiz.InReview',
var370:'Quiz.PercentageScore',
var371:'Quiz.AttemptCount',
var372:'Quiz.Pass',
var373:'Quiz.Score',
var374:'Quiz.PassPercentage',
var375:'Quiz.PassPoints',
var376:'Quiz.CorrectAnswerCount',
var377:'Quiz.MaxScore',
var378:'Quiz.QuestionCount',
var379:'Quiz.UnansweredQuestionCount',
var380:'Question.AnswerChoice',
var381:'Question.PreviousQuestionScore',
var382:'Question.MaxAttempts',
var383:'Question.NegativePoints',
var384:'Question.PointsAssigned',
var2952:'variableEditBoxStr_1',
var2953:'variableEditBoxNum_1',
var3114:'variableEditBoxStr_2',
var3115:'variableEditBoxNum_2'
},
project:{
fps:30,
hasTOC:1,
hasCC:false,
showClosedCaptions:true,
w:1440,
h:900,
iw:1440,
ih:900,
prm:[1,1,0,0],
stateNameToLocalizedStateNameMap:{
kCPNormalState:'Normal',
kCPDownState:'Click',
kCPRolloverState:'Hover',
kCPVisitedState:'Visited',
kCPDragoverState:'',
kCPDragstartState:'',
kCPDropCorrect:'',
kCPDropIncorrect:'',
kCPDropAccept:'',
kCPDropReject:''
}
,
prjBgColor:'#ffffff',
pkt:0,
htmlBgColor:'#f5f4f1',
shc:false,
pN:'untitled_training1.cpt'
},
projectThemeData:{
image_presets:'{\
  "theme_image_default": {\
    "meta": {\
      "name": "kCPImageStyleNormal",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_default--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_default--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Normal",\
        "mixBlendMode": "normal"\
      }\
    }\
  },\
\
  "theme_image_greyscale": {\
    "meta": {\
      "name": "kCPImageStyleGreyscale",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_greyscale--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_greyscale--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Greyscale",\
        "mixBlendMode": "saturation",\
        "intensity": "var(--theme_image_greyscale--intensity)",\
        "filterColor": {\
          "fill": "#000000",\
          "fillOpacity": 1\
        }\
      }\
    }\
  },\
\
  "theme_image_lighten": {\
    "meta": {\
      "name": "kCPImageStyleLighten",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_lighten--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_lighten--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Lighten",\
        "mixBlendMode": "soft-light",\
        "intensity": "var(--theme_image_lighten--intensity)",\
        "filterColor": {\
          "fill": "#FFFFFF",\
          "fillOpacity": 1\
        }\
      }\
    }\
  },\
\
  "theme_image_darken": {\
    "meta": {\
      "name": "kCPImageStyleDarken",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_darken--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_darken--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Darken",\
        "mixBlendMode": "soft-light",\
        "intensity": "var(--theme_image_darken--intensity)",\
        "filterColor": {\
          "fill": "var(--black)",\
          "fillOpacity": 1\
        }\
      }\
    }\
  },\
\
  "theme_image_overlay": {\
    "meta": {\
      "name": "kCPImageStyleOverlay",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_overlay--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_overlay--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Overlay",\
        "mixBlendMode": "overlay",\
        "intensity": "var(--theme_image_overlay--intensity)",\
        "filterColor": {\
          "fill": "var(--theme_image_overlay--primaryFillColor)",\
          "fillOpacity": 1,\
          "gradientProps": {\
            "linearGradientProps": {\
              "colorStops": [\
                {\
                  "color": "#378ef0",\
                  "alpha": 1,\
                  "scaledPosition": 0\
                },\
                {\
                  "color": "#1c4778",\
                  "alpha": 1,\
                  "scaledPosition": 1\
                }\
              ],\
              "endPoints": [\
                { "x": 50, "y": 0 },\
                { "x": 50, "y": 100 }\
              ]\
            },\
            "radialGradientProps": {\
              "colorStops": [\
                {\
                  "color": "#378ef0",\
                  "alpha": 1,\
                  "scaledPosition": 0\
                },\
                {\
                  "color": "#1c4778",\
                  "alpha": 1,\
                  "scaledPosition": 1\
                }\
              ],\
              "endPoints": [\
                { "x": 50, "y": 50 },\
                { "x": 100, "y": 50 }\
              ],\
              "radialHandlePoints": [\
                { "x": 50, "y": 100 },\
                { "x": 100, "y": 100 }\
              ]\
            }\
          }\
        }\
      }\
    }\
  },\
\
  "theme_image_colorize": {\
    "meta": {\
      "name": "kCPImageStyleColorize",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_colorize--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_colorize--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Colorize",\
        "mixBlendMode": "color",\
        "intensity": "var(--theme_image_colorize--intensity)",\
        "filterColor": {\
          "fill": "var(--theme_image_colorize--primaryFillColor)",\
          "fillOpacity": 1,\
          "gradientProps": {\
            "linearGradientProps": {\
              "colorStops": [\
                {\
                  "color": "#378ef0",\
                  "alpha": 1,\
                  "scaledPosition": 0\
                },\
                {\
                  "color": "#1c4778",\
                  "alpha": 1,\
                  "scaledPosition": 1\
                }\
              ],\
              "endPoints": [\
                { "x": 50, "y": 0 },\
                { "x": 50, "y": 100 }\
              ]\
            },\
            "radialGradientProps": {\
              "colorStops": [\
                {\
                  "color": "#378ef0",\
                  "alpha": 1,\
                  "scaledPosition": 0\
                },\
                {\
                  "color": "#1c4778",\
                  "alpha": 1,\
                  "scaledPosition": 1\
                }\
              ],\
              "endPoints": [\
                { "x": 50, "y": 50 },\
                { "x": 100, "y": 50 }\
              ],\
              "radialHandlePoints": [\
                { "x": 50, "y": 100 },\
                { "x": 100, "y": 100 }\
              ]\
            }\
          }\
        }\
      }\
    }\
  }\
}\
',
meta:'{\
  "name": "kCPThemeLight",\
  "description": "kCPThemeLightDescription",\
  "version": 0.1,\
  "guid": "Default-Light-Theme",\
  "default_presets": {\
    "0": "cp_default_shape_solid_style",\
    "1": "text-body-1",\
    "2": "theme_image_default",\
    "3": "cp_default_slide_style",\
    "4": "cp_textinshape_body_1",\
    "5": "cp_default_line_shape_style",\
    "6": "cp_default_complex_shape_solid_style",\
    "7": "cp_button_style_1_textonly",\
    "8": "cp_checkbox_style_1_textonly",\
    "9": "cp_svg_style",\
    "10": "cp_dropDown_style_1",\
    "11": "cp_radiobutton_style_1_textonly",\
    "12": "cp_inputField_style_1",\
    "13": "cp_clickbox_style",\
    "14": "cp_responsive_container_style",\
    "15": "cp_default_shape_solid_style"\
  },\
  "color_palettes": [\
    {\
      "name": "Light Palette - 1",\
      "colors": [\
        "var(--color1)",\
        "var(--color2)",\
        "var(--color3)",\
        "var(--color4)",\
        "var(--color5)",\
        "var(--color6)",\
        "var(--color7)",\
        "var(--color5_light)",\
        "var(--color4_dark)"\
      ]\
    }\
  ],\
  "active_color_palette": 0\
}',
other_presets:'{\
  "cp_default_slide_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "type": 3,\
      "category": 0\
    },\
    "backgroundColor": "var(--palette-color1)",\
    "outlineColor": "var(--palette-color5)",\
    "outlineWidth": 1,\
    "outlineStyle": "solid",\
    "outlineCap": "butt",\
    "fill": "var(--palette-color1)",\
    "fillOpacity": 1,\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color2)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 0,\
            "y": 0\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color2)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_responsive_container_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 14,\
      "category": 0\
    },\
    "fill": "var(--palette-color6)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": 1,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color1)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_correct": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--success)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_incorrect": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--error)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_incomplete": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--incomplete)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_hint": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--hint)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_retry": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--retry)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_timeout": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--timeout)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_shape_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color6)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color1)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_shape_linear_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color1)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_shape_radial_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color1)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  }\
}',
theme:'{\
  "--primary": "#F1EEE6",\
\
  "--color1": "#FFFFFF",\
  "--color2": "#F8F7F4",\
  "--color3": "#F1EEE6",\
  "--color4": "#D6D5D1",\
  "--color5": "#666666",\
  "--color6": "#333333",\
  "--color7": "#020C1C",\
  "--colorC7": "#F7F7F7",\
  "--disabledC12": "#989898",\
  "--color1_light": "#FFCD74",\
  "--color1_dark": "#C76D12",\
  "--color2_light": "#86FFFF",\
  "--color2_dark": "#00ACCC",\
  "--color3_light": "#9B5DFF",\
  "--color3_dark": "#0000CA",\
  "--color4_light": "#99FF99",\
  "--color4_dark": "#112FA7",\
  "--color5_light": "#163EE5",\
  "--color5_dark": "#00CB92",\
  "--color6_light": "#7697FF",\
  "--color6_dark": "#0040CB",\
  "--color7_light": "#FF8E64",\
  "--color7_dark": "#C5230B",\
\
  "--success": "#558564",\
  "--error": "#C83E4D",\
  "--hint": "#CB6F10",\
  "--incomplete":"#E8BD2B",\
  "--timeout": "#C74545",\
  "--retry": "#CB6F10",\
  "--white": "#ffffff",\
  "--black": "#000000",\
\
  "--greyscale1": "#FFFFFF",\
  "--greyscale2": "#F1EEE61F",\
  "--greyscale3": "#B3B3B3",\
  "--greyscale4": "#4B4B4B",\
  "--greyscale5": "#333333",\
  "--disabled": "#818181",\
\
  "--palette-color0": "var(--color1)",\
  "--palette-color1": "var(--color2)",\
  "--palette-color2": "var(--color3)",\
  "--palette-color3": "var(--color4)",\
  "--palette-color4": "var(--color5)",\
  "--palette-color5": "var(--color6)",\
  "--palette-color6": "var(--color7)",\
  "--palette-color7": "var(--color5_light)",\
  "--palette-color8": "var(--color4_dark)",\
\
  "--design-option-color1": "255, 255, 255",\
  "--design-option-color2": "248, 247, 244",\
  "--design-option-color3": "241, 238, 230",\
  "--design-option-color4": "214, 213, 209",\
  "--design-option-color5": "102, 102, 102",\
  "--design-option-color6": "51, 51, 51",\
  "--design-option-color7": "2, 12, 28",\
  "--design-option-color5_light": "22, 62, 229",\
  "--design-option-color4_dark": "17, 47, 167",\
\
  "--c1": "var(--design-option-color1)",\
  "--c2": "var(--design-option-color2)",\
  "--c3": "var(--design-option-color3)",\
  "--c4": "var(--design-option-color4)",\
  "--c5": "var(--design-option-color5)",\
  "--c6": "var(--design-option-color6)",\
  "--c7": "var(--design-option-color7)",\
  "--c8": "var(--design-option-color5_light)",\
  "--c9": "var(--design-option-color4_dark)",\
  \
  "--widget-container--fillcolor": "var(--palette-color1)",\
\
  "--font1": "Georgia",\
  "--font2": "Arial",\
  "--text-style-unset": "none",\
\
  "--text-heading-1--fontSize--desktop": "120px",\
  "--text-heading-1--fontSize--tablet": "100px",\
  "--text-heading-1--fontSize--mobile": "80px",\
  "--text-heading-1--fontFamily": "var(--font1)",\
  "--text-heading-1--fontWeight": "normal",\
  "--text-heading-1--fontType": "regular",\
  "--text-heading-1--fontStyle": "normal",\
  "--text-heading-1--fontStretch": "normal",\
  "--text-heading-1--lineHeight": "1.07",\
  "--text-heading-1--marginLeft": "0px",\
  "--text-heading-1--color": "var(--palette-color6)",\
  "--text-heading-1--borderBottomStyle": "none",\
  "--text-heading-1--textDecoration": "none",\
  "--text-heading-1--letterSpacing": "-0.01",\
  "--text-heading-1--textTransform": "none",\
  "--text-heading-1--stroke": "var(--palette-color2)",\
  "--text-heading-1--textAlign": "left",\
  "--text-heading-1--justifyContent": "flex-start",\
  "--text-heading-1--marginTop": "auto",\
  "--text-heading-1--marginBottom": "0",\
  "--text-heading-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-1--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-2--fontSize--desktop": "80px",\
  "--text-heading-2--fontSize--tablet": "72px",\
  "--text-heading-2--fontSize--mobile": "60px",\
  "--text-heading-2--fontFamily": "var(--font1)",\
  "--text-heading-2--fontWeight": "normal",\
  "--text-heading-2--fontType": "regular",\
  "--text-heading-2--fontStyle": "normal",\
  "--text-heading-2--fontStretch": "normal",\
  "--text-heading-2--lineHeight": "1.1",\
  "--text-heading-2--marginLeft": "0px",\
  "--text-heading-2--color": "var(--palette-color6)",\
  "--text-heading-2--borderBottomStyle": "none",\
  "--text-heading-2--textDecoration": "none",\
  "--text-heading-2--letterSpacing": "-0.04",\
  "--text-heading-2--textTransform": "none",\
  "--text-heading-2--stroke": "var(--palette-color2)",\
  "--text-heading-2--textAlign": "left",\
  "--text-heading-2--justifyContent": "flex-start",\
  "--text-heading-2--marginTop": "auto",\
  "--text-heading-2--marginBottom": "0",\
  "--text-heading-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-2--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-3--fontSize--desktop": "60px",\
  "--text-heading-3--fontSize--tablet": "52px",\
  "--text-heading-3--fontSize--mobile": "44px",\
  "--text-heading-3--fontFamily": "var(--font1)",\
  "--text-heading-3--fontWeight": "normal",\
  "--text-heading-3--fontType": "regular",\
  "--text-heading-3--fontStyle": "normal",\
  "--text-heading-3--fontStretch": "normal",\
  "--text-heading-3--lineHeight": "1.1",\
  "--text-heading-3--marginLeft": "0px",\
  "--text-heading-3--color": "var(--palette-color6)",\
  "--text-heading-3--borderBottomStyle": "none",\
  "--text-heading-3--textDecoration": "none",\
  "--text-heading-3--letterSpacing": "0.03",\
  "--text-heading-3--textTransform": "none",\
  "--text-heading-3--stroke": "var(--palette-color2)",\
  "--text-heading-3--textAlign": "left",\
  "--text-heading-3--justifyContent": "flex-start",\
  "--text-heading-3--marginTop": "auto",\
  "--text-heading-3--marginBottom": "0",\
  "--text-heading-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-3--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-4--fontSize--desktop": "52px",\
  "--text-heading-4--fontSize--tablet": "40px",\
  "--text-heading-4--fontSize--mobile": "32px",\
  "--text-heading-4--fontFamily": "var(--font1)",\
  "--text-heading-4--fontWeight": "normal",\
  "--text-heading-4--fontType": "regular",\
  "--text-heading-4--fontStyle": "normal",\
  "--text-heading-4--fontStretch": "normal",\
  "--text-heading-4--lineHeight": "1.15",\
  "--text-heading-4--marginLeft": "0px",\
  "--text-heading-4--color": "var(--palette-color6)",\
  "--text-heading-4--borderBottomStyle": "none",\
  "--text-heading-4--textDecoration": "none",\
  "--text-heading-4--letterSpacing": "0.10",\
  "--text-heading-4--textTransform": "uppercase",\
  "--text-heading-4--stroke": "var(--palette-color2)",\
  "--text-heading-4--textAlign": "left",\
  "--text-heading-4--justifyContent": "flex-start",\
  "--text-heading-4--marginTop": "auto",\
  "--text-heading-4--marginBottom": "0",\
  "--text-heading-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-4--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-5--fontSize--desktop": "40px",\
  "--text-heading-5--fontSize--tablet": "32px",\
  "--text-heading-5--fontSize--mobile": "28px",\
  "--text-heading-5--fontFamily": "var(--font1)",\
  "--text-heading-5--fontWeight": "normal",\
  "--text-heading-5--fontType": "regular",\
  "--text-heading-5--fontStyle": "normal",\
  "--text-heading-5--fontStretch": "normal",\
  "--text-heading-5--lineHeight": "1.2",\
  "--text-heading-5--marginLeft": "0px",\
  "--text-heading-5--color": "var(--palette-color6)",\
  "--text-heading-5--borderBottomStyle": "none",\
  "--text-heading-5--textDecoration": "none",\
  "--text-heading-5--letterSpacing": "0",\
  "--text-heading-5--textTransform": "none",\
  "--text-heading-5--stroke": "var(--palette-color2)",\
  "--text-heading-5--textAlign": "left",\
  "--text-heading-5--justifyContent": "flex-start",\
  "--text-heading-5--marginTop": "auto",\
  "--text-heading-5--marginBottom": "0",\
  "--text-heading-5--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-5--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-5--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-6--fontSize--desktop": "36px",\
  "--text-heading-6--fontSize--tablet": "28px",\
  "--text-heading-6--fontSize--mobile": "24px",\
  "--text-heading-6--fontFamily": "var(--font2)",\
  "--text-heading-6--fontWeight": "normal",\
  "--text-heading-6--fontType": "regular",\
  "--text-heading-6--fontStyle": "normal",\
  "--text-heading-6--fontStretch": "normal",\
  "--text-heading-6--lineHeight": "1.2",\
  "--text-heading-6--marginLeft": "0px",\
  "--text-heading-6--color": "var(--palette-color6)",\
  "--text-heading-6--borderBottomStyle": "none",\
  "--text-heading-6--textDecoration": "none",\
  "--text-heading-6--letterSpacing": "0",\
  "--text-heading-6--textTransform": "none",\
  "--text-heading-6--stroke": "var(--palette-color2)",\
  "--text-heading-6--textAlign": "left",\
  "--text-heading-6--justifyContent": "flex-start",\
  "--text-heading-6--marginTop": "auto",\
  "--text-heading-6--marginBottom": "0",\
  "--text-heading-6--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-6--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-6--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-7--fontSize--desktop": "20px",\
  "--text-heading-7--fontSize--tablet": "20px",\
  "--text-heading-7--fontSize--mobile": "20px",\
  "--text-heading-7--fontFamily": "var(--font1)",\
  "--text-heading-7--fontWeight": "normal",\
  "--text-heading-7--fontType": "regular",\
  "--text-heading-7--fontStyle": "normal",\
  "--text-heading-7--fontStretch": "normal",\
  "--text-heading-7--lineHeight": "1.35",\
  "--text-heading-7--marginLeft": "0px",\
  "--text-heading-7--color": "var(--palette-color5)",\
  "--text-heading-7--borderBottomStyle": "none",\
  "--text-heading-7--textDecoration": "none",\
  "--text-heading-7--letterSpacing": "0",\
  "--text-heading-7--textTransform": "none",\
  "--text-heading-7--stroke": "var(--palette-color2)",\
  "--text-heading-7--textAlign": "left",\
  "--text-heading-7--justifyContent": "flex-start",\
  "--text-heading-7--marginTop": "auto",\
  "--text-heading-7--marginBottom": "0",\
  "--text-heading-7--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-7--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-7--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-7--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-8--fontSize--desktop": "72px",\
  "--text-heading-8--fontSize--tablet": "48px",\
  "--text-heading-8--fontSize--mobile": "32px",\
  "--text-heading-8--fontFamily": "var(--font1)",\
  "--text-heading-8--fontWeight": "normal",\
  "--text-heading-8--fontType": "regular",\
  "--text-heading-8--fontStyle": "normal",\
  "--text-heading-8--fontStretch": "normal",\
  "--text-heading-8--lineHeight": "1.35",\
  "--text-heading-8--marginLeft": "0px",\
  "--text-heading-8--color": "var(--palette-color5)",\
  "--text-heading-8--borderBottomStyle": "none",\
  "--text-heading-8--textDecoration": "none",\
  "--text-heading-8--letterSpacing": "0",\
  "--text-heading-8--textTransform": "none",\
  "--text-heading-8--stroke": "var(--palette-color2)",\
  "--text-heading-8--textAlign": "center",\
  "--text-heading-8--justifyContent": "flex-start",\
  "--text-heading-8--marginTop": "auto",\
  "--text-heading-8--marginBottom": "0",\
  "--text-heading-8--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-8--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-8--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-8--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-9--fontSize--desktop": "32px",\
  "--text-heading-9--fontSize--tablet": "32px",\
  "--text-heading-9--fontSize--mobile": "32px",\
  "--text-heading-9--fontFamily": "var(--font1)",\
  "--text-heading-9--fontWeight": "normal",\
  "--text-heading-9--fontType": "regular",\
  "--text-heading-9--fontStyle": "normal",\
  "--text-heading-9--fontStretch": "normal",\
  "--text-heading-9--lineHeight": "1.35",\
  "--text-heading-9--marginLeft": "0px",\
  "--text-heading-9--color": "var(--palette-color5)",\
  "--text-heading-9--borderBottomStyle": "none",\
  "--text-heading-9--textDecoration": "none",\
  "--text-heading-9--letterSpacing": "0",\
  "--text-heading-9--textTransform": "none",\
  "--text-heading-9--stroke": "var(--palette-color2)",\
  "--text-heading-9--textAlign": "center",\
  "--text-heading-9--justifyContent": "flex-start",\
  "--text-heading-9--marginTop": "auto",\
  "--text-heading-9--marginBottom": "0",\
  "--text-heading-9--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-9--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-9--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-9--textShadow": "var(--text-style-unset)",\
\
  "--text-body-1--fontSize--desktop": "22px",\
  "--text-body-1--fontSize--tablet": "20px",\
  "--text-body-1--fontSize--mobile": "18px",\
  "--text-body-1--fontFamily": "var(--font1)",\
  "--text-body-1--fontWeight": "normal",\
  "--text-body-1--fontType": "regular",\
  "--text-body-1--fontStyle": "normal",\
  "--text-body-1--fontStretch": "normal",\
  "--text-body-1--lineHeight": "1.3",\
  "--text-body-1--marginLeft": "0px",\
  "--text-body-1--color": "var(--palette-color5)",\
  "--text-body-1--borderBottomStyle": "none",\
  "--text-body-1--textDecoration": "none",\
  "--text-body-1--letterSpacing": "0",\
  "--text-body-1--textTransform": "none",\
  "--text-body-1--stroke": "var(--palette-color2)",\
  "--text-body-1--textAlign": "left",\
  "--text-body-1--justifyContent": "flex-start",\
  "--text-body-1--marginTop": "auto",\
  "--text-body-1--marginBottom": "0",\
  "--text-body-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-1--textShadow": "var(--text-style-unset)",\
\
  "--text-body-2--fontSize--desktop": "22px",\
  "--text-body-2--fontSize--tablet": "20px",\
  "--text-body-2--fontSize--mobile": "18px",\
  "--text-body-2--fontFamily": "var(--font2)",\
  "--text-body-2--fontWeight": "normal",\
  "--text-body-2--fontType": "regular",\
  "--text-body-2--fontStyle": "normal",\
  "--text-body-2--fontStretch": "normal",\
  "--text-body-2--lineHeight": "1.3",\
  "--text-body-2--marginLeft": "0px",\
  "--text-body-2--color": "var(--palette-color4)",\
  "--text-body-2--borderBottomStyle": "none",\
  "--text-body-2--textDecoration": "none",\
  "--text-body-2--letterSpacing": "0.03",\
  "--text-body-2--textTransform": "none",\
  "--text-body-2--Stroke": "var(--palette-color2)",\
  "--text-body-2--textAlign": "left",\
  "--text-body-2--justifyContent": "flex-start",\
  "--text-body-2--marginTop": "auto",\
  "--text-body-2--marginBottom": "0",\
  "--text-body-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-2--textShadow": "var(--text-style-unset)",\
\
  "--text-body-3--fontSize--desktop": "18px",\
  "--text-body-3--fontSize--tablet": "16px",\
  "--text-body-3--fontSize--mobile": "16px",\
  "--text-body-3--fontFamily": "var(--font1)",\
  "--text-body-3--fontWeight": "normal",\
  "--text-body-3--fontType": "regular",\
  "--text-body-3--fontStyle": "normal",\
  "--text-body-3--fontStretch": "normal",\
  "--text-body-3--lineHeight": "1.35",\
  "--text-body-3--marginLeft": "0px",\
  "--text-body-3--color": "var(--palette-color4)",\
  "--text-body-3--borderBottomStyle": "none",\
  "--text-body-3--textDecoration": "none",\
  "--text-body-3--letterSpacing": "0",\
  "--text-body-3--textTransform": "none",\
  "--text-body-3--Stroke": "var(--palette-color2)",\
  "--text-body-3--textAlign": "left",\
  "--text-body-3--justifyContent": "flex-start",\
  "--text-body-3--marginTop": "auto",\
  "--text-body-3--marginBottom": "0",\
  "--text-body-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-3--textShadow": "var(--text-style-unset)",\
\
  "--text-body-4--fontSize--desktop": "18px",\
  "--text-body-4--fontSize--tablet": "16px",\
  "--text-body-4--fontSize--mobile": "16px",\
  "--text-body-4--fontFamily": "var(--font2)",\
  "--text-body-4--fontWeight": "normal",\
  "--text-body-4--fontType": "regular",\
  "--text-body-4--fontStyle": "normal",\
  "--text-body-4--fontStretch": "normal",\
  "--text-body-4--lineHeight": "1.35",\
  "--text-body-4--marginLeft": "0px",\
  "--text-body-4--color": "var(--palette-color4)",\
  "--text-body-4--borderBottomStyle": "none",\
  "--text-body-4--textDecoration": "none",\
  "--text-body-4--letterSpacing": "0",\
  "--text-body-4--textTransform": "none",\
  "--text-body-4--Stroke": "var(--palette-color2)",\
  "--text-body-4--textAlign": "left",\
  "--text-body-4--justifyContent": "flex-start",\
  "--text-body-4--marginTop": "auto",\
  "--text-body-4--marginBottom": "0",\
  "--text-body-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-4--textShadow": "var(--text-style-unset)",\
\
  "--text-body-5--fontSize--desktop": "18px",\
  "--text-body-5--fontSize--tablet": "16px",\
  "--text-body-5--fontSize--mobile": "16px",\
  "--text-body-5--fontFamily": "var(--font1)",\
  "--text-body-5--fontWeight": "normal",\
  "--text-body-5--fontType": "italic",\
  "--text-body-5--fontStyle": "normal",\
  "--text-body-5--fontStretch": "normal",\
  "--text-body-5--lineHeight": "1.35",\
  "--text-body-5--marginLeft": "0px",\
  "--text-body-5--color": "var(--palette-color4)",\
  "--text-body-5--borderBottomStyle": "none",\
  "--text-body-5--textDecoration": "none",\
  "--text-body-5--letterSpacing": "0",\
  "--text-body-5--textTransform": "none",\
  "--text-body-5--Stroke": "var(--palette-color2)",\
  "--text-body-5--textAlign": "center",\
  "--text-body-5--justifyContent": "flex-start",\
  "--text-body-5--marginTop": "auto",\
  "--text-body-5--marginBottom": "0",\
  "--text-body-5--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-5--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-5--textShadow": "var(--text-style-unset)",\
\
  "--text-body-6--fontSize--desktop": "16px",\
  "--text-body-6--fontSize--tablet": "14px",\
  "--text-body-6--fontSize--mobile": "14px",\
  "--text-body-6--fontFamily": "var(--font2)",\
  "--text-body-6--fontWeight": "normal",\
  "--text-body-6--fontType": "regular",\
  "--text-body-6--fontStyle": "normal",\
  "--text-body-6--fontStretch": "normal",\
  "--text-body-6--lineHeight": "1.35",\
  "--text-body-6--marginLeft": "0px",\
  "--text-body-6--color": "var(--palette-color4)",\
  "--text-body-6--borderBottomStyle": "none",\
  "--text-body-6--textDecoration": "none",\
  "--text-body-6--letterSpacing": "0",\
  "--text-body-6--textTransform": "none",\
  "--text-body-6--Stroke": "var(--palette-color2)",\
  "--text-body-6--textAlign": "left",\
  "--text-body-6--justifyContent": "flex-start",\
  "--text-body-6--marginTop": "auto",\
  "--text-body-6--marginBottom": "0",\
  "--text-body-6--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-6--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-6--textShadow": "var(--text-style-unset)",\
\
  "--text-component-1--fontSize--desktop": "22px",\
  "--text-component-1--fontSize--tablet": "20px",\
  "--text-component-1--fontSize--mobile": "20px",\
  "--text-component-1--fontFamily": "var(--font1)",\
  "--text-component-1--fontWeight": "normal",\
  "--text-component-1--fontType": "regular",\
  "--text-component-1--fontStyle": "normal",\
  "--text-component-1--fontStretch": "normal",\
  "--text-component-1--lineHeight": "1.35",\
  "--text-component-1--marginLeft": "0px",\
  "--text-component-1--color": "var(--color6)",\
  "--text-component-1--borderBottomStyle": "none",\
  "--text-component-1--textDecoration": "none",\
  "--text-component-1--letterSpacing": "0",\
  "--text-component-1--textTransform": "none",\
  "--text-component-1--stroke": "var(--palette-color2)",\
  "--text-component-1--textAlign": "left",\
  "--text-component-1--justifyContent": "flex-start",\
  "--text-component-1--marginTop": "auto",\
  "--text-component-1--marginBottom": "0",\
  "--text-component-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-component-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-component-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-component-1--textShadow": "var(--text-style-unset)",\
\
  "--text-component-2--fontSize--desktop": "24px",\
  "--text-component-2--fontSize--tablet": "20px",\
  "--text-component-2--fontSize--mobile": "20px",\
  "--text-component-2--fontFamily": "var(--font1)",\
  "--text-component-2--fontWeight": "normal",\
  "--text-component-2--fontType": "regular",\
  "--text-component-2--fontStyle": "normal",\
  "--text-component-2--fontStretch": "normal",\
  "--text-component-2--lineHeight": "1.35",\
  "--text-component-2--marginLeft": "0px",\
  "--text-component-2--color": "var(--palette-color1)",\
  "--text-component-2--borderBottomStyle": "none",\
  "--text-component-2--textDecoration": "none",\
  "--text-component-2--letterSpacing": "0.16",\
  "--text-component-2--textTransform": "none",\
  "--text-component-2--stroke": "var(--palette-color2)",\
  "--text-component-2--textAlign": "left",\
  "--text-component-2--justifyContent": "flex-start",\
  "--text-component-2--marginTop": "auto",\
  "--text-component-2--marginBottom": "0",\
  "--text-component-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-component-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-component-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-component-2--textShadow": "var(--text-style-unset)",\
\
  "--text-component-3--fontSize--desktop": "14px",\
  "--text-component-3--fontSize--tablet": "14px",\
  "--text-component-3--fontSize--mobile": "14px",\
  "--text-component-3--fontFamily": "var(--font1)",\
  "--text-component-3--fontWeight": "normal",\
  "--text-component-3--fontType": "regular",\
  "--text-component-3--fontStyle": "normal",\
  "--text-component-3--fontStretch": "normal",\
  "--text-component-3--lineHeight": "1.35",\
  "--text-component-3--marginLeft": "0px",\
  "--text-component-3--color": "var(--palette-color6)",\
  "--text-component-3--borderBottomStyle": "none",\
  "--text-component-3--textDecoration": "none",\
  "--text-component-3--letterSpacing": "0.2",\
  "--text-component-3--textTransform": "uppercase",\
  "--text-component-3--stroke": "var(--palette-color2)",\
  "--text-component-3--textAlign": "center",\
  "--text-component-3--justifyContent": "flex-start",\
  "--text-component-3--marginTop": "auto",\
  "--text-component-3--marginBottom": "0",\
  "--text-component-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-component-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-component-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-component-3--textShadow": "var(--text-style-unset)",\
\
  "--text-component-4--fontSize--desktop": "22px",\
  "--text-component-4--fontSize--tablet": "20px",\
  "--text-component-4--fontSize--mobile": "20px",\
  "--text-component-4--fontFamily": "var(--font1)",\
  "--text-component-4--fontWeight": "normal",\
  "--text-component-4--fontType": "regular",\
  "--text-component-4--fontStyle": "normal",\
  "--text-component-4--fontStretch": "normal",\
  "--text-component-4--lineHeight": "1.35",\
  "--text-component-4--marginLeft": "0px",\
  "--text-component-4--color": "var(--color6)",\
  "--text-component-4--borderBottomStyle": "none",\
  "--text-component-4--textDecoration": "none",\
  "--text-component-4--letterSpacing": "0.02",\
  "--text-component-4--textTransform": "none",\
  "--text-component-4--stroke": "var(--palette-color2)",\
  "--text-component-4--textAlign": "left",\
  "--text-component-4--justifyContent": "flex-start",\
  "--text-component-4--marginTop": "auto",\
  "--text-component-4--marginBottom": "0",\
  "--text-component-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-component-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-component-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-component-4--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-1--fontSize--desktop": "36px",\
  "--text-subheading-1--fontSize--tablet": "32px",\
  "--text-subheading-1--fontSize--mobile": "28px",\
  "--text-subheading-1--fontFamily": "var(--font2)",\
  "--text-subheading-1--fontWeight": "normal",\
  "--text-subheading-1--fontType": "regular",\
  "--text-subheading-1--fontStyle": "normal",\
  "--text-subheading-1--fontStretch": "normal",\
  "--text-subheading-1--lineHeight": "1.1",\
  "--text-subheading-1--marginLeft": "0px",\
  "--text-subheading-1--color": "var(--palette-color6)",\
  "--text-subheading-1--borderBottomStyle": "none",\
  "--text-subheading-1--textDecoration": "none",\
  "--text-subheading-1--letterSpacing": "0.05",\
  "--text-subheading-1--textTransform": "uppercase",\
  "--text-subheading-1--stroke": "var(--palette-color2)",\
  "--text-subheading-1--textAlign": "left",\
  "--text-subheading-1--justifyContent": "flex-start",\
  "--text-subheading-1--marginTop": "auto",\
  "--text-subheading-1--marginBottom": "0",\
  "--text-subheading-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-1--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-2--fontSize--desktop": "28px",\
  "--text-subheading-2--fontSize--tablet": "24px",\
  "--text-subheading-2--fontSize--mobile": "20px",\
  "--text-subheading-2--fontFamily": "var(--font2)",\
  "--text-subheading-2--fontWeight": "normal",\
  "--text-subheading-2--fontType": "bold",\
  "--text-subheading-2--fontStyle": "normal",\
  "--text-subheading-2--fontStretch": "normal",\
  "--text-subheading-2--lineHeight": "1.15",\
  "--text-subheading-2--marginLeft": "0px",\
  "--text-subheading-2--color": "var(--palette-color6)",\
  "--text-subheading-2--borderBottomStyle": "none",\
  "--text-subheading-2--textDecoration": "none",\
  "--text-subheading-2--letterSpacing": "0.05",\
  "--text-subheading-2--textTransform": "none",\
  "--text-subheading-2--stroke": "var(--palette-color2)",\
  "--text-subheading-2--textAlign": "left",\
  "--text-subheading-2--justifyContent": "flex-start",\
  "--text-subheading-2--marginTop": "auto",\
  "--text-subheading-2--marginBottom": "0",\
  "--text-subheading-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-2--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-3--fontSize--desktop": "26px",\
  "--text-subheading-3--fontSize--tablet": "22px",\
  "--text-subheading-3--fontSize--mobile": "18px",\
  "--text-subheading-3--fontFamily": "var(--font2)",\
  "--text-subheading-3--fontWeight": "normal",\
  "--text-subheading-3--fontType": "regular",\
  "--text-subheading-3--fontStyle": "normal",\
  "--text-subheading-3--fontStretch": "normal",\
  "--text-subheading-3--lineHeight": "1.15",\
  "--text-subheading-3--marginLeft": "0px",\
  "--text-subheading-3--color": "var(--palette-color6)",\
  "--text-subheading-3--borderBottomStyle": "none",\
  "--text-subheading-3--textDecoration": "none",\
  "--text-subheading-3--letterSpacing": "0",\
  "--text-subheading-3--textTransform": "none",\
  "--text-subheading-3--stroke": "var(--palette-color2)",\
  "--text-subheading-3--textAlign": "center",\
  "--text-subheading-3--justifyContent": "flex-start",\
  "--text-subheading-3--marginTop": "auto",\
  "--text-subheading-3--marginBottom": "0",\
  "--text-subheading-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-3--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-4--fontSize--desktop": "24px",\
  "--text-subheading-4--fontSize--tablet": "20px",\
  "--text-subheading-4--fontSize--mobile": "16px",\
  "--text-subheading-4--fontFamily": "var(--font2)",\
  "--text-subheading-4--fontWeight": "normal",\
  "--text-subheading-4--fontType": "bold",\
  "--text-subheading-4--fontStyle": "normal",\
  "--text-subheading-4--fontStretch": "normal",\
  "--text-subheading-4--lineHeight": "1.15",\
  "--text-subheading-4--marginLeft": "0px",\
  "--text-subheading-4--color": "var(--palette-color0)",\
  "--text-subheading-4--borderBottomStyle": "none",\
  "--text-subheading-4--textDecoration": "none",\
  "--text-subheading-4--letterSpacing": "0.05",\
  "--text-subheading-4--textTransform": "none",\
  "--text-subheading-4--stroke": "var(--palette-color2)",\
  "--text-subheading-4--textAlign": "left",\
  "--text-subheading-4--justifyContent": "flex-start",\
  "--text-subheading-4--marginTop": "auto",\
  "--text-subheading-4--marginBottom": "0",\
  "--text-subheading-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-4--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-5--fontSize--desktop": "24px",\
  "--text-subheading-5--fontSize--tablet": "20px",\
  "--text-subheading-5--fontSize--mobile": "16px",\
  "--text-subheading-5--fontFamily": "var(--font1)",\
  "--text-subheading-5--fontWeight": "normal",\
  "--text-subheading-5--fontType": "bold",\
  "--text-subheading-5--fontStyle": "normal",\
  "--text-subheading-5--fontStretch": "normal",\
  "--text-subheading-5--lineHeight": "1.15",\
  "--text-subheading-5--marginLeft": "0px",\
  "--text-subheading-5--color": "var(--palette-color5)",\
  "--text-subheading-5--borderBottomStyle": "none",\
  "--text-subheading-5--textDecoration": "none",\
  "--text-subheading-5--letterSpacing": "-0.05",\
  "--text-subheading-5--textTransform": "none",\
  "--text-subheading-5--stroke": "var(--palette-color2)",\
  "--text-subheading-5--textAlign": "left",\
  "--text-subheading-5--justifyContent": "flex-start",\
  "--text-subheading-5--marginTop": "auto",\
  "--text-subheading-5--marginBottom": "0",\
  "--text-subheading-5--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-5--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-5--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-6--fontSize--desktop": "18px",\
  "--text-subheading-6--fontSize--tablet": "16px",\
  "--text-subheading-6--fontSize--mobile": "14px",\
  "--text-subheading-6--fontFamily": "var(--font2)",\
  "--text-subheading-6--fontWeight": "normal",\
  "--text-subheading-6--fontType": "bold",\
  "--text-subheading-6--fontStyle": "normal",\
  "--text-subheading-6--fontStretch": "normal",\
  "--text-subheading-6--lineHeight": "1.25",\
  "--text-subheading-6--marginLeft": "0px",\
  "--text-subheading-6--color": "var(--palette-color5)",\
  "--text-subheading-6--borderBottomStyle": "none",\
  "--text-subheading-6--textDecoration": "none",\
  "--text-subheading-6--letterSpacing": "0",\
  "--text-subheading-6--textTransform": "none",\
  "--text-subheading-6--stroke": "var(--palette-color2)",\
  "--text-subheading-6--textAlign": "left",\
  "--text-subheading-6--justifyContent": "flex-start",\
  "--text-subheading-6--marginTop": "auto",\
  "--text-subheading-6--marginBottom": "0",\
  "--text-subheading-6--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-6--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-6--textShadow": "var(--text-style-unset)",\
\
  "--text-detail-1--fontSize--desktop": "20px",\
  "--text-detail-1--fontSize--tablet": "18px",\
  "--text-detail-1--fontSize--mobile": "16px",\
  "--text-detail-1--fontFamily": "var(--font2)",\
  "--text-detail-1--fontWeight": "normal",\
  "--text-detail-1--fontType": "regular",\
  "--text-detail-1--fontStyle": "normal",\
  "--text-detail-1--fontStretch": "normal",\
  "--text-detail-1--lineHeight": "1.2",\
  "--text-detail-1--marginLeft": "0px",\
  "--text-detail-1--color": "var(--palette-color6)",\
  "--text-detail-1--borderBottomStyle": "none",\
  "--text-detail-1--textDecoration": "none",\
  "--text-detail-1--letterSpacing": "0",\
  "--text-detail-1--textTransform": "uppercase",\
  "--text-detail-1--stroke": "var(--palette-color5)",\
  "--text-detail-1--textAlign": "left",\
  "--text-detail-1--justifyContent": "flex-start",\
  "--text-detail-1--marginTop": "auto",\
  "--text-detail-1--marginBottom": "0",\
  "--text-detail-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-detail-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-detail-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-detail-1--textShadow": "var(--text-style-unset)",\
\
  "--text-detail-2--fontSize--desktop": "16px",\
  "--text-detail-2--fontSize--tablet": "14px",\
  "--text-detail-2--fontSize--mobile": "12px",\
  "--text-detail-2--fontFamily": "var(--font2)",\
  "--text-detail-2--fontWeight": "normal",\
  "--text-detail-2--fontType": "bold",\
  "--text-detail-2--fontStyle": "normal",\
  "--text-detail-2--fontStretch": "normal",\
  "--text-detail-2--lineHeight": "1.3",\
  "--text-detail-2--marginLeft": "0px",\
  "--text-detail-2--color": "var(--palette-color6)",\
  "--text-detail-2--borderBottomStyle": "none",\
  "--text-detail-2--textDecoration": "none",\
  "--text-detail-2--letterSpacing": "0",\
  "--text-detail-2--textTransform": "uppercase",\
  "--text-detail-2--stroke": "var(--palette-color2)",\
  "--text-detail-2--textAlign": "left",\
  "--text-detail-2--justifyContent": "flex-start",\
  "--text-detail-2--marginTop": "auto",\
  "--text-detail-2--marginBottom": "0",\
  "--text-detail-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-detail-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-detail-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-detail-2--textShadow": "var(--text-style-unset)",\
\
  "--text-detail-3--fontSize--desktop": "16px",\
  "--text-detail-3--fontSize--tablet": "14px",\
  "--text-detail-3--fontSize--mobile": "12px",\
  "--text-detail-3--fontFamily": "var(--font2)",\
  "--text-detail-3--fontWeight": "normal",\
  "--text-detail-3--fontType": "regular",\
  "--text-detail-3--fontStyle": "normal",\
  "--text-detail-3--fontStretch": "normal",\
  "--text-detail-3--lineHeight": "1.35",\
  "--text-detail-3--marginLeft": "0px",\
  "--text-detail-3--color": "var(--palette-color4)",\
  "--text-detail-3--borderBottomStyle": "none",\
  "--text-detail-3--textDecoration": "none",\
  "--text-detail-3--letterSpacing": "0.2",\
  "--text-detail-3--textTransform": "uppercase",\
  "--text-detail-3--stroke": "var(--palette-color2)",\
  "--text-detail-3--textAlign": "left",\
  "--text-detail-3--justifyContent": "flex-start",\
  "--text-detail-3--marginTop": "auto",\
  "--text-detail-3--marginBottom": "0",\
  "--text-detail-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-detail-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-detail-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-detail-3--textShadow": "var(--text-style-unset)",\
\
  "--text-detail-4--fontSize--desktop": "22px",\
  "--text-detail-4--fontSize--tablet": "20px",\
  "--text-detail-4--fontSize--mobile": "20px",\
  "--text-detail-4--fontFamily": "var(--font1)",\
  "--text-detail-4--fontWeight": "normal",\
  "--text-detail-4--fontType": "regular",\
  "--text-detail-4--fontStyle": "normal",\
  "--text-detail-4--fontStretch": "normal",\
  "--text-detail-4--lineHeight": "1.35",\
  "--text-detail-4--marginLeft": "0px",\
  "--text-detail-4--color": "var(--palette-color5)",\
  "--text-detail-4--borderBottomStyle": "none",\
  "--text-detail-4--textDecoration": "none",\
  "--text-detail-4--letterSpacing": "0",\
  "--text-detail-4--textTransform": "none",\
  "--text-detail-4--stroke": "var(--palette-color2)",\
  "--text-detail-4--textAlign": "center",\
  "--text-detail-4--justifyContent": "flex-start",\
  "--text-detail-4--marginTop": "auto",\
  "--text-detail-4--marginBottom": "0",\
  "--text-detail-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-detail-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-detail-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-detail-4--textShadow": "var(--text-style-unset)",\
\
  "--text-variable-1--fontSize--desktop": "36px",\
  "--text-variable-1--fontSize--tablet": "32px",\
  "--text-variable-1--fontSize--mobile": "30px",\
  "--text-variable-1--fontFamily": "var(--font2)",\
  "--text-variable-1--fontWeight": "normal",\
  "--text-variable-1--fontType": "bold",\
  "--text-variable-1--fontStyle": "normal",\
  "--text-variable-1--fontStretch": "normal",\
  "--text-variable-1--lineHeight": "1.2",\
  "--text-variable-1--marginLeft": "0px",\
  "--text-variable-1--color": "var(--palette-color7)",\
  "--text-variable-1--borderBottomStyle": "none",\
  "--text-variable-1--textDecoration": "none",\
  "--text-variable-1--letterSpacing": "0.02",\
  "--text-variable-1--textTransform": "none",\
  "--text-variable-1--stroke": "var(--palette-color2)",\
  "--text-variable-1--textAlign": "left",\
  "--text-variable-1--justifyContent": "flex-start",\
  "--text-variable-1--marginTop": "auto",\
  "--text-variable-1--marginBottom": "0",\
  "--text-variable-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-variable-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-variable-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-variable-1--textShadow": "var(--text-style-unset)",\
\
  "--text-variable-2--fontSize--desktop": "24px",\
  "--text-variable-2--fontSize--tablet": "22px",\
  "--text-variable-2--fontSize--mobile": "20px",\
  "--text-variable-2--fontFamily": "var(--font2)",\
  "--text-variable-2--fontWeight": "normal",\
  "--text-variable-2--fontType": "bold",\
  "--text-variable-2--fontStyle": "normal",\
  "--text-variable-2--fontStretch": "normal",\
  "--text-variable-2--lineHeight": "1.15",\
  "--text-variable-2--marginLeft": "0px",\
  "--text-variable-2--color": "var(--palette-color6)",\
  "--text-variable-2--borderBottomStyle": "none",\
  "--text-variable-2--textDecoration": "none",\
  "--text-variable-2--letterSpacing": "0",\
  "--text-variable-2--textTransform": "none",\
  "--text-variable-2--stroke": "var(--palette-color2)",\
  "--text-variable-2--textAlign": "left",\
  "--text-variable-2--justifyContent": "flex-start",\
  "--text-variable-2--marginTop": "auto",\
  "--text-variable-2--marginBottom": "0",\
  "--text-variable-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-variable-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-variable-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-variable-2--textShadow": "var(--text-style-unset)",\
\
  "--text-variable-3--fontSize--desktop": "20px",\
  "--text-variable-3--fontSize--tablet": "18px",\
  "--text-variable-3--fontSize--mobile": "16px",\
  "--text-variable-3--fontFamily": "var(--font1)",\
  "--text-variable-3--fontWeight": "normal",\
  "--text-variable-3--fontType": "bold",\
  "--text-variable-3--fontStyle": "normal",\
  "--text-variable-3--fontStretch": "normal",\
  "--text-variable-3--lineHeight": "1.2",\
  "--text-variable-3--marginLeft": "0px",\
  "--text-variable-3--color": "var(--palette-color6)",\
  "--text-variable-3--borderBottomStyle": "none",\
  "--text-variable-3--textDecoration": "none",\
  "--text-variable-3--letterSpacing": "0",\
  "--text-variable-3--textTransform": "none",\
  "--text-variable-3--stroke": "var(--palette-color2)",\
  "--text-variable-3--textAlign": "left",\
  "--text-variable-3--justifyContent": "flex-start",\
  "--text-variable-3--marginTop": "auto",\
  "--text-variable-3--marginBottom": "0",\
  "--text-variable-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-variable-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-variable-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-variable-3--textShadow": "var(--text-style-unset)",\
\
  "--text-variable-4--fontSize--desktop": "16px",\
  "--text-variable-4--fontSize--tablet": "14px",\
  "--text-variable-4--fontSize--mobile": "12px",\
  "--text-variable-4--fontFamily": "var(--font2)",\
  "--text-variable-4--fontWeight": "normal",\
  "--text-variable-4--fontType": "bold",\
  "--text-variable-4--fontStyle": "normal",\
  "--text-variable-4--fontStretch": "normal",\
  "--text-variable-4--lineHeight": "1.3",\
  "--text-variable-4--marginLeft": "0px",\
  "--text-variable-4--color": "var(--palette-color6)",\
  "--text-variable-4--borderBottomStyle": "none",\
  "--text-variable-4--textDecoration": "none",\
  "--text-variable-4--letterSpacing": "0.02",\
  "--text-variable-4--textTransform": "none",\
  "--text-variable-4--stroke": "var(--palette-color2)",\
  "--text-variable-4--textAlign": "left",\
  "--text-variable-4--justifyContent": "flex-start",\
  "--text-variable-4--marginTop": "auto",\
  "--text-variable-4--marginBottom": "0",\
  "--text-variable-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-variable-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-variable-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-variable-4--textShadow": "var(--text-style-unset)",\
\
  "--text-question-1--fontSize--desktop": "48px",\
  "--text-question-1--fontSize--tablet": "20px",\
  "--text-question-1--fontSize--mobile": "20px",\
  "--text-question-1--fontFamily": "var(--font1)",\
  "--text-question-1--fontWeight": "normal",\
  "--text-question-1--fontType": "regular",\
  "--text-question-1--fontStyle": "normal",\
  "--text-question-1--fontStretch": "normal",\
  "--text-question-1--lineHeight": "1.35",\
  "--text-question-1--marginLeft": "0px",\
  "--text-question-1--color": "var(--palette-color5)",\
  "--text-question-1--borderBottomStyle": "none",\
  "--text-question-1--textDecoration": "none",\
  "--text-question-1--letterSpacing": "0",\
  "--text-question-1--textTransform": "none",\
  "--text-question-1--stroke": "var(--palette-color2)",\
  "--text-question-1--textAlign": "left",\
  "--text-question-1--justifyContent": "flex-start",\
  "--text-question-1--marginTop": "auto",\
  "--text-question-1--marginBottom": "0",\
  "--text-question-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-question-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-question-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-question-1--textShadow": "var(--text-style-unset)",\
\
  "--text-question-2--fontSize--desktop": "24px",\
  "--text-question-2--fontSize--tablet": "20px",\
  "--text-question-2--fontSize--mobile": "20px",\
  "--text-question-2--fontFamily": "var(--font1)",\
  "--text-question-2--fontWeight": "normal",\
  "--text-question-2--fontType": "bold",\
  "--text-question-2--fontStyle": "normal",\
  "--text-question-2--fontStretch": "normal",\
  "--text-question-2--lineHeight": "1.35",\
  "--text-question-2--marginLeft": "0px",\
  "--text-question-2--color": "var(--palette-color5)",\
  "--text-question-2--borderBottomStyle": "none",\
  "--text-question-2--textDecoration": "none",\
  "--text-question-2--letterSpacing": "0",\
  "--text-question-2--textTransform": "none",\
  "--text-question-2--stroke": "var(--palette-color2)",\
  "--text-question-2--textAlign": "left",\
  "--text-question-2--justifyContent": "flex-start",\
  "--text-question-2--marginTop": "auto",\
  "--text-question-2--marginBottom": "0",\
  "--text-question-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-question-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-question-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-question-2--textShadow": "var(--text-style-unset)",\
\
  "--text-button-1--fontSize--desktop": "16px",\
  "--text-button-1--fontSize--tablet": "16px",\
  "--text-button-1--fontSize--mobile": "16px",\
  "--text-button-1--fontFamily": "var(--font2)",\
  "--text-button-1--fontWeight": "normal",\
  "--text-button-1--fontType": "regular",\
  "--text-button-1--fontStyle": "normal",\
  "--text-button-1--fontStretch": "normal",\
  "--text-button-1--lineHeight": "1.25",\
  "--text-button-1--marginLeft": "0px",\
  "--text-button-1--color": "var(--palette-color7)",\
  "--text-button-1--borderBottomStyle": "none",\
  "--text-button-1--textDecoration": "none",\
  "--text-button-1--letterSpacing": "0.12",\
  "--text-button-1--textTransform": "uppercase",\
  "--text-button-1--stroke": "var(--palette-color2)",\
  "--text-button-1--textAlign": "center",\
  "--text-button-1--justifyContent": "flex-start",\
  "--text-button-1--marginTop": "auto",\
  "--text-button-1--marginBottom": "0",\
  "--text-button-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-button-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-button-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-button-1--textShadow": "var(--text-style-unset)",\
\
  "--text-button-2--fontSize--desktop": "16px",\
  "--text-button-2--fontSize--tablet": "16px",\
  "--text-button-2--fontSize--mobile": "16px",\
  "--text-button-2--fontFamily": "var(--font2)",\
  "--text-button-2--fontWeight": "normal",\
  "--text-button-2--fontType": "regular",\
  "--text-button-2--fontStyle": "normal",\
  "--text-button-2--fontStretch": "normal",\
  "--text-button-2--lineHeight": "1.25",\
  "--text-button-2--marginLeft": "0px",\
  "--text-button-2--color": "var(--palette-color0)",\
  "--text-button-2--borderBottomStyle": "none",\
  "--text-button-2--textDecoration": "none",\
  "--text-button-2--letterSpacing": "0.12",\
  "--text-button-2--textTransform": "uppercase",\
  "--text-button-2--stroke": "var(--palette-color2)",\
  "--text-button-2--textAlign": "center",\
  "--text-button-2--justifyContent": "flex-start",\
  "--text-button-2--marginTop": "auto",\
  "--text-button-2--marginBottom": "0",\
  "--text-button-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-button-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-button-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-button-2--textShadow": "var(--text-style-unset)",\
\
  "--text-button-3--fontSize--desktop": "16px",\
  "--text-button-3--fontSize--tablet": "16px",\
  "--text-button-3--fontSize--mobile": "16px",\
  "--text-button-3--fontFamily": "var(--font2)",\
  "--text-button-3--fontWeight": "normal",\
  "--text-button-3--fontType": "regular",\
  "--text-button-3--fontStyle": "normal",\
  "--text-button-3--fontStretch": "normal",\
  "--text-button-3--lineHeight": "1.25",\
  "--text-button-3--marginLeft": "0px",\
  "--text-button-3--color": "var(--palette-color5)",\
  "--text-button-3--borderBottomStyle": "none",\
  "--text-button-3--textDecoration": "none",\
  "--text-button-3--letterSpacing": "0.12",\
  "--text-button-3--textTransform": "uppercase",\
  "--text-button-3--stroke": "var(--palette-color2)",\
  "--text-button-3--textAlign": "center",\
  "--text-button-3--justifyContent": "flex-start",\
  "--text-button-3--marginTop": "auto",\
  "--text-button-3--marginBottom": "0",\
  "--text-button-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-button-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-button-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-button-3--textShadow": "var(--text-style-unset)",\
\
  "--text-button-4--fontSize--desktop": "16px",\
  "--text-button-4--fontSize--tablet": "16px",\
  "--text-button-4--fontSize--mobile": "16px",\
  "--text-button-4--fontFamily": "var(--font2)",\
  "--text-button-4--fontWeight": "normal",\
  "--text-button-4--fontType": "regular",\
  "--text-button-4--fontStyle": "normal",\
  "--text-button-4--fontStretch": "normal",\
  "--text-button-4--lineHeight": "1.25",\
  "--text-button-4--marginLeft": "0px",\
  "--text-button-4--color": "var(--palette-color4)",\
  "--text-button-4--borderBottomStyle": "none",\
  "--text-button-4--textDecoration": "none",\
  "--text-button-4--letterSpacing": "0.12",\
  "--text-button-4--textTransform": "uppercase",\
  "--text-button-4--stroke": "var(--palette-color2)",\
  "--text-button-4--textAlign": "center",\
  "--text-button-4--justifyContent": "flex-start",\
  "--text-button-4--marginTop": "auto",\
  "--text-button-4--marginBottom": "0",\
  "--text-button-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-button-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-button-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-button-4--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-1--fontSize--desktop": "18px",\
  "--text-uic-1--fontSize--tablet": "18px",\
  "--text-uic-1--fontSize--mobile": "18px",\
  "--text-uic-1--fontFamily": "var(--font1)",\
  "--text-uic-1--fontWeight": "normal",\
  "--text-uic-1--fontType": "italic",\
  "--text-uic-1--fontStyle": "normal",\
  "--text-uic-1--fontStretch": "normal",\
  "--text-uic-1--lineHeight": "1.35",\
  "--text-uic-1--marginLeft": "0px",\
  "--text-uic-1--color": "var(--palette-color4)",\
  "--text-uic-1--borderBottomStyle": "none",\
  "--text-uic-1--textDecoration": "none",\
  "--text-uic-1--letterSpacing": "0",\
  "--text-uic-1--textTransform": "none",\
  "--text-uic-1--stroke": "var(--palette-color2)",\
  "--text-uic-1--textAlign": "left",\
  "--text-uic-1--justifyContent": "flex-start",\
  "--text-uic-1--marginTop": "auto",\
  "--text-uic-1--marginBottom": "0",\
  "--text-uic-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-1--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-2--fontSize--desktop": "18px",\
  "--text-uic-2--fontSize--tablet": "18px",\
  "--text-uic-2--fontSize--mobile": "18px",\
  "--text-uic-2--fontFamily": "var(--font1)",\
  "--text-uic-2--fontWeight": "normal",\
  "--text-uic-2--fontType": "italic",\
  "--text-uic-2--fontStyle": "normal",\
  "--text-uic-2--fontStretch": "normal",\
  "--text-uic-2--lineHeight": "1.35",\
  "--text-uic-2--marginLeft": "0px",\
  "--text-uic-2--color": "var(--palette-color1)",\
  "--text-uic-2--borderBottomStyle": "none",\
  "--text-uic-2--textDecoration": "none",\
  "--text-uic-2--letterSpacing": "0",\
  "--text-uic-2--textTransform": "none",\
  "--text-uic-2--stroke": "var(--palette-color2)",\
  "--text-uic-2--textAlign": "left",\
  "--text-uic-2--justifyContent": "flex-start",\
  "--text-uic-2--marginTop": "auto",\
  "--text-uic-2--marginBottom": "0",\
  "--text-uic-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-2--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-3--fontSize--desktop": "22px",\
  "--text-uic-3--fontSize--tablet": "22px",\
  "--text-uic-3--fontSize--mobile": "22px",\
  "--text-uic-3--fontFamily": "var(--font1)",\
  "--text-uic-3--fontWeight": "normal",\
  "--text-uic-3--fontType": "regular",\
  "--text-uic-3--fontStyle": "normal",\
  "--text-uic-3--fontStretch": "normal",\
  "--text-uic-3--lineHeight": "1.25",\
  "--text-uic-3--marginLeft": "0px",\
  "--text-uic-3--color": "var(--palette-color5)",\
  "--text-uic-3--borderBottomStyle": "none",\
  "--text-uic-3--textDecoration": "none",\
  "--text-uic-3--letterSpacing": "0",\
  "--text-uic-3--textTransform": "none",\
  "--text-uic-3--stroke": "var(--palette-color2)",\
  "--text-uic-3--textAlign": "left",\
  "--text-uic-3--justifyContent": "flex-start",\
  "--text-uic-3--marginTop": "auto",\
  "--text-uic-3--marginBottom": "0",\
  "--text-uic-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-3--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-4--fontSize--desktop": "22px",\
  "--text-uic-4--fontSize--tablet": "22px",\
  "--text-uic-4--fontSize--mobile": "22px",\
  "--text-uic-4--fontFamily": "var(--font1)",\
  "--text-uic-4--fontWeight": "normal",\
  "--text-uic-4--fontType": "regular",\
  "--text-uic-4--fontStyle": "normal",\
  "--text-uic-4--fontStretch": "normal",\
  "--text-uic-4--lineHeight": "1.25",\
  "--text-uic-4--marginLeft": "0px",\
  "--text-uic-4--color": "var(--palette-color4)",\
  "--text-uic-4--borderBottomStyle": "none",\
  "--text-uic-4--textDecoration": "none",\
  "--text-uic-4--letterSpacing": "0",\
  "--text-uic-4--textTransform": "none",\
  "--text-uic-4--stroke": "var(--palette-color2)",\
  "--text-uic-4--textAlign": "left",\
  "--text-uic-4--justifyContent": "flex-start",\
  "--text-uic-4--marginTop": "auto",\
  "--text-uic-4--marginBottom": "0",\
  "--text-uic-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-4--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-5--fontSize--desktop": "22px",\
  "--text-uic-5--fontSize--tablet": "22px",\
  "--text-uic-5--fontSize--mobile": "22px",\
  "--text-uic-5--fontFamily": "var(--font1)",\
  "--text-uic-5--fontWeight": "normal",\
  "--text-uic-5--fontType": "regular",\
  "--text-uic-5--fontStyle": "normal",\
  "--text-uic-5--fontStretch": "normal",\
  "--text-uic-5--lineHeight": "1.25",\
  "--text-uic-5--marginLeft": "0px",\
  "--text-uic-5--color": "var(--palette-color3)",\
  "--text-uic-5--borderBottomStyle": "none",\
  "--text-uic-5--textDecoration": "none",\
  "--text-uic-5--letterSpacing": "0",\
  "--text-uic-5--textTransform": "none",\
  "--text-uic-5--stroke": "var(--palette-color2)",\
  "--text-uic-5--textAlign": "left",\
  "--text-uic-5--justifyContent": "flex-start",\
  "--text-uic-5--marginTop": "auto",\
  "--text-uic-5--marginBottom": "0",\
  "--text-uic-5--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-5--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-5--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-6--fontSize--desktop": "16px",\
  "--text-uic-6--fontSize--tablet": "16px",\
  "--text-uic-6--fontSize--mobile": "16px",\
  "--text-uic-6--fontFamily": "var(--font2)",\
  "--text-uic-6--fontWeight": "normal",\
  "--text-uic-6--fontType": "bold",\
  "--text-uic-6--fontStyle": "normal",\
  "--text-uic-6--fontStretch": "normal",\
  "--text-uic-6--lineHeight": "1.5",\
  "--text-uic-6--marginLeft": "0px",\
  "--text-uic-6--color": "var(--palette-color7)",\
  "--text-uic-6--borderBottomStyle": "none",\
  "--text-uic-6--textDecoration": "none",\
  "--text-uic-6--letterSpacing": "0.12",\
  "--text-uic-6--textTransform": "none",\
  "--text-uic-6--stroke": "var(--palette-color2)",\
  "--text-uic-6--textAlign": "left",\
  "--text-uic-6--justifyContent": "flex-start",\
  "--text-uic-6--marginTop": "auto",\
  "--text-uic-6--marginBottom": "0",\
  "--text-uic-6--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-6--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-6--textShadow": "var(--text-style-unset)",\
\
  "--text-closedcaptions--fontSize--desktop": "24px",\
  "--text-closedcaptions--fontSize--tablet": "24px",\
  "--text-closedcaptions--fontSize--mobile": "24px",\
  "--text-closedcaptions--fontFamily": "var(--font1)",\
  "--text-closedcaptions--fontWeight": "normal",\
  "--text-closedcaptions--fontType": "regular",\
  "--text-closedcaptions--fontStyle": "normal",\
  "--text-closedcaptions--fontStretch": "normal",\
  "--text-closedcaptions--lineHeight": "1.35",\
  "--text-closedcaptions--marginLeft": "0px",\
  "--text-closedcaptions--color": "var(--white)",\
  "--text-closedcaptions--borderBottomStyle": "none",\
  "--text-closedcaptions--textDecoration": "none",\
  "--text-closedcaptions--letterSpacing": "0",\
  "--text-closedcaptions--textTransform": "none",\
  "--text-closedcaptions--stroke": "var(--palette-color2)",\
  "--text-closedcaptions--textAlign": "center",\
  "--text-closedcaptions--justifyContent": "flex-start",\
  "--text-closedcaptions--marginTop": "auto",\
  "--text-closedcaptions--marginBottom": "0",\
  "--text-closedcaptions--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-closedcaptions--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-closedcaptions--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-closedcaptions--textShadow": "var(--text-style-unset)",\
\
  "--text-caption--fontSize--desktop": "24px",\
  "--text-caption--fontSize--tablet": "24px",\
  "--text-caption--fontSize--mobile": "24px",\
  "--text-caption--fontFamily": "var(--font1)",\
  "--text-caption--fontWeight": "normal",\
  "--text-caption--fontType": "regular",\
  "--text-caption--fontStyle": "normal",\
  "--text-caption--fontStretch": "normal",\
  "--text-caption--lineHeight": "1.35",\
  "--text-caption--marginLeft": "0px",\
  "--text-caption--color": "var(--palette-color6)",\
  "--text-caption--borderBottomStyle": "none",\
  "--text-caption--textDecoration": "none",\
  "--text-caption--letterSpacing": "0",\
  "--text-caption--textTransform": "none",\
  "--text-caption--stroke": "var(--palette-color2)",\
  "--text-caption--textAlign": "center",\
  "--text-caption--justifyContent": "flex-start",\
  "--text-caption--marginTop": "auto",\
  "--text-caption--marginBottom": "0",\
  "--text-caption--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_correct--fontSize--desktop": "24px",\
  "--text-caption_correct--fontSize--tablet": "24px",\
  "--text-caption_correct--fontSize--mobile": "24px",\
  "--text-caption_correct--fontFamily": "var(--font1)",\
  "--text-caption_correct--fontWeight": "normal",\
  "--text-caption_correct--fontType": "regular",\
  "--text-caption_correct--fontStyle": "normal",\
  "--text-caption_correct--fontStretch": "normal",\
  "--text-caption_correct--lineHeight": "1.35",\
  "--text-caption_correct--marginLeft": "0px",\
  "--text-caption_correct--color": "var(--palette-color6)",\
  "--text-caption_correct--borderBottomStyle": "none",\
  "--text-caption_correct--textDecoration": "none",\
  "--text-caption_correct--letterSpacing": "0",\
  "--text-caption_correct--textTransform": "none",\
  "--text-caption_correct--stroke": "var(--palette-color2)",\
  "--text-caption_correct--textAlign": "center",\
  "--text-caption_correct--justifyContent": "flex-start",\
  "--text-caption_correct--marginTop": "auto",\
  "--text-caption_correct--marginBottom": "0",\
  "--text-caption_correct--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_correct--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_correct--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_correct--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_incorrect--fontSize--desktop": "24px",\
  "--text-caption_incorrect--fontSize--tablet": "24px",\
  "--text-caption_incorrect--fontSize--mobile": "24px",\
  "--text-caption_incorrect--fontFamily": "var(--font1)",\
  "--text-caption_incorrect--fontWeight": "normal",\
  "--text-caption_incorrect--fontType": "regular",\
  "--text-caption_incorrect--fontStyle": "normal",\
  "--text-caption_incorrect--fontStretch": "normal",\
  "--text-caption_incorrect--lineHeight": "1.35",\
  "--text-caption_incorrect--marginLeft": "0px",\
  "--text-caption_incorrect--color": "var(--palette-color6)",\
  "--text-caption_incorrect--borderBottomStyle": "none",\
  "--text-caption_incorrect--textDecoration": "none",\
  "--text-caption_incorrect--letterSpacing": "0",\
  "--text-caption_incorrect--textTransform": "none",\
  "--text-caption_incorrect--stroke": "var(--palette-color2)",\
  "--text-caption_incorrect--textAlign": "center",\
  "--text-caption_incorrect--justifyContent": "flex-start",\
  "--text-caption_incorrect--marginTop": "auto",\
  "--text-caption_incorrect--marginBottom": "0",\
  "--text-caption_incorrect--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_incorrect--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_incorrect--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_incorrect--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_incomplete--fontSize--desktop": "24px",\
  "--text-caption_incomplete--fontSize--tablet": "24px",\
  "--text-caption_incomplete--fontSize--mobile": "24px",\
  "--text-caption_incomplete--fontFamily": "var(--font1)",\
  "--text-caption_incomplete--fontWeight": "normal",\
  "--text-caption_incomplete--fontType": "regular",\
  "--text-caption_incomplete--fontStyle": "normal",\
  "--text-caption_incomplete--fontStretch": "normal",\
  "--text-caption_incomplete--lineHeight": "1.35",\
  "--text-caption_incomplete--marginLeft": "0px",\
  "--text-caption_incomplete--color": "var(--palette-color6)",\
  "--text-caption_incomplete--borderBottomStyle": "none",\
  "--text-caption_incomplete--textDecoration": "none",\
  "--text-caption_incomplete--letterSpacing": "0",\
  "--text-caption_incomplete--textTransform": "none",\
  "--text-caption_incomplete--stroke": "var(--palette-color2)",\
  "--text-caption_incomplete--textAlign": "center",\
  "--text-caption_incomplete--justifyContent": "flex-start",\
  "--text-caption_incomplete--marginTop": "auto",\
  "--text-caption_incomplete--marginBottom": "0",\
  "--text-caption_incomplete--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_incomplete--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_incomplete--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_incomplete--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_hint--fontSize--desktop": "24px",\
  "--text-caption_hint--fontSize--tablet": "24px",\
  "--text-caption_hint--fontSize--mobile": "24px",\
  "--text-caption_hint--fontFamily": "var(--font1)",\
  "--text-caption_hint--fontWeight": "normal",\
  "--text-caption_hint--fontType": "regular",\
  "--text-caption_hint--fontStyle": "normal",\
  "--text-caption_hint--fontStretch": "normal",\
  "--text-caption_hint--lineHeight": "1.35",\
  "--text-caption_hint--marginLeft": "0px",\
  "--text-caption_hint--color": "var(--palette-color6)",\
  "--text-caption_hint--borderBottomStyle": "none",\
  "--text-caption_hint--textDecoration": "none",\
  "--text-caption_hint--letterSpacing": "0",\
  "--text-caption_hint--textTransform": "none",\
  "--text-caption_hint--stroke": "var(--palette-color2)",\
  "--text-caption_hint--textAlign": "center",\
  "--text-caption_hint--justifyContent": "flex-start",\
  "--text-caption_hint--marginTop": "auto",\
  "--text-caption_hint--marginBottom": "0",\
  "--text-caption_hint--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_hint--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_hint--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_hint--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_retry--fontSize--desktop": "24px",\
  "--text-caption_retry--fontSize--tablet": "24px",\
  "--text-caption_retry--fontSize--mobile": "24px",\
  "--text-caption_retry--fontFamily": "var(--font1)",\
  "--text-caption_retry--fontWeight": "normal",\
  "--text-caption_retry--fontType": "regular",\
  "--text-caption_retry--fontStyle": "normal",\
  "--text-caption_retry--fontStretch": "normal",\
  "--text-caption_retry--lineHeight": "1.35",\
  "--text-caption_retry--marginLeft": "0px",\
  "--text-caption_retry--color": "var(--palette-color6)",\
  "--text-caption_retry--borderBottomStyle": "none",\
  "--text-caption_retry--textDecoration": "none",\
  "--text-caption_retry--letterSpacing": "0",\
  "--text-caption_retry--textTransform": "none",\
  "--text-caption_retry--stroke": "var(--palette-color2)",\
  "--text-caption_retry--textAlign": "center",\
  "--text-caption_retry--justifyContent": "flex-start",\
  "--text-caption_retry--marginTop": "auto",\
  "--text-caption_retry--marginBottom": "0",\
  "--text-caption_retry--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_retry--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_retry--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_retry--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_timeout--fontSize--desktop": "24px",\
  "--text-caption_timeout--fontSize--tablet": "24px",\
  "--text-caption_timeout--fontSize--mobile": "24px",\
  "--text-caption_timeout--fontFamily": "var(--font1)",\
  "--text-caption_timeout--fontWeight": "normal",\
  "--text-caption_timeout--fontType": "regular",\
  "--text-caption_timeout--fontStyle": "normal",\
  "--text-caption_timeout--fontStretch": "normal",\
  "--text-caption_timeout--lineHeight": "1.35",\
  "--text-caption_timeout--marginLeft": "0px",\
  "--text-caption_timeout--color": "var(--palette-color6)",\
  "--text-caption_timeout--borderBottomStyle": "none",\
  "--text-caption_timeout--textDecoration": "none",\
  "--text-caption_timeout--letterSpacing": "0",\
  "--text-caption_timeout--textTransform": "none",\
  "--text-caption_timeout--stroke": "var(--palette-color2)",\
  "--text-caption_timeout--textAlign": "center",\
  "--text-caption_timeout--justifyContent": "flex-start",\
  "--text-caption_timeout--marginTop": "auto",\
  "--text-caption_timeout--marginBottom": "0",\
  "--text-caption_timeout--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_timeout--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_timeout--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_timeout--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_1--fontSize--desktop": "18px",\
  "--text-caption_1--fontSize--tablet": "18px",\
  "--text-caption_1--fontSize--mobile": "16px",\
  "--text-caption_1--fontFamily": "var(--font2)",\
  "--text-caption_1--fontWeight": "normal",\
  "--text-caption_1--fontType": "regular",\
  "--text-caption_1--fontStyle": "normal",\
  "--text-caption_1--fontStretch": "normal",\
  "--text-caption_1--lineHeight": "1.2",\
  "--text-caption_1--marginLeft": "0px",\
  "--text-caption_1--color": "#FFFFFF",\
  "--text-caption_1--borderBottomStyle": "none",\
  "--text-caption_1--textDecoration": "none",\
  "--text-caption_1--letterSpacing": "0",\
  "--text-caption_1--textTransform": "none",\
  "--text-caption_1--stroke": "#00000000",\
  "--text-caption_1--textAlign": "left",\
  "--text-caption_1--justifyContent": "flex-start",\
  "--text-caption_1--marginTop": "auto",\
  "--text-caption_1--marginBottom": "0",\
  "--text-caption_1--defaultTextStroke": "1px #00000000",\
  "--text-caption_1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_1--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_2--fontSize--desktop": "20px",\
  "--text-caption_2--fontSize--tablet": "20px",\
  "--text-caption_2--fontSize--mobile": "18px",\
  "--text-caption_2--fontFamily": "var(--font2)",\
  "--text-caption_2--fontWeight": "normal",\
  "--text-caption_2--fontType": "bold",\
  "--text-caption_2--fontStyle": "normal",\
  "--text-caption_2--fontStretch": "normal",\
  "--text-caption_2--lineHeight": "1.2",\
  "--text-caption_2--marginLeft": "0px",\
  "--text-caption_2--color": "#FFFFFF",\
  "--text-caption_2--borderBottomStyle": "none",\
  "--text-caption_2--textDecoration": "none",\
  "--text-caption_2--letterSpacing": "0",\
  "--text-caption_2--textTransform": "none",\
  "--text-caption_2--stroke": "#00000000",\
  "--text-caption_2--textAlign": "left",\
  "--text-caption_2--justifyContent": "flex-start",\
  "--text-caption_2--marginTop": "auto",\
  "--text-caption_2--marginBottom": "0",\
  "--text-caption_2--defaultTextStroke": "1px #00000000",\
  "--text-caption_2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_2--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_3--fontSize--desktop": "24px",\
  "--text-caption_3--fontSize--tablet": "24px",\
  "--text-caption_3--fontSize--mobile": "22px",\
  "--text-caption_3--fontFamily": "var(--font1)",\
  "--text-caption_3--fontWeight": "normal",\
  "--text-caption_3--fontType": "italic",\
  "--text-caption_3--fontStyle": "normal",\
  "--text-caption_3--fontStretch": "normal",\
  "--text-caption_3--lineHeight": "1.2",\
  "--text-caption_3--marginLeft": "0px",\
  "--text-caption_3--color": "#FFFFFF",\
  "--text-caption_3--borderBottomStyle": "none",\
  "--text-caption_3--textDecoration": "none",\
  "--text-caption_3--letterSpacing": "0",\
  "--text-caption_3--textTransform": "none",\
  "--text-caption_3--stroke": "#00000000",\
  "--text-caption_3--textAlign": "left",\
  "--text-caption_3--justifyContent": "flex-start",\
  "--text-caption_3--marginTop": "auto",\
  "--text-caption_3--marginBottom": "0",\
  "--text-caption_3--defaultTextStroke": "1px #00000000",\
  "--text-caption_3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_3--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_4--fontSize--desktop": "22px",\
  "--text-caption_4--fontSize--tablet": "22px",\
  "--text-caption_4--fontSize--mobile": "20px",\
  "--text-caption_4--fontFamily": "var(--font2)",\
  "--text-caption_4--fontWeight": "normal",\
  "--text-caption_4--fontType": "italic",\
  "--text-caption_4--fontStyle": "normal",\
  "--text-caption_4--fontStretch": "normal",\
  "--text-caption_4--lineHeight": "1.3",\
  "--text-caption_4--marginLeft": "0px",\
  "--text-caption_4--color": "#666666",\
  "--text-caption_4--borderBottomStyle": "none",\
  "--text-caption_4--textDecoration": "none",\
  "--text-caption_4--letterSpacing": "0",\
  "--text-caption_4--textTransform": "none",\
  "--text-caption_4--stroke": "#00000000",\
  "--text-caption_4--textAlign": "left",\
  "--text-caption_4--justifyContent": "flex-start",\
  "--text-caption_4--marginTop": "auto",\
  "--text-caption_4--marginBottom": "0",\
  "--text-caption_4--defaultTextStroke": "1px #00000000",\
  "--text-caption_4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_4--textShadow": "var(--text-style-unset)",\
\
  "--text-comment-box--fontSize--desktop": "20px",\
  "--text-comment-box--fontSize--tablet": "20px",\
  "--text-comment-box--fontSize--mobile": "20px",\
  "--text-comment-box--fontFamily": "var(--font1)",\
  "--text-comment-box--fontWeight": "normal",\
  "--text-comment-box--fontType": "regular",\
  "--text-comment-box--fontStyle": "normal",\
  "--text-comment-box--fontStretch": "normal",\
  "--text-comment-box--lineHeight": "1.35",\
  "--text-comment-box--marginLeft": "0px",\
  "--text-comment-box--color": "var(--palette-color6)",\
  "--text-comment-box--borderBottomStyle": "none",\
  "--text-comment-box--textDecoration": "none",\
  "--text-comment-box--letterSpacing": "0",\
  "--text-comment-box--textTransform": "none",\
  "--text-comment-box--stroke": "var(--palette-color2)",\
  "--text-comment-box--textAlign": "center",\
  "--text-comment-box--justifyContent": "flex-start",\
  "--text-comment-box--marginTop": "auto",\
  "--text-comment-box--marginBottom": "0",\
  "--text-comment-box--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-comment-box--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-comment-box--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-comment-box--textShadow": "var(--text-style-unset)",\
\
  "--theme_image_default--strokeColor": "var(--palette-color1)",\
  "--theme_image_default--boxShadowColor": "var(--greyscale3)",\
\
  "--theme_image_greyscale--strokeColor": "var(--palette-color1)",\
  "--theme_image_greyscale--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_greyscale--intensity": 100,\
\
  "--theme_image_lighten--strokeColor": "var(--palette-color1)",\
  "--theme_image_lighten--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_lighten--intensity": 80,\
\
  "--theme_image_darken--strokeColor": "var(--palette-color1)",\
  "--theme_image_darken--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_darken--intensity": 80,\
\
  "--theme_image_overlay--strokeColor": "var(--palette-color1)",\
  "--theme_image_overlay--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_overlay--intensity": 80,\
  "--theme_image_overlay--primaryFillColor": "var(--palette-color2)",\
  "--theme_image_overlay--secondaryFillColor": "var(--palette-color1)",\
\
  "--theme_image_colorize--strokeColor": "var(--palette-color1)",\
  "--theme_image_colorize--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_colorize--intensity": 80,\
  "--theme_image_colorize--primaryFillColor": "var(--palette-color4)",\
  "--theme_image_colorize--secondaryFillColor": "var(--palette-color1)",\
\
\
  "--button-normal--primaryColor": "var(--palette-color7)",\
  "--button-normal--borderColor": "var(--palette-color7)",\
  "--button-normal--shadowColor": "var(--greyscale3)",\
  "--text-button-normal--color": "var(--palette-color0)",\
  "--text-button-normal--fontFamily": "var(--font2)",\
  "--text-button-normal--fontType": "regular",\
  "--text-button-normal--fontSize--desktop": "16px",\
  "--text-button-normal--fontSize--tablet": "16px",\
  "--text-button-normal--fontSize--mobile": "16px",\
\
  "--button-selected--primaryColor": "var(--palette-color5)",\
  "--button-selected--borderColor": "var(--palette-color5)",\
  "--button-selected--shadowColor": "var(--greyscale3)",\
  "--text-button-selected--color": "var(--palette-color0)",\
  "--text-button-selected--fontFamily": "var(--font2)",\
  "--text-button-selected--fontType": "regular",\
  "--text-button-selected--fontSize--desktop": "16px",\
  "--text-button-selected--fontSize--tablet": "16px",\
  "--text-button-selected--fontSize--mobile": "16px",\
\
  "--button-disabled--primaryColor": "var(--palette-color3)",\
  "--button-disabled--borderColor": "var(--palette-color3)",\
  "--button-disabled--shadowColor": "var(--greyscale3)",\
  "--text-button-disabled--color": "var(--palette-color4)",\
  "--text-button-disabled--fontFamily": "var(--font2)",\
  "--text-button-disabled--fontType": "regular",\
  "--text-button-disabled--fontSize--desktop": "16px",\
  "--text-button-disabled--fontSize--tablet": "16px",\
  "--text-button-disabled--fontSize--mobile": "16px",\
\
  "--button-hover--primaryColor": "#112FA7",\
  "--button-hover--borderColor": "#112FA7",\
  "--button-hover--shadowColor": "var(--greyscale3)",\
  "--text-button-hover--color": "var(--palette-color0)",\
  "--text-button-hover--fontFamily": "var(--font2)",\
  "--text-button-hover--fontType": "regular",\
  "--text-button-hover--fontSize--desktop": "16px",\
  "--text-button-hover--fontSize--tablet": "16px",\
  "--text-button-hover--fontSize--mobile": "16px",\
\
  "--button-visited--primaryColor": "#112FA780",\
  "--button-visited--borderColor": "#112FA780",\
  "--button-visited--shadowColor": "var(--greyscale3)",\
  "--text-button-visited--color": "var(--palette-color0)",\
  "--text-button-visited--fontFamily": "var(--font2)",\
  "--text-button-visited--fontType": "regular",\
  "--text-button-visited--fontSize--desktop": "16px",\
  "--text-button-visited--fontSize--tablet": "16px",\
  "--text-button-visited--fontSize--mobile": "16px",\
\
  "--checkbox-normal--primaryColor": "var(--palette-color0)",\
  "--checkbox-normal--borderColor": "var(--palette-color3)",\
  "--checkbox-normal--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-normal--color": "var(--palette-color4)",\
  "--text-checkbox-normal--fontFamily": "var(--font1)",\
  "--text-checkbox-normal--fontType": "regular",\
  "--text-checkbox-normal--fontSize--desktop": "22px",\
  "--text-checkbox-normal--fontSize--tablet": "20px",\
  "--text-checkbox-normal--fontSize--mobile": "20px",\
\
  "--checkbox-selected--primaryColor": "var(--palette-color7)",\
  "--checkbox-selected--borderColor": "var(--palette-color4)",\
  "--checkbox-selected--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-selected--color": "var(--palette-color4)",\
  "--text-checkbox-selected--fontFamily": "var(--font1)",\
  "--text-checkbox-selected--fontType": "regular",\
  "--text-checkbox-selected--fontSize--desktop": "22px",\
  "--text-checkbox-selected--fontSize--tablet": "20px",\
  "--text-checkbox-selected--fontSize--mobile": "20px",\
\
  "--checkbox-disabled-checked--primaryColor": "var(--palette-color3)",\
  "--checkbox-disabled-checked--borderColor": "var(--palette-color3)",\
  "--checkbox-disabled-checked--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-disabled-checked--color": "var(--palette-color3)",\
  "--text-checkbox-disabled-checked--fontFamily": "var(--font1)",\
  "--text-checkbox-disabled-checked--fontType": "regular",\
  "--text-checkbox-disabled-checked--fontSize--desktop": "22px",\
  "--text-checkbox-disabled-checked--fontSize--tablet": "20px",\
  "--text-checkbox-disabled-checked--fontSize--mobile": "20px",\
\
  "--checkbox-hover--primaryColor": "var(--palette-color0)",\
  "--checkbox-hover--borderColor": "var(--palette-color3)",\
  "--checkbox-hover--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-hover--color": "var(--palette-color5)",\
  "--text-checkbox-hover--fontFamily": "var(--font1)",\
  "--text-checkbox-hover--fontType": "regular",\
  "--text-checkbox-hover--fontSize--desktop": "22px",\
  "--text-checkbox-hover--fontSize--tablet": "20px",\
  "--text-checkbox-hover--fontSize--mobile": "20px",\
\
  "--checkbox-disabled-unchecked--primaryColor": "var(--palette-color3)",\
  "--checkbox-disabled-unchecked--borderColor": "var(--palette-color3)",\
  "--checkbox-disabled-unchecked--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-disabled-unchecked--color": "var(--palette-color3)",\
  "--text-checkbox-disabled-unchecked--fontFamily": "var(--font1)",\
  "--text-checkbox-disabled-unchecked--fontType": "regular",\
  "--text-checkbox-disabled-unchecked--fontSize--desktop": "22px",\
  "--text-checkbox-disabled-unchecked--fontSize--tablet": "20px",\
  "--text-checkbox-disabled-unchecked--fontSize--mobile": "20px",\
\
  "--inputfield-normal--primaryColor": "var(--palette-color0)", \
  "--inputfield-normal--borderColor": "var(--palette-color3)",\
  "--inputfield-normal--shadowColor": "var(--greyscale3)",\
  "--text-inputfield-normal--color": "var(--palette-color4)",\
  "--text-inputfield-normal--fontFamily": "var(--font1)",\
  "--text-inputfield-normal--fontType": "regular",\
  "--text-inputfield-normal--fontSize--desktop": "18px",\
  "--text-inputfield-normal--fontSize--tablet": "20px",\
  "--text-inputfield-normal--fontSize--mobile": "20px",\
\
  "--inputfield-active--primaryColor": "var(--palette-color0)",\
  "--inputfield-active--borderColor": "var(--palette-color7)",\
  "--inputfield-active--shadowColor": "#var(--greyscale3)",\
  "--text-inputfield-active--color": "var(--palette-color4)",\
  "--text-inputfield-active--fontFamily": "var(--font1)",\
  "--text-inputfield-active--fontType": "regular",\
  "--text-inputfield-active--fontSize--desktop": "18px",\
  "--text-inputfield-active--fontSize--tablet": "20px",\
  "--text-inputfield-active--fontSize--mobile": "20px",\
\
  "--inputfield-disabled--primaryColor": "var(--palette-color3)",\
  "--inputfield-disabled--borderColor": "var(--palette-color3)",\
  "--inputfield-disabled--shadowColor": "var(--greyscale3)",\
  "--text-inputfield-disabled--color": "var(--palette-color1)",\
  "--text-inputfield-disabled--fontFamily": "var(--font1)",\
  "--text-inputfield-disabled--fontType": "regular",\
  "--text-inputfield-disabled--fontSize--desktop": "18px",\
  "--text-inputfield-disabled--fontSize--tablet": "20px",\
  "--text-inputfield-disabled--fontSize--mobile": "20px",\
\
  "--inputfield-focusLost--primaryColor": "var(--palette-color0)",\
  "--inputfield-focusLost--borderColor": "var(--palette-color3)",\
  "--inputfield-focusLost--shadowColor": "var(--greyscale3)",\
  "--text-inputfield-focusLost--color": "var(--palette-color4)",\
  "--text-inputfield-focusLost--fontFamily": "var(--font1)",\
  "--text-inputfield-focusLost--fontType": "regular",\
  "--text-inputfield-focusLost--fontSize--desktop": "18px",\
  "--text-inputfield-focusLost--fontSize--tablet": "20px",\
  "--text-inputfield-focusLost--fontSize--mobile": "20px",\
\
  "--inputfield-error--primaryColor": "var(--palette-color0)",\
  "--inputfield-error--borderColor": "var(--error)",\
  "--inputfield-error--shadowColor": "var(--greyscale3)",\
  "--text-inputfield-error--color": "var(--palette-color4)",\
  "--text-inputfield-error--fontFamily": "var(--font1)",\
  "--text-inputfield-error--fontType": "regular",\
  "--text-inputfield-error--fontSize--desktop": "18px",\
  "--text-inputfield-error--fontSize--tablet": "20px",\
  "--text-inputfield-error--fontSize--mobile": "20px",\
\
  "--dropdown-normal--primaryColor": "var(--palette-color0)",\
  "--dropdown-normal--borderColor": "var(--palette-color3)",\
  "--dropdown-normal--shadowColor": "var(--greyscale3)",\
  "--text-dropdown-normal--color": "var(--palette-color4)",\
  "--text-dropdown-normal--fontFamily": "var(--font1)",\
  "--text-dropdown-normal--fontType": "italic",\
  "--text-dropdown-normal--fontSize--desktop": "18px",\
  "--text-dropdown-normal--fontSize--tablet": "18px",\
  "--text-dropdown-normal--fontSize--mobile": "18px",\
\
  "--dropdown-selected--primaryColor": "var(--palette-color0)",\
  "--dropdown-selected--borderColor": "var(--palette-color7)",\
  "--dropdown-selected--shadowColor": "var(--greyscale3)",\
  "--text-dropdown-selected--color": "var(--palette-color4)",\
  "--text-dropdown-selected--fontFamily": "var(--font1)",\
  "--text-dropdown-selected--fontType": "italic",\
  "--text-dropdown-selected--fontSize--desktop": "18px",\
  "--text-dropdown-selected--fontSize--tablet": "18px",\
  "--text-dropdown-selected--fontSize--mobile": "18px",\
\
  "--dropdown-disabled--primaryColor": "var(--palette-color3)",\
  "--dropdown-disabled--borderColor": "var(--palette-color3)",\
  "--dropdown-disabled--shadowColor": "var(--greyscale3)",\
  "--text-dropdown-disabled--color": "var(--palette-color1)",\
  "--text-dropdown-disabled--fontFamily": "var(--font1)",\
  "--text-dropdown-disabled--fontType": "italic",\
  "--text-dropdown-disabled--fontSize--desktop": "18px",\
  "--text-dropdown-disabled--fontSize--tablet": "18px",\
  "--text-dropdown-disabled--fontSize--mobile": "18px",\
\
  "--dropdown-hover--primaryColor": "var(--palette-color0)",\
  "--dropdown-hover--borderColor": "var(--palette-color3)",\
  "--dropdown-hover--shadowColor": "var(--greyscale3)",\
  "--text-dropdown-hover--color": "var(--palette-color4)",\
  "--text-dropdown-hover--fontFamily": "var(--font1)",\
  "--text-dropdown-hover--fontType": "italic",\
  "--text-dropdown-hover--fontSize--desktop": "18px",\
  "--text-dropdown-hover--fontSize--tablet": "18px",\
  "--text-dropdown-hover--fontSize--mobile": "18px",\
\
  "--radio-normal--primaryColor": "var(--palette-color0)",\
  "--radio-normal--borderColor": "var(--palette-color3)",\
  "--radio-normal--shadowColor": "var(--greyscale3)",\
  "--text-radio-normal--color": "var(--palette-color4)",\
  "--text-radio-normal--fontFamily": "var(--font1)",\
  "--text-radio-normal--fontType": "regular",\
  "--text-radio-normal--fontSize--desktop": "22px",\
  "--text-radio-normal--fontSize--tablet": "20px",\
  "--text-radio-normal--fontSize--mobile": "20px",\
\
  "--radio-selected--primaryColor": "var(--palette-color0)",\
  "--radio-selected--borderColor": "var(--palette-color4)",\
  "--radio-selected--shadowColor": "var(--greyscale3)",\
  "--text-radio-selected--color": "var(--palette-color4)",\
  "--text-radio-selected--fontFamily": "var(--font1)",\
  "--text-radio-selected--fontType": "regular",\
  "--text-radio-selected--fontSize--desktop": "22px",\
  "--text-radio-selected--fontSize--tablet": "20px",\
  "--text-radio-selected--fontSize--mobile": "20px",\
\
  "--radio-disabled-checked--primaryColor": "var(--palette-color3)",\
  "--radio-disabled-checked--borderColor": "var(--palette-color3)",\
  "--radio-disabled-checked--shadowColor": "var(--greyscale3)",\
  "--text-radio-disabled-checked--color": "var(--palette-color3)",\
  "--text-radio-disabled-checked--fontFamily": "var(--font1)",\
  "--text-radio-disabled-checked--fontType": "regular",\
  "--text-radio-disabled-checked--fontSize--desktop": "22px",\
  "--text-radio-disabled-checked--fontSize--tablet": "20px",\
  "--text-radio-disabled-checked--fontSize--mobile": "20px",\
\
  "--radio-hover--primaryColor": "var(--palette-color0)",\
  "--radio-hover--borderColor": "var(--palette-color3)",\
  "--radio-hover--shadowColor": "var(--greyscale3)",\
  "--text-radio-hover--color": "var(--palette-color5)",\
  "--text-radio-hover--fontFamily": "var(--font1)",\
  "--text-radio-hover--fontType": "regular",\
  "--text-radio-hover--fontSize--desktop": "22px",\
  "--text-radio-hover--fontSize--tablet": "20px",\
  "--text-radio-hover--fontSize--mobile": "20px",\
\
  "--radio-disabled-unchecked--primaryColor": "var(--palette-color3)",\
  "--radio-disabled-unchecked--borderColor": "var(--palette-color3)",\
  "--radio-disabled-unchecked--shadowColor": "var(--greyscale3)",\
  "--text-radio-disabled-unchecked--color": "var(--palette-color3)",\
  "--text-radio-disabled-unchecked--fontFamily": "var(--font1)",\
  "--text-radio-disabled-unchecked--fontType": "regular",\
  "--text-radio-disabled-unchecked--fontSize--desktop": "22px",\
  "--text-radio-disabled-unchecked--fontSize--tablet": "20px",\
  "--text-radio-disabled-unchecked--fontSize--mobile": "20px",\
\
  "--video_preset-color": "#666666",\
  "--video_preset-borderColor": "#666666",\
  \
  "--clickbox-preset-fill-color": "#3F80E4",\
\
  "--drag-object-default-state-fill-color": "255, 255, 255",\
  "--drag-object-hover-state-fill-color": "250, 250, 250",\
  "--drag-object-transition-state-fill-color": "250, 250, 250",\
  "--drag-object-dragOver-state-fill-color": "250, 250, 250",\
  "--drag-object-dropped-state-fill-color": "255, 255, 255",\
\
  "--drag-object-default-state-border-color": "214, 213, 209",\
  "--drag-object-hover-state-border-color": "214, 213, 209",\
  "--drag-object-transition-state-border-color": "214, 213, 209",\
  "--drag-object-dragOver-state-border-color": "230, 132, 80",\
  "--drag-object-dropped-state-border-color": "214, 213, 209",\
\
  "--drop-object-default-state-fill-color": "255, 255, 255",\
  "--drop-object-hover-state-fill-color": "255, 255, 255",\
  "--drop-object-dragOver-state-fill-color": "230, 132, 80",\
  "--drop-object-dropped-state-fill-color": "255, 255, 255",\
\
  "--drop-object-default-state-border-color": "42, 49, 62",\
  "--drop-object-hover-state-border-color": "230, 132, 80",\
  "--drop-object-dragOver-state-border-color": "230, 132, 80",\
  "--drop-object-dropped-state-border-color": "42, 49, 62"\
}',
uic_presets:'{\
  "cp_button_shape_1_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-normal--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_1_solid_style_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 1,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-hover--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 0,\
      "y": 0,\
      "blur": 7,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 0.53\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_1_solid_style_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-selected--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "--button-selected--shadowColor",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_1_solid_style_visited": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-visited--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-visited--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-visited--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_1_solid_style_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-disabled--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-disabled--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style": {\
    "fill": "var(--palette-color0)",\
    "fillOpacity": 1,\
    "stroke": "#707070",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_hover": {\
    "fill": "#9ec4f3",\
    "fillOpacity": 1,\
    "stroke": "var(--color6)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 0,\
      "y": 0,\
      "blur": 7,\
      "spread": null,\
      "color": "var(--black)",\
      "inset": null,\
      "opacity": 0.53\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_selected": {\
    "fill": "var(--palette-color5)",\
    "fillOpacity": 1,\
    "stroke": "var(--color6)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_visited": {\
    "fill": "#0A00FF",\
    "fillOpacity": 1,\
    "stroke": "var(--color6)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_disabled": {\
    "fill": "#0A00FF",\
    "fillOpacity": 1,\
    "stroke": "var(--color6)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-hover--borderColor)",\
    "strokeWidth": 3,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-selected--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-selected--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style_disabled_checked": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-disabled-checked--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-disabled-checked--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-disabled-checked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style_disabled_unchecked": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-disabled-unchecked--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-disabled-unchecked--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-disabled-unchecked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style_active": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-active--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-active--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-active--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style_focusLost": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-focusLost--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-focusLost--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-focusLost--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style_error": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-error--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-error--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-error--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-disabled--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-disabled--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_dropDown_shape_1_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-normal--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_dropDown_shape_1_solid_style_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-hover--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 0,\
      "y": 0,\
      "blur": 14,\
      "spread": null,\
      "color": "var(--dropdown-hover--shadowColor)",\
      "inset": null,\
      "opacity": 0.78\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_dropDown_shape_1_solid_style_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-selected--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-selected--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_dropDown_shape_1_solid_style_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-disabled--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-disabled--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "video_preset_style": {\
    "fillEnable": 0,\
    "strokeEnable": 0,\
    "shadowEnable": 0,\
    "fill": "var(--video_preset-color)",\
    "fillOpacity": 1,\
    "stroke": "var(--video_preset-border)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_comment_box_shape_1_solid_style": {\
    "fill": "#F2B807",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_clickbox_shape_solid_style": {\
    "fill": "var(--clickbox-preset-fill-color)",\
    "fillOpacity": 0.6,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "2, 3",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_normal": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-hover--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-selected--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_visited": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-visited--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-visited--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-disabled--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_navigate_default": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "#333333",\
    "fillOpacity": 1,\
    "stroke": "#D6D5D1",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_navigate_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "#000000",\
    "fillOpacity": 1,\
    "stroke": "#D6D5D1",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_navigate_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "#D6D5D1",\
    "fillOpacity": 1,\
    "stroke": "#D6D5D1",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "dropdown_shape_1_normal": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "dropdown_shape_1_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-hover--borderColor)",\
    "strokeWidth": 3,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "dropdown_shape_1_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-selected--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-selected--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "dropdown_shape_1_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-disabled--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-disabled--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_normal": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-hover--borderColor)",\
    "strokeWidth": 3,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-selected--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-selected--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_disabled_checked": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-disabled-checked--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-disabled-checked--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-disabled-checked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_disabled_unchecked": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-disabled-unchecked--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-disabled-unchecked--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_clicktoreveal_default": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "#ffffff",\
    "fillOpacity": 1,\
    "stroke": "#ffffff",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_linear_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 3,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color0)",\
    "fillOpacity": 1,\
    "stroke": "var(--black)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "#FF335E",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "#ECA8B6",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color7)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color8)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_blue": {\
    "fill": "#ADD8E6",\
    "fillOpacity": 1,\
    "stroke": "var(--black)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "#FF335E",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "#ECA8B6",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  }\
}'
},
project_main:{
from:1,
to:0,
currentFrame:1,
featureFlags:{
isNewWidgetArchitecture:'{"isEnabled":true,"featureData":{}}'
}
,
useResponsive:true,
responsiveType:512,
isResponsiveSim:1,
currentFrame:1,
useWidgetVersion7:false,
isPublishedFromLacuna:false,
slideAudios:'StAd28,StAd29',
vestr:0,
vim:0,
slides:'Slide436,Slide553,Slide590,Slide707,Slide824,Slide861,Slide898,Slide935,Slide972,Slide1089,Slide1126,Slide1163,Slide1200,Slide1317,Slide1354,Slide1471,Slide1588,Slide1705,Slide1822,Slide1939,Slide2056',
questions:'',
autoplay:false,
preloader:true,
preloaderFileName:'dr/loading.gif',
preloaderPercentage:100,
pprtd:false,
peon:false,
fadeInAtStart:0,
fadeOutAtEnd:0
},
borderProperties:{
hasBorder:false
},
playBarProperties:{
hasPlayBar:true,
jsfile:'playbarScript.js',
cssfile:'playbarStyle.css',
position:3,
layout:3,
showOnHover:false,
overlay:true,
tworow:false,
hasRewind:true,
hasBackward:true,
hasPlay:true,
hasEnterVR:false,
hasSlider:true,
hasForward:true,
hasCC:false,
hasAudioOn:true,
hasExit:true,
hasFastForward:true,
applyColors:false,
alpha:100,
noToolTips:false,
locale:0
},
tocProperties:{
tocProperties:'{"tocConfig":{"labels":{"TITLE":"Table of Content","SLIDE_DETAILS":"SLIDE TITLE","DURATION":"DURATION","CLOSE_BUTTON_LABEL":"Close"},"slideDetails":[{"label":"Simulation slide 1","type":"slide","parentId":null,"id":"Slide436","isVisible":true,"slideVisited":false,"originalId":436,"labelShouldBeInSync":true},{"label":"Simulation slide 2","type":"slide","parentId":null,"id":"Slide553","isVisible":true,"slideVisited":false,"originalId":553,"labelShouldBeInSync":true},{"label":"Simulation slide 3","type":"slide","parentId":null,"id":"Slide590","isVisible":true,"slideVisited":false,"originalId":590,"labelShouldBeInSync":true},{"label":"Simulation slide 4","type":"slide","parentId":null,"id":"Slide707","isVisible":true,"slideVisited":false,"originalId":707,"labelShouldBeInSync":true},{"label":"Simulation slide 5","type":"slide","parentId":null,"id":"Slide824","isVisible":true,"slideVisited":false,"originalId":824,"labelShouldBeInSync":true},{"label":"Simulation slide 6","type":"slide","parentId":null,"id":"Slide861","isVisible":true,"slideVisited":false,"originalId":861,"labelShouldBeInSync":true},{"label":"Simulation slide 7","type":"slide","parentId":null,"id":"Slide898","isVisible":true,"slideVisited":false,"originalId":898,"labelShouldBeInSync":true},{"label":"Simulation slide 8","type":"slide","parentId":null,"id":"Slide935","isVisible":true,"slideVisited":false,"originalId":935,"labelShouldBeInSync":true},{"label":"Simulation slide 9","type":"slide","parentId":null,"id":"Slide972","isVisible":true,"slideVisited":false,"originalId":972,"labelShouldBeInSync":true},{"label":"Simulation slide 10","type":"slide","parentId":null,"id":"Slide1089","isVisible":true,"slideVisited":false,"originalId":1089,"labelShouldBeInSync":true},{"label":"Simulation slide 11","type":"slide","parentId":null,"id":"Slide1126","isVisible":true,"slideVisited":false,"originalId":1126,"labelShouldBeInSync":true},{"label":"Simulation slide 12","type":"slide","parentId":null,"id":"Slide1163","isVisible":true,"slideVisited":false,"originalId":1163,"labelShouldBeInSync":true},{"label":"Simulation slide 13","type":"slide","parentId":null,"id":"Slide1200","isVisible":true,"slideVisited":false,"originalId":1200,"labelShouldBeInSync":true},{"label":"Simulation slide 14","type":"slide","parentId":null,"id":"Slide1317","isVisible":true,"slideVisited":false,"originalId":1317,"labelShouldBeInSync":true},{"label":"Simulation slide 15","type":"slide","parentId":null,"id":"Slide1354","isVisible":true,"slideVisited":false,"originalId":1354,"labelShouldBeInSync":true},{"label":"Simulation slide 16","type":"slide","parentId":null,"id":"Slide1471","isVisible":true,"slideVisited":false,"originalId":1471,"labelShouldBeInSync":true},{"label":"Simulation slide 17","type":"slide","parentId":null,"id":"Slide1588","isVisible":true,"slideVisited":false,"originalId":1588,"labelShouldBeInSync":true},{"label":"Simulation slide 18","type":"slide","parentId":null,"id":"Slide1705","isVisible":true,"slideVisited":false,"originalId":1705,"labelShouldBeInSync":true},{"label":"Simulation slide 19","type":"slide","parentId":null,"id":"Slide1822","isVisible":true,"slideVisited":false,"originalId":1822,"labelShouldBeInSync":true},{"label":"Simulation slide 20","type":"slide","parentId":null,"id":"Slide1939","isVisible":true,"slideVisited":false,"originalId":1939,"labelShouldBeInSync":true},{"label":"Simulation slide 21","type":"slide","parentId":null,"id":"Slide2056","isVisible":true,"slideVisited":false,"originalId":2056,"labelShouldBeInSync":true}],"tocGeneratedOnPreviewClick":true,"preserveSlidesOrder":true},"playbarConfig":{"isPlaybarControlsPlayEnabled":true,"isPlaybarControlsNextEnabled":true,"isPlaybarControlsTOCEnabled":true,"isShowPlaybarEnabled":true,"isShowTooltipsEnabled":true,"isPlaybarControlsBackEnabled":true,"isHidePlaybarInQuizEnabled":false,"isPlaybarControlsMuteEnabled":true,"isPlaybarControlsClosedCaptionsEnabled":false}}'
},
trecs:[{
link:436,
text:['""','""','""','""','""','""','""']
}
,{
link:553,
text:['""','""','""','""','""']
}
,{
link:590,
text:['""','""','""','""','""']
}
,{
link:707,
text:['""','""','""','""','""']
}
,{
link:824,
text:['""','""','""']
}
,{
link:861,
text:['""','""','""','""']
}
,{
link:898,
text:['""','""','""','""']
}
,{
link:935,
text:['""','""','""','""']
}
,{
link:972,
text:['""','""','""','""','""']
}
,{
link:1089,
text:['""','""','""']
}
,{
link:1126,
text:['""','""','""']
}
,{
link:1163,
text:['""','""','""']
}
,{
link:1200,
text:['""','""','""']
}
,{
link:1317,
text:['""','""','""']
}
,{
link:1354,
text:['""','""','""']
}
,{
link:1471,
text:['""','""','""']
}
,{
link:1588,
text:['""','""','""']
}
,{
link:1705,
text:['""','""','""']
}
,{
link:1822,
text:['""','""','""']
}
,{
link:1939,
text:['""','""','""']
}
,{
link:2056,
text:['""','""','""']
}
]

,
typekit:{
kit_id:''
},
};
cp.model.projectImages=[
'assets/htmlimages/ThreeD_Close.svg',
'assets/htmlimages/ThreeD_HotspotDefaultGlow.png',
'assets/htmlimages/ThreeD_HotspotGlow.png',
'assets/htmlimages/assessmenthotspotvisited.svg',
'assets/htmlimages/expand_icon.png',
'assets/htmlimages/img_trans.gif',
'assets/htmlimages/placeholder.png'
];
cp.model.data.images=[{
ip:'dr/01006.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01123.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01160.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01197.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01234.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01351.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01388.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01505.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01622.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01739.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01856.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01973.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02090.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0470.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0587.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0624.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0741.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0858.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0895.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0932.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0969.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
];
cp.model.videos=[
];
cp.model.slideVideos=[
];
cp.model.tocVideos=[
];
cp.model.audios=[
'ar/StAd27.mp3',
'ar/2133.mp3'
];

cp.initVariables = function(){
cp.cv('CaptivateVersion','12.2.0',1,1000,0);
cp.cv('Date.DateDDMMYY','dd/mm/yyyy',1,15,0);
cp.cv('Date.DateMMDDYY','mm/dd/yyyy',1,15,0);
cp.cv('Date.Day',1,1,15,0);
cp.cv('Date.Hours','hh',1,15,0);
cp.cv('Date.LocaleString','',1,15,0);
cp.cv('Date.Minutes','mm',1,15,0);
cp.cv('Date.Month','mm',1,15,0);
cp.cv('Date.Time','hh:mm:ss',1,15,0);
cp.cv('Date.Today','dd',1,15,0);
cp.cv('Date.Year','yyyy',1,15,0);
cp.cv('Project.AudioLevel',100,1,15,0);
cp.cv('Project.ClosedCaptions',1,1,15,0);
cp.cv('Project.CurrentSlideName','slide',1,15,0);
cp.cv('Project.CurrentSlideNumber',1,1,15,0);
cp.cv('Project.LockTOC',0,1,15,0);
cp.cv('Project.MuteAudio',0,1,15,0);
cp.cv('Project.ShowPlaybar',1,1,15,0);
cp.cv('Project.ShowTOC',0,1,15,0);
cp.cv('Project.SlideCount',1,1,15,0);
cp.cv('Question.AnswerChoice','',1,15,0);
cp.cv('Question.MaxAttempts',0,1,15,0);
cp.cv('Question.NegativePoints',0,1,15,0);
cp.cv('Question.PointsAssigned',0,1,15,0);
cp.cv('Question.PreviousQuestionScore',0,1,15,0);
cp.cv('Quiz.AttemptCount',0,1,15,0);
cp.cv('Quiz.CorrectAnswerCount',0,1,15,0);
cp.cv('Quiz.InReview',0,1,15,0);
cp.cv('Quiz.InScope',0,1,15,0);
cp.cv('Quiz.MaxScore',0,1,1000,0);
cp.cv('Quiz.Pass',0,1,15,0);
cp.cv('Quiz.PassPercentage',80,1,1000,0);
cp.cv('Quiz.PassPoints',0,1,1000,0);
cp.cv('Quiz.PercentageScore',0,1,15,0);
cp.cv('Quiz.QuestionCount',0,1,1000,0);
cp.cv('Quiz.Score',0,1,15,0);
cp.cv('Quiz.UnansweredQuestionCount',0,1,1000,0);
cp.cv('cpInfoHasPlaybar',1,1,1000,0);
cp.cv('cpInfoSlidesInProject',21,1,1000,0);
cp.cv('cpLockTOC',0,1,1000,0);
cp.cv('cpQuizInfoPreTestTotalQuestions',0,1,1000,0);
cp.cv('cpQuizInfoTotalQuizPoints',0,1,1000,0);
cp.cv('cpInfoPrevFrame',0,1,15,0);
cp.cv('LMS.CourseName','',0,15,0);
cp.cv('LMS.LearnerID','',0,15,0);
cp.cv('LMS.LearnerName','',0,15,0);
cp.cv('variableEditBoxNum_1','',0,15,0);
cp.cv('variableEditBoxNum_2','',0,15,0);
cp.cv('variableEditBoxStr_1','',0,15,0);
cp.cv('variableEditBoxStr_2','',0,15,0);
};cp.ReportingVariables="LMS.CourseName,LMS.LearnerID,LMS.LearnerName,variableEditBoxNum_1,variableEditBoxNum_2,variableEditBoxStr_1,variableEditBoxStr_2,";
};cp.sbw=0;cp.useg=0;cp.geo=0;cp.pg=0;cp.win8=0;cp.autoGrow=1;cp.fluidFont=1;
